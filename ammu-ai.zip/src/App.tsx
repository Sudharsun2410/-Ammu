import React, { useState } from 'react';
import { 
  Globe, 
  Sparkles, 
  Sliders, 
  Code2, 
  LayoutGrid, 
  Smartphone, 
  MessageSquare, 
  Home as HomeIcon, 
  Mic, 
  Image as ImageIcon, 
  FolderGit2, 
  User, 
  Menu, 
  X,
  CloudCheck,
  ShieldCheck,
  Download
} from 'lucide-react';
import { AppLanguage, ScreenType, UserProfile, VoiceAssistantConfig } from './types';
import { translations } from './i18n/translations';
import { MobileFrame } from './components/MobileFrame';
import { HomeScreen } from './screens/HomeScreen';
import { ChatBotScreen } from './screens/ChatBotScreen';
import { VoiceAnalysisScreen } from './screens/VoiceAnalysisScreen';
import { ImageGeneratorScreen } from './screens/ImageGeneratorScreen';
import { ProjectsScreen } from './screens/ProjectsScreen';
import { LoginScreen } from './screens/LoginScreen';
import { CustomVoiceModal } from './screens/CustomVoiceModal';
import { AndroidCodeHubModal } from './screens/AndroidCodeHubModal';
import { CustomVoiceAgentScreen } from './screens/CustomVoiceAgentScreen';
import { voiceCloneService } from './services/voiceCloneService';

export default function App() {
  const [language, setLanguage] = useState<AppLanguage>('en');
  const [currentScreen, setCurrentScreen] = useState<ScreenType>('home');
  const [viewMode, setViewMode] = useState<'single' | 'triple'>('single');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState(false);
  const [isCodeModalOpen, setIsCodeModalOpen] = useState(false);
  const [activePrompt, setActivePrompt] = useState<string>('');

  const [user, setUser] = useState<UserProfile>({
    name: 'Jack Johnson',
    email: 'jack.johnson@ammu.ai',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80',
    isLoggedIn: true,
    role: 'Pro Member',
  });

  const [voiceConfig, setVoiceConfig] = useState<VoiceAssistantConfig>(() => {
    const activeProf = voiceCloneService.getActiveProfile();
    const activeVoice = voiceCloneService.getActiveVoiceSelection();
    return {
      selectedVoice: activeVoice || (activeProf ? 'my-voice' : 'female'),
      femaleVoice: activeVoice === 'female',
      pitch: activeProf?.acousticFeatures?.pitchShift ?? 1.0,
      rate: 1.0,
      volume: 1.0,
      lang: 'auto',
      autoDetectLanguage: true,
      activeProfile: activeProf,
      hasCustomVoice: Boolean(activeProf),
      customVoiceName: activeProf?.name || 'My Voice',
    };
  });

  const t = translations[language];

  const handleLanguageToggle = () => {
    setLanguage(prev => prev === 'en' ? 'ta' : 'en');
  };

  const handleQuickPrompt = (prompt: string) => {
    setActivePrompt(prompt);
    setCurrentScreen('chatbot');
  };

  const renderActiveScreen = () => {
    switch (currentScreen) {
      case 'home':
        return (
          <HomeScreen
            language={language}
            user={user}
            onNavigate={(screen) => setCurrentScreen(screen)}
            onQuickPrompt={handleQuickPrompt}
            onOpenMenu={() => setIsMenuOpen(true)}
          />
        );
      case 'chatbot':
        return (
          <ChatBotScreen
            language={language}
            onBack={() => setCurrentScreen('home')}
            onOpenVoice={() => setCurrentScreen('voice')}
            onOpenMenu={() => setIsMenuOpen(true)}
            voiceConfig={voiceConfig}
            initialPrompt={activePrompt}
          />
        );
      case 'voice':
        return (
          <VoiceAnalysisScreen
            language={language}
            onBack={() => setCurrentScreen('home')}
            onOpenMenu={() => setIsMenuOpen(true)}
            onOpenVoiceSettings={() => setIsVoiceModalOpen(true)}
            onCommandGenerated={(cmd) => {
              setActivePrompt(cmd);
              setCurrentScreen('chatbot');
            }}
            voiceConfig={voiceConfig}
            onUpdateVoiceConfig={setVoiceConfig}
            onOpenVoiceAgent={() => setCurrentScreen('voiceagent')}
          />
        );
      case 'voiceagent':
        return (
          <CustomVoiceAgentScreen
            language={language}
            onBack={() => setCurrentScreen('home')}
            onOpenMenu={() => setIsMenuOpen(true)}
            voiceConfig={voiceConfig}
            onUpdateVoiceConfig={setVoiceConfig}
          />
        );
      case 'imagegen':
        return (
          <ImageGeneratorScreen
            language={language}
            onBack={() => setCurrentScreen('home')}
            onOpenMenu={() => setIsMenuOpen(true)}
          />
        );
      case 'projects':
        return (
          <ProjectsScreen
            language={language}
            onBack={() => setCurrentScreen('home')}
            onOpenMenu={() => setIsMenuOpen(true)}
          />
        );
      case 'login':
        return (
          <LoginScreen
            language={language}
            onLanguageChange={setLanguage}
            onLoginSuccess={(loggedUser) => {
              setUser(loggedUser);
              setCurrentScreen('home');
            }}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-[#07030e] text-white flex flex-col font-sans selection:bg-purple-600 selection:text-white">
      {/* Top Global Command Bar */}
      <header className="sticky top-0 z-40 bg-[#0d061c]/90 backdrop-blur-xl border-b border-purple-500/20 px-4 py-2.5 flex items-center justify-between">
        {/* Brand & Tag */}
        <div className="flex items-center gap-3">
          <div 
            onClick={() => setCurrentScreen('home')}
            className="flex items-center gap-2 cursor-pointer group"
          >
            <div className="w-8 h-8 rounded-full p-[1.5px] bg-gradient-to-tr from-fuchsia-500 via-purple-500 to-indigo-500 shadow-[0_0_15px_rgba(168,85,247,0.5)]">
              <div className="w-full h-full rounded-full bg-[#0d061c] flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-fuchsia-400 group-hover:rotate-12 transition-transform" />
              </div>
            </div>
            <div>
              <span className="font-extrabold text-base tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white via-purple-100 to-fuchsia-300">
                AMMU
              </span>
              <span className="ml-1.5 px-1.5 py-0.5 rounded-full bg-purple-900/60 border border-purple-500/30 text-[9px] font-semibold text-purple-300">
                Android Jetpack
              </span>
            </div>
          </div>
        </div>

        {/* Center Screen Navigator Navigation Bar */}
        <nav className="hidden lg:flex items-center gap-1 px-2 py-1 rounded-full bg-[#150a29]/80 border border-purple-500/25">
          {[
            { id: 'home', label: 'Home', icon: HomeIcon },
            { id: 'chatbot', label: 'Chat Bot', icon: MessageSquare },
            { id: 'voice', label: 'Voice Analysis', icon: Mic },
            { id: 'voiceagent', label: 'Voice Agent', icon: Sparkles },
            { id: 'imagegen', label: 'AI Images', icon: ImageIcon },
            { id: 'projects', label: 'My Projects', icon: FolderGit2 },
          ].map((item) => {
            const Icon = item.icon;
            const isActive = currentScreen === item.id && viewMode === 'single';
            return (
              <button
                key={item.id}
                onClick={() => {
                  setViewMode('single');
                  setCurrentScreen(item.id as ScreenType);
                }}
                className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold transition-all ${
                  isActive
                    ? 'bg-purple-600 text-white shadow-[0_0_12px_rgba(168,85,247,0.6)]'
                    : 'text-slate-300 hover:text-white hover:bg-purple-950/40'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Right Action Tools */}
        <div className="flex items-center gap-2">
          {/* 3-Screen Reference View Toggle */}
          <button
            onClick={() => setViewMode(prev => prev === 'single' ? 'triple' : 'single')}
            className={`hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold transition-all ${
              viewMode === 'triple'
                ? 'bg-gradient-to-r from-fuchsia-600 to-purple-600 border-purple-400 text-white shadow-[0_0_15px_rgba(168,85,247,0.5)]'
                : 'bg-[#180c2f] border-purple-500/30 text-purple-200 hover:text-white hover:border-purple-400'
            }`}
            title="Toggle 3-Screen View matching the uploaded screenshot"
          >
            {viewMode === 'triple' ? (
              <>
                <Smartphone className="w-3.5 h-3.5" />
                <span>Single Mobile</span>
              </>
            ) : (
              <>
                <LayoutGrid className="w-3.5 h-3.5 text-fuchsia-400" />
                <span>3-Screen Design View</span>
              </>
            )}
          </button>

          {/* Android Kotlin Code Hub Modal Trigger */}
          <button
            onClick={() => setIsCodeModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#190a32] border border-purple-500/35 text-xs font-semibold text-purple-200 hover:text-white hover:border-purple-400 transition-all shadow-md active:scale-95"
            title="View & Export Jetpack Compose Kotlin Code"
          >
            <Code2 className="w-3.5 h-3.5 text-fuchsia-400" />
            <span className="hidden md:inline">Android Code</span>
          </button>

          {/* AI Voice Cloning & Tuner Trigger */}
          <button
            onClick={() => setIsVoiceModalOpen(true)}
            className="flex items-center gap-1.5 p-2 sm:px-3 sm:py-1.5 rounded-xl bg-[#190a32] border border-purple-500/35 text-xs font-semibold text-purple-200 hover:text-white hover:border-purple-400 transition-all shadow-md active:scale-95"
            title="Custom Voice Cloning & Audio Settings"
          >
            <Sliders className="w-3.5 h-3.5 text-fuchsia-400" />
            <span className="hidden md:inline">
              {voiceConfig.selectedVoice === 'my-voice'
                ? voiceConfig.activeProfile
                  ? `Voice: ${voiceConfig.activeProfile.name.slice(0, 10)}`
                  : 'Voice: My Voice'
                : voiceConfig.selectedVoice === 'female'
                ? 'Voice: Female'
                : 'Voice: Male'}
            </span>
          </button>

          {/* Language Switcher (EN / தமிழ்) */}
          <button
            onClick={handleLanguageToggle}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-950/80 border border-purple-500/40 text-xs font-bold text-white hover:border-purple-300 transition-all active:scale-95 shadow-md"
            title="Switch Language (English / தமிழ்)"
          >
            <Globe className="w-3.5 h-3.5 text-fuchsia-400" />
            <span>{language === 'en' ? 'தமிழ்' : 'English'}</span>
          </button>
        </div>
      </header>

      {/* Main Workspace Area */}
      <main className="flex-1 flex flex-col items-center justify-center p-3 sm:p-6 overflow-y-auto">
        {viewMode === 'triple' ? (
          /* 3-Screen Reference Presentation matching the user's uploaded screenshot! */
          <div className="w-full max-w-7xl mx-auto py-2">
            <div className="text-center mb-6">
              <h2 className="text-lg sm:text-2xl font-extrabold tracking-tight text-white flex items-center justify-center gap-2">
                <Sparkles className="w-5 h-5 text-fuchsia-400" />
                <span>AMMU 3-Screen Native Android Design System</span>
              </h2>
              <p className="text-xs sm:text-sm text-purple-300/80 mt-1">
                Pixel-accurate recreation of Home Dashboard, AI Chat Bot, and Voice Analysis screens
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 xl:gap-8 items-start justify-center">
              {/* Screen 1: Home Dashboard */}
              <div className="flex flex-col items-center">
                <div className="text-xs font-semibold text-purple-300 mb-2 uppercase tracking-wider flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-purple-400" />
                  <span>1. Home Dashboard</span>
                </div>
                <MobileFrame>
                  <HomeScreen
                    language={language}
                    user={user}
                    onNavigate={(screen) => {
                      setViewMode('single');
                      setCurrentScreen(screen);
                    }}
                    onQuickPrompt={(p) => {
                      setViewMode('single');
                      handleQuickPrompt(p);
                    }}
                    onOpenMenu={() => setIsMenuOpen(true)}
                  />
                </MobileFrame>
              </div>

              {/* Screen 2: AI Chatbot */}
              <div className="flex flex-col items-center">
                <div className="text-xs font-semibold text-purple-300 mb-2 uppercase tracking-wider flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-fuchsia-400" />
                  <span>2. AI Chat Bot</span>
                </div>
                <MobileFrame>
                  <ChatBotScreen
                    language={language}
                    onBack={() => {
                      setViewMode('single');
                      setCurrentScreen('home');
                    }}
                    onOpenVoice={() => {
                      setViewMode('single');
                      setCurrentScreen('voice');
                    }}
                    onOpenMenu={() => setIsMenuOpen(true)}
                    voiceConfig={voiceConfig}
                    initialPrompt=""
                  />
                </MobileFrame>
              </div>

              {/* Screen 3: Voice Assistant / Voice Analysis */}
              <div className="flex flex-col items-center">
                <div className="text-xs font-semibold text-purple-300 mb-2 uppercase tracking-wider flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-pink-400" />
                  <span>3. Voice Analysis</span>
                </div>
                <MobileFrame>
                  <VoiceAnalysisScreen
                    language={language}
                    onBack={() => {
                      setViewMode('single');
                      setCurrentScreen('home');
                    }}
                    onOpenMenu={() => setIsMenuOpen(true)}
                    onOpenVoiceSettings={() => setIsVoiceModalOpen(true)}
                    onCommandGenerated={(cmd) => {
                      setViewMode('single');
                      handleQuickPrompt(cmd);
                    }}
                    voiceConfig={voiceConfig}
                    onUpdateVoiceConfig={setVoiceConfig}
                    onOpenVoiceAgent={() => {
                      setViewMode('single');
                      setCurrentScreen('voiceagent');
                    }}
                  />
                </MobileFrame>
              </div>
            </div>
          </div>
        ) : (
          /* Single Interactive Android Mobile Screen */
          <div className="w-full flex flex-col items-center">
            <MobileFrame>
              {renderActiveScreen()}
            </MobileFrame>
          </div>
        )}
      </main>

      {/* Responsive Slide-Over App Drawer */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/75 backdrop-blur-md animate-fadeIn">
          <div className="w-full max-w-xs h-full bg-[#120726] border-l border-purple-500/30 p-5 flex flex-col justify-between text-white shadow-2xl">
            {/* Drawer Header */}
            <div>
              <div className="flex items-center justify-between pb-4 border-b border-purple-500/20 mb-4">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-full p-[1.5px] bg-gradient-to-tr from-fuchsia-500 to-purple-500">
                    <img src={user.avatar} alt={user.name} className="w-full h-full rounded-full object-cover" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">{user.name}</h4>
                    <p className="text-[10px] text-purple-300">{user.role}</p>
                  </div>
                </div>

                <button
                  onClick={() => setIsMenuOpen(false)}
                  className="w-8 h-8 rounded-full bg-purple-950/60 flex items-center justify-center text-slate-300 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Drawer Links */}
              <div className="space-y-1">
                {[
                  { id: 'home', label: language === 'ta' ? 'முகப்பு' : 'Home Dashboard', icon: HomeIcon },
                  { id: 'chatbot', label: language === 'ta' ? 'அம்மு உரையாடல்' : 'AI Chatbot', icon: MessageSquare },
                  { id: 'voice', label: language === 'ta' ? 'குரல் பகுப்பாய்வு' : 'Voice Assistant', icon: Mic },
                  { id: 'voiceagent', label: language === 'ta' ? 'தனிப்பயன் குரல் ஏஜென்ட்' : 'Custom Voice Agent', icon: Sparkles },
                  { id: 'imagegen', label: language === 'ta' ? 'AI பட உருவாக்கம்' : 'AI Image Generator', icon: ImageIcon },
                  { id: 'projects', label: language === 'ta' ? 'எனது திட்டங்கள்' : 'My Projects (Offline)', icon: FolderGit2 },
                  { id: 'login', label: language === 'ta' ? 'சுயவிவரம் & கணக்கு' : 'Profile & Firebase Auth', icon: User },
                ].map((item) => {
                  const Icon = item.icon;
                  const isActive = currentScreen === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        setViewMode('single');
                        setCurrentScreen(item.id as ScreenType);
                        setIsMenuOpen(false);
                      }}
                      className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                        isActive
                          ? 'bg-purple-600/40 text-white border border-purple-400/40'
                          : 'text-slate-300 hover:text-white hover:bg-purple-950/40'
                      }`}
                    >
                      <Icon className="w-4 h-4 text-purple-400" />
                      <span>{item.label}</span>
                    </button>
                  );
                })}
              </div>

              {/* Developer & System shortcuts */}
              <div className="mt-5 pt-4 border-t border-purple-500/20 space-y-2">
                <button
                  onClick={() => {
                    setIsMenuOpen(false);
                    setIsCodeModalOpen(true);
                  }}
                  className="w-full flex items-center justify-between p-2.5 rounded-xl bg-purple-950/50 border border-purple-500/25 text-xs text-purple-200 hover:text-white hover:border-purple-400"
                >
                  <span className="flex items-center gap-2">
                    <Code2 className="w-4 h-4 text-fuchsia-400" />
                    <span>Android Jetpack Code</span>
                  </span>
                  <span className="text-[10px] text-purple-400">Kotlin</span>
                </button>

                <button
                  onClick={() => {
                    setIsMenuOpen(false);
                    setIsVoiceModalOpen(true);
                  }}
                  className="w-full flex items-center justify-between p-2.5 rounded-xl bg-purple-950/50 border border-purple-500/25 text-xs text-purple-200 hover:text-white hover:border-purple-400"
                >
                  <span className="flex items-center gap-2">
                    <Sliders className="w-4 h-4 text-purple-400" />
                    <span>Voice Cloning & Settings</span>
                  </span>
                  <span className="text-[10px] text-fuchsia-400">Clone</span>
                </button>
              </div>
            </div>

            {/* Cloud & Version Info */}
            <div className="p-3 rounded-2xl bg-black/40 border border-purple-500/20 text-[11px] text-slate-400 space-y-1">
              <div className="flex items-center gap-1.5 text-emerald-400 font-medium">
                <CloudCheck className="w-3.5 h-3.5" />
                <span>Firebase Firestore Ready</span>
              </div>
              <p className="text-[10px]">AMMU v1.0.0 • Mobile Native</p>
            </div>
          </div>
        </div>
      )}

      {/* Voice Tuning & Custom Voice Import Modal */}
      {isVoiceModalOpen && (
        <CustomVoiceModal
          language={language}
          voiceConfig={voiceConfig}
          onUpdateConfig={setVoiceConfig}
          onClose={() => setIsVoiceModalOpen(false)}
        />
      )}

      {/* Jetpack Compose Android Code Hub Modal */}
      {isCodeModalOpen && (
        <AndroidCodeHubModal
          onClose={() => setIsCodeModalOpen(false)}
        />
      )}
    </div>
  );
}
