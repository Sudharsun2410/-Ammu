import { AppLanguage } from '../types';

export interface Translations {
  appName: string;
  greetingPrefix: string;
  defaultUserName: string;
  heroLine1: string;
  heroLine2: string;
  cardGenVisual: string;
  cardGenDoc: string;
  cardOrgMeeting: string;
  recentChat: string;
  seeAll: string;
  pillGenImage: string;
  pillSummarize: string;
  pillQuickReport: string;
  pillAskAnything: string;
  startNewChat: string;
  chatBotTitle: string;
  askAiPlaceholder: string;
  copy: string;
  copied: string;
  share: string;
  download: string;
  voiceAnalysisTitle: string;
  listening: string;
  tapToSpeak: string;
  voiceHeroTitle: string;
  voiceHeroDesc: string;
  imageGenTitle: string;
  imagePromptPlaceholder: string;
  generateImagesBtn: string;
  myProjectsTitle: string;
  offlineReadyBadge: string;
  cloudSyncedBadge: string;
  loginTitle: string;
  loginSubtitle: string;
  signInBtn: string;
  guestBtn: string;
  languageSelect: string;
  voiceAssistantSettings: string;
  femaleVoiceLabel: string;
  customVoiceImport: string;
  importVoiceAudio: string;
  testVoiceSample: string;
  offlineNotice: string;
  syncNow: string;
  switchView: string;
  previewMode: string;
  threeScreensMode: string;
  androidCodeExport: string;
  sampleChatQ1: string;
  sampleChatA1: string;
  sampleChatQ2: string;
  sampleChatA2: string;
  voiceAgentTitle: string;
  voiceAgentSubtitle: string;
  uploadVoiceBtn: string;
  recordVoiceBtn: string;
  createProfileBtn: string;
  testVoiceResponseBtn: string;
  selectMyVoice: string;
  selectAmmuFemale: string;
  trainingStatusLabel: string;
  voiceConsentLabel: string;
}

export const translations: Record<AppLanguage, Translations> = {
  en: {
    appName: 'AMMU',
    greetingPrefix: 'Hi there',
    defaultUserName: 'Jack Johnson',
    heroLine1: 'Smart Help,',
    heroLine2: 'Instantly for You',
    cardGenVisual: 'Generating Visual',
    cardGenDoc: 'Generate Document',
    cardOrgMeeting: 'Organizing Meeting',
    recentChat: 'Recent Chat',
    seeAll: 'See All',
    pillGenImage: 'Generate AI Image',
    pillSummarize: 'Summarize This Text',
    pillQuickReport: 'Build Quick Report',
    pillAskAnything: 'Ask Anything Now',
    startNewChat: 'Start New Chat',
    chatBotTitle: 'Chat Bot',
    askAiPlaceholder: 'Ask AI anything...',
    copy: 'Copy',
    copied: 'Copied!',
    share: 'Share',
    download: 'Download',
    voiceAnalysisTitle: 'Voice Analysis',
    listening: 'Listening...',
    tapToSpeak: 'Tap microphone to speak',
    voiceHeroTitle: 'Generate high-quality images',
    voiceHeroDesc: 'instantly using voice commands —smart, fast, and powered by advanced AI',
    imageGenTitle: 'AI Image Generator',
    imagePromptPlaceholder: 'Describe the graphic picture you want to create...',
    generateImagesBtn: 'Generate 4 Visuals',
    myProjectsTitle: 'My Projects',
    offlineReadyBadge: 'Offline Ready (Local Cache)',
    cloudSyncedBadge: 'Firebase Synced',
    loginTitle: 'Welcome to AMMU',
    loginSubtitle: 'Experience the next-gen AI companion with Tamil & English voice intelligence',
    signInBtn: 'Continue with Firebase Auth',
    guestBtn: 'Explore as Guest',
    languageSelect: 'Language',
    voiceAssistantSettings: 'Voice Assistant & Female TTS',
    femaleVoiceLabel: 'AMMU Female AI Voice',
    customVoiceImport: 'Custom Voice Profile',
    importVoiceAudio: 'Import Custom Voice Sample (.mp3 / .wav)',
    testVoiceSample: 'Test Voice Synthesis',
    offlineNotice: 'All creations are saved locally in offline storage and sync automatically to Cloud Firestore.',
    syncNow: 'Sync with Cloud',
    switchView: 'Toggle Multi-Screen Reference View',
    previewMode: 'Mobile Device View',
    threeScreensMode: '3-Screen Design Overview',
    androidCodeExport: 'Jetpack Compose Code & Android Studio Project',
    sampleChatQ1: 'Hey, is this our first time chatting together today?',
    sampleChatA1: "Hello! Yes, and I'm excited to assist you. How can I help today?",
    sampleChatQ2: 'Awesome! Can you show me four cool graphic pictures?',
    sampleChatA2: 'Sure! Here are 4 graphic images I made for you!',
    voiceAgentTitle: 'AMMU Custom Voice Agent',
    voiceAgentSubtitle: 'Clone your own voice and have AMMU respond in your authentic voice across Tamil & English',
    uploadVoiceBtn: 'Upload Voice (MP3, WAV, M4A)',
    recordVoiceBtn: 'Record Voice Sample',
    createProfileBtn: 'Create Custom Voice Profile',
    testVoiceResponseBtn: 'Test Voice Response',
    selectMyVoice: 'My Custom Voice',
    selectAmmuFemale: 'AMMU Female AI Voice',
    trainingStatusLabel: 'Voice Training Status',
    voiceConsentLabel: 'I confirm ownership of this voice sample and authorize AMMU to clone and synthesize AI responses in my voice.',
  },
  ta: {
    appName: 'அம்மு (AMMU)',
    greetingPrefix: 'வணக்கம்',
    defaultUserName: 'ஜாக் ஜான்சன்',
    heroLine1: 'உடனடி ஸ்மார்ட் உதவி,',
    heroLine2: 'உங்களுக்காக எப்போதும்',
    cardGenVisual: 'காட்சி உருவாக்கம்',
    cardGenDoc: 'ஆவணம் உருவாக்குதல்',
    cardOrgMeeting: 'கூட்டம் ஏற்பாடு செய்தல்',
    recentChat: 'சமீபத்திய உரையாடல்',
    seeAll: 'அனைத்தும்',
    pillGenImage: 'AI படம் உருவாக்கு',
    pillSummarize: 'இந்த உரையை சுருக்கு',
    pillQuickReport: 'விரைவு அறிக்கை தயார் செய்',
    pillAskAnything: 'இப்போதே எதையும் கேளுங்கள்',
    startNewChat: 'புதிய அரட்டை தொடங்கு',
    chatBotTitle: 'அம்மு உரையாடல்',
    askAiPlaceholder: 'அம்முவிடம் எதையும் கேளுங்கள்...',
    copy: 'நகலெடு',
    copied: 'நகலெடுக்கப்பட்டது!',
    share: 'பகிர்',
    download: 'பதிவிறக்கு',
    voiceAnalysisTitle: 'குரல் பகுப்பாய்வு',
    listening: 'கவனித்துக் கொண்டிருக்கிறது...',
    tapToSpeak: 'பேச மைக்ரோஃபோனைத் தொடவும்',
    voiceHeroTitle: 'உயர்தர படங்களை உருவாக்கலாம்',
    voiceHeroDesc: 'குரல் கட்டளைகள் மூலம் உடனடியாக உருவாக்கவும் — அதிவேக, அறிவார்ந்த AMMU AI',
    imageGenTitle: 'AI பட உருவாக்கக் கூடம்',
    imagePromptPlaceholder: 'நீங்கள் உருவாக்க விரும்பும் படத்தை விவரிக்கவும்...',
    generateImagesBtn: '4 படங்களை உருவாக்கு',
    myProjectsTitle: 'எனது திட்டங்கள்',
    offlineReadyBadge: 'ஆஃப்லைனில் தயார் (லோக்கல் மெமரி)',
    cloudSyncedBadge: 'ஃபயர்பேஸ் ஒத்திசைக்கப்பட்டது',
    loginTitle: 'அம்முவுக்கு வரவேற்கிறோம்',
    loginSubtitle: 'தமிழ் மற்றும் ஆங்கில குரல் நுண்ணறிவு கொண்ட அடுத்த தலைமுறை AI துணை',
    signInBtn: 'ஃபயர்பேஸ் மூலம் உள்நுழைக',
    guestBtn: 'விருந்தினராக தொடரவும்',
    languageSelect: 'மொழி',
    voiceAssistantSettings: 'குரல் உதவியாளர் & பெண் குரல் TTS',
    femaleVoiceLabel: 'அம்மு பெண் AI குரல்',
    customVoiceImport: 'தனிப்பயன் குரல் சுயவிவரம்',
    importVoiceAudio: 'குரல் மாதிரியைப் பதிவேற்றுக (.mp3 / .wav)',
    testVoiceSample: 'குரலை சோதிக்கவும்',
    offlineNotice: 'அனைத்து உருவாக்கங்களும் ஆஃப்லைனில் சேமிக்கப்பட்டு ஃபயர்பேஸ் கிளவுட் உடன் ஒத்திசைக்கப்படும்.',
    syncNow: 'கிளவுடுடன் ஒத்திசை',
    switchView: '3-திரை வடிவமைப்பு பார்வை',
    previewMode: 'மொபைல் சாதன பார்வை',
    threeScreensMode: '3-திரை கண்ணோட்டம்',
    androidCodeExport: 'ஜெட் பேக் கம்போஸ் கோட் & ஆன்ட்ராய்டு ஸ்டுடியோ திட்டம்',
    sampleChatQ1: 'வணக்கம், இன்று நாம் முதன்முறையாகப் பேசுகிறோமா?',
    sampleChatA1: 'வணக்கம்! ஆம், உங்களுக்கு உதவ நான் தயாராக உள்ளேன். இன்று நான் உங்களுக்கு என்ன உதவ முடியும்?',
    sampleChatQ2: 'அற்புதம்! எனக்கு நான்கு அழகான கிராபிக் படங்களைக் காட்ட முடியுமா?',
    sampleChatA2: 'நிச்சயமாக! உங்களுக்காக நான் உருவாக்கிய 4 கிராபிக் படங்கள் இதோ!',
    voiceAgentTitle: 'AMMU தனிப்பயன் குரல் ஏஜென்ட்',
    voiceAgentSubtitle: 'உங்கள் சொந்த குரலை குளோன் செய்து, தமிழ் மற்றும் ஆங்கிலத்தில் AI பதில்களைப் பெறுங்கள்',
    uploadVoiceBtn: 'குரல் பதிவேற்றுக (MP3, WAV, M4A)',
    recordVoiceBtn: 'குரல் மாதிரியை பதிவு செய்',
    createProfileBtn: 'தனிப்பயன் குரல் சுயவிவரத்தை உருவாக்கு',
    testVoiceResponseBtn: 'குரல் பதிலை சோதிக்கவும்',
    selectMyVoice: 'எனது தனிப்பயன் குரல்',
    selectAmmuFemale: 'அம்மு பெண் AI குரல்',
    trainingStatusLabel: 'குரல் பயிற்சி நிலை',
    voiceConsentLabel: 'இந்த குரல் மாதிரி என்னுடையது என்பதை உறுதிப்படுத்துகிறேன், மேலும் AMMU AI எனது குரலில் பேச முழு அனுமதி அளிக்கிறேன்.',
  },
};
