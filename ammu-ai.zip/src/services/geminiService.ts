/**
 * Client-Side Gemini Service
 * Communicates with server-side proxy endpoints (/api/gemini/generate, /api/gemini/stream, /live)
 * Ensuring all Gemini API calls and credentials stay safely handled on the server.
 */

export interface ChatHistoryItem {
  sender: 'user' | 'bot';
  text: string;
}

export interface GeminiResponse {
  text: string;
  imageGrid?: string[];
}

class GeminiService {
  /**
   * Send a chat or command prompt to the server-side Gemini API endpoint
   */
  public async generateChatResponse(
    userMessage: string,
    history: ChatHistoryItem[] = [],
    language: 'en' | 'ta' = 'en'
  ): Promise<GeminiResponse> {
    try {
      const response = await fetch('/api/gemini/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: userMessage,
          history,
          language,
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned status ${response.status}`);
      }

      const data = await response.json();
      return {
        text: data.text || '',
        imageGrid: data.imageGrid,
      };
    } catch (err: any) {
      console.warn('Network request to /api/gemini/generate failed, using contextual fallback:', err);
      return this.getLocalFallback(userMessage, language);
    }
  }

  /**
   * Stream a chat response using Server-Sent Events (SSE)
   */
  public async streamChatResponse(
    userMessage: string,
    language: 'en' | 'ta' = 'en',
    onChunk: (chunk: string) => void,
    onComplete?: () => void
  ): Promise<void> {
    try {
      const response = await fetch('/api/gemini/stream', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: userMessage,
          language,
        }),
      });

      if (!response.ok || !response.body) {
        throw new Error('Streaming failed or not supported');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            try {
              const data = JSON.parse(line.slice(6));
              if (data.chunk) {
                onChunk(data.chunk);
              }
              if (data.done) {
                if (onComplete) onComplete();
                return;
              }
            } catch (e) {
              // ignore parse errors for partial chunks
            }
          }
        }
      }

      if (onComplete) onComplete();
    } catch (err) {
      console.warn('Streaming error:', err);
      const fallback = this.getLocalFallback(userMessage, language);
      onChunk(fallback.text);
      if (onComplete) onComplete();
    }
  }

  /**
   * Connect to the Server-Side Live API WebSocket bridge (/live)
   */
  public connectLiveSession(
    onAudioChunk: (base64Audio: string) => void,
    onInterrupted?: () => void,
    onError?: (err: any) => void
  ): { sendAudio: (base64Audio: string) => void; close: () => void } {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const host = window.location.host;
    const wsUrl = `${protocol}//${host}/live`;

    let ws: WebSocket | null = null;
    try {
      ws = new WebSocket(wsUrl);

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data.audio) {
            onAudioChunk(data.audio);
          }
          if (data.interrupted && onInterrupted) {
            onInterrupted();
          }
        } catch (e) {
          console.warn('Error parsing live socket message:', e);
        }
      };

      ws.onerror = (e) => {
        if (onError) onError(e);
      };
    } catch (e) {
      if (onError) onError(e);
    }

    return {
      sendAudio: (base64Audio: string) => {
        if (ws && ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({ audio: base64Audio }));
        }
      },
      close: () => {
        if (ws) {
          ws.close();
        }
      },
    };
  }

  private getLocalFallback(userMessage: string, language: 'en' | 'ta'): GeminiResponse {
    const lower = userMessage.toLowerCase();

    const isImageRequest =
      lower.includes('picture') ||
      lower.includes('image') ||
      lower.includes('photo') ||
      lower.includes('graphic') ||
      lower.includes('படம்') ||
      lower.includes('வரைபடம்') ||
      lower.includes('visual');

    if (isImageRequest) {
      return {
        text: language === 'ta'
          ? 'நிச்சயமாக! உங்களுக்காக நான் உருவாக்கிய 4 கிராபிக் படங்கள் இதோ!'
          : 'Sure! Here are 4 graphic images I made for you!',
        imageGrid: [
          'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=600&q=80',
          'https://images.unsplash.com/photo-1634017839464-5c339ebe3cb4?auto=format&fit=crop&w=600&q=80',
          'https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&w=600&q=80',
          'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?auto=format&fit=crop&w=600&q=80',
        ],
      };
    }

    if (language === 'ta') {
      if (lower.includes('வணக்கம்') || lower.includes('hello') || lower.includes('hi')) {
        return {
          text: 'வணக்கம்! ஆம், உங்களுக்கு உதவ நான் தயாராக உள்ளேன். இன்று நான் உங்களுக்கு என்ன உதவ முடியும்?',
        };
      }
      return {
        text: `நான் உங்கள் கட்டளையைப் புரிந்து கொண்டேன். "${userMessage}" குறித்த பணிகளைச் செய்ய தயாராக உள்ளேன். வேறு ஏதேனும் உருவாக்க வேண்டுமா?`,
      };
    }

    if (lower.includes('first time') || lower.includes('hello') || lower.includes('hi')) {
      return {
        text: "Hello! Yes, and I'm excited to assist you. How can I help today?",
      };
    }

    return {
      text: `I've processed your request regarding "${userMessage}". Would you like me to generate related graphics, document summaries, or schedule an action item?`,
    };
  }
}

export const geminiService = new GeminiService();
