/**
 * Firebase Authentication & Cloud Firestore Integration Blueprint for AMMU
 * Supports both Android (Kotlin Google Services) & Web SDK clients.
 */

export interface FirebaseClientConfig {
  apiKey: string;
  authDomain: string;
  projectId: string;
  storageBucket: string;
  messagingSenderId: string;
  appId: string;
}

export const AMMU_FIREBASE_CONFIG: FirebaseClientConfig = {
  apiKey: "AIzaSyAMMU_CLIENT_API_KEY_PLACEHOLDER",
  authDomain: "ammu-ai-mobile-prod.firebaseapp.com",
  projectId: "ammu-ai-mobile-prod",
  storageBucket: "ammu-ai-mobile-prod.appspot.com",
  messagingSenderId: "709967487309",
  appId: "1:709967487309:android:bff0e9bd4e3a89",
};

/**
 * Recommended Cloud Firestore Data Schema for AMMU:
 * 
 * /users/{userId}
 *   - uid: string
 *   - displayName: string
 *   - email: string
 *   - preferredLanguage: 'en' | 'ta'
 *   - voiceSettings: { pitch: number, rate: number, customVoiceId?: string }
 *   - createdAt: timestamp
 * 
 * /users/{userId}/projects/{projectId}
 *   - id: string
 *   - title: string
 *   - category: 'image' | 'doc' | 'chat' | 'audio'
 *   - description: string
 *   - previewUrl: string
 *   - content: string
 *   - updatedAt: timestamp
 *   - localSynced: boolean
 * 
 * /users/{userId}/chats/{chatId}
 *   - id: string
 *   - sender: 'user' | 'bot'
 *   - text: string
 *   - imageGrid: array<string>
 *   - timestamp: timestamp
 */

export const FIRESTORE_SECURITY_RULES = `rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
      
      match /projects/{projectId} {
        allow read, write: if request.auth != null && request.auth.uid == userId;
      }
      
      match /chats/{chatId} {
        allow read, write: if request.auth != null && request.auth.uid == userId;
      }
    }
  }
}`;
