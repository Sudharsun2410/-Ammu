import { VoiceAssistantConfig, VoiceSelectionType } from '../types';
import { voiceCloneService } from './voiceCloneService';

class TtsService {
  private recognition: any = null;

  public isSpeaking(): boolean {
    return voiceCloneService.isSpeaking();
  }

  public isPlaybackPaused(): boolean {
    return voiceCloneService.isPlaybackPaused();
  }

  public pause(): void {
    voiceCloneService.pausePlayback();
  }

  public resume(): void {
    voiceCloneService.resumePlayback();
  }

  public stop(): void {
    voiceCloneService.stopPlayback();
    if (this.recognition) {
      try {
        this.recognition.abort();
      } catch (e) {}
    }
  }

  /**
   * Speak response using the user's selected voice:
   * - 'my-voice': authentic cloned voice (never generic female)
   * - 'female': AMMU female AI voice
   * - 'male': AMMU male AI voice
   */
  public async speak(
    text: string,
    lang?: 'en' | 'ta' | 'auto',
    config?: Partial<VoiceAssistantConfig>,
    onStart?: () => void,
    onEnd?: () => void,
    onError?: (err: any) => void
  ): Promise<boolean> {
    if (!text || !text.trim()) return false;

    // Determine voice type
    const voiceType: VoiceSelectionType =
      config?.selectedVoice || voiceCloneService.getActiveVoiceSelection() || 'my-voice';

    const speed = config?.rate ?? 1.0;
    const pitch = config?.pitch ?? 1.0;

    try {
      await voiceCloneService.speakText(
        text,
        voiceType,
        speed,
        pitch,
        onStart,
        onEnd,
        onError
      );
      return true;
    } catch (e) {
      console.error('TtsService speech generation failed:', e);
      if (onError) onError(e);
      return false;
    }
  }

  /**
   * Check microphone permission
   */
  public async checkMicrophonePermission(): Promise<'granted' | 'denied' | 'prompt'> {
    if (navigator.permissions && navigator.permissions.query) {
      try {
        const result = await navigator.permissions.query({ name: 'microphone' as PermissionName });
        return result.state;
      } catch (e) {
        // fall through
      }
    }
    return 'prompt';
  }

  /**
   * Speech Recognition (Speech-to-Text) with Tamil & English auto-support
   */
  public startSpeechRecognition(
    lang: 'en' | 'ta' | 'auto',
    onResult: (transcript: string) => void,
    onError: (err: string) => void,
    onEnd?: () => void
  ): { stop: () => void } {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      onError('Speech recognition is not supported in this browser. You can type commands directly.');
      return { stop: () => {} };
    }

    try {
      if (this.recognition) {
        this.recognition.abort();
      }

      const recognition = new SpeechRecognition();
      this.recognition = recognition;
      recognition.lang = lang === 'ta' ? 'ta-IN' : 'en-US';
      recognition.continuous = false;
      recognition.interimResults = true;

      recognition.onresult = (event: any) => {
        let finalTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          }
        }
        if (finalTranscript) {
          onResult(finalTranscript);
        }
      };

      recognition.onerror = (event: any) => {
        if (event.error === 'not-allowed') {
          onError('Microphone permission was denied. Please allow microphone access in your browser settings.');
        } else {
          onError(event.error || 'Speech recognition error occurred.');
        }
      };

      recognition.onend = () => {
        if (onEnd) onEnd();
      };

      recognition.start();

      return {
        stop: () => {
          try {
            recognition.stop();
          } catch (e) {}
        },
      };
    } catch (e: any) {
      onError(e?.message || 'Failed to start microphone listener.');
      return { stop: () => {} };
    }
  }
}

export const ttsService = new TtsService();
