import { ProjectItem, ChatMessage, FirebaseSyncState } from '../types';

const PROJECTS_STORAGE_KEY = 'ammu_offline_projects_v1';
const CHAT_STORAGE_KEY = 'ammu_chat_history_v1';
const SYNC_STATE_KEY = 'ammu_sync_state_v1';

export const INITIAL_PROJECTS: ProjectItem[] = [
  {
    id: 'proj-1',
    title: 'Neon Light Wave Symphony',
    category: 'image',
    description: 'High-res abstract energy waves in deep purple, magenta, and cyan with glassmorphism glow.',
    createdAt: '2026-10-31 21:30',
    previewUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=600&q=80',
    synced: true,
    size: '2.4 MB',
  },
  {
    id: 'proj-2',
    title: 'Strategic Meeting Summary & Action Items',
    category: 'doc',
    description: 'Organized executive notes, automated follow-up calendar items, and team deliverables.',
    createdAt: '2026-10-31 20:15',
    content: '1. AI Voice Architecture finalized.\n2. Kotlin Compose UI synced with design system.\n3. Offline storage with Cloud Firestore backup enabled.',
    synced: true,
    size: '14 KB',
  },
  {
    id: 'proj-3',
    title: 'Cool Graphic Pictures 4-Grid Collection',
    category: 'image',
    description: '4 generated graphic artworks: Golden Rings, Neon Core, Powder Explosion, Cosmic Nebula.',
    createdAt: '2026-10-31 19:40',
    previewUrl: 'https://images.unsplash.com/photo-1634017839464-5c339ebe3cb4?auto=format&fit=crop&w=600&q=80',
    synced: false,
    size: '6.8 MB',
  },
  {
    id: 'proj-4',
    title: 'AMMU Voice Command Memo (Tamil & English)',
    category: 'audio',
    description: 'Bilingual voice session analysis and automated image prompt generation.',
    createdAt: '2026-10-31 18:20',
    synced: true,
    size: '1.1 MB',
  },
];

class StorageService {
  public getProjects(): ProjectItem[] {
    try {
      const data = localStorage.getItem(PROJECTS_STORAGE_KEY);
      if (!data) {
        this.saveProjects(INITIAL_PROJECTS);
        return INITIAL_PROJECTS;
      }
      return JSON.parse(data);
    } catch (e) {
      console.warn('Failed to read projects from storage:', e);
      return INITIAL_PROJECTS;
    }
  }

  public saveProjects(projects: ProjectItem[]): void {
    try {
      localStorage.setItem(PROJECTS_STORAGE_KEY, JSON.stringify(projects));
    } catch (e) {
      console.error('Failed to save projects to storage:', e);
    }
  }

  public addProject(project: Omit<ProjectItem, 'id' | 'createdAt' | 'synced'>): ProjectItem {
    const projects = this.getProjects();
    const newProject: ProjectItem = {
      ...project,
      id: 'proj-' + Date.now(),
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      synced: false,
    };
    const updated = [newProject, ...projects];
    this.saveProjects(updated);
    this.updateSyncCount(1);
    return newProject;
  }

  public deleteProject(id: string): void {
    const projects = this.getProjects();
    const updated = projects.filter(p => p.id !== id);
    this.saveProjects(updated);
  }

  public getChatHistory(): ChatMessage[] {
    try {
      const data = localStorage.getItem(CHAT_STORAGE_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  }

  public saveChatHistory(messages: ChatMessage[]): void {
    try {
      localStorage.setItem(CHAT_STORAGE_KEY, JSON.stringify(messages));
    } catch (e) {
      console.warn('Failed to save chat history:', e);
    }
  }

  public getSyncState(): FirebaseSyncState {
    try {
      const data = localStorage.getItem(SYNC_STATE_KEY);
      if (data) return JSON.parse(data);
    } catch {}
    return {
      isConfigured: true,
      status: 'offline',
      pendingChangesCount: 1,
      projectId: 'ammu-ai-mobile-prod',
      lastSyncedAt: 'Just now',
    };
  }

  public saveSyncState(state: FirebaseSyncState): void {
    try {
      localStorage.setItem(SYNC_STATE_KEY, JSON.stringify(state));
    } catch {}
  }

  public updateSyncCount(increment: number): void {
    const state = this.getSyncState();
    state.pendingChangesCount = Math.max(0, state.pendingChangesCount + increment);
    state.status = state.pendingChangesCount > 0 ? 'offline' : 'synced';
    this.saveSyncState(state);
  }

  public async syncWithCloud(): Promise<FirebaseSyncState> {
    const state = this.getSyncState();
    state.status = 'syncing';
    this.saveSyncState(state);

    // Simulate reliable background sync with Firestore
    await new Promise(res => setTimeout(res, 1200));

    const projects = this.getProjects().map(p => ({ ...p, synced: true }));
    this.saveProjects(projects);

    state.status = 'synced';
    state.pendingChangesCount = 0;
    state.lastSyncedAt = new Date().toLocaleTimeString();
    this.saveSyncState(state);
    return state;
  }
}

export const storageService = new StorageService();
