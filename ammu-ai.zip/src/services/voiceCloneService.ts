import { VoiceProfile, VoiceSelectionType, VoiceBackendStatus } from '../types';

class VoiceCloneService {
  private mediaRecorder: MediaRecorder | null = null;
  private recordedChunks: Blob[] = [];
  private currentAudio: HTMLAudioElement | null = null;
  private audioContext: AudioContext | null = null;
  private activeSourceNode: AudioBufferSourceNode | null = null;
  private isPaused: boolean = false;
  private pauseTime: number = 0;
  private startTime: number = 0;

  // Stored active profiles key
  private readonly PROFILES_KEY = 'ammu_custom_voice_profiles_v1';
  private readonly ACTIVE_VOICE_KEY = 'ammu_active_voice_type_v1';
  private readonly CONSENT_KEY = 'ammu_voice_consent_v1';

  constructor() {
    if (typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.audioContext = new AudioCtx();
      }
    }
  }

  // ==========================================
  // FEATURE 1: PERSONAL VOICE INPUT & RECORDING
  // ==========================================

  public async startRecording(
    onAudioLevel?: (level: number) => void
  ): Promise<void> {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      throw new Error('Microphone recording is not supported in this browser.');
    }

    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    this.recordedChunks = [];

    // Optional audio level visualizer
    if (onAudioLevel && this.audioContext) {
      try {
        if (this.audioContext.state === 'suspended') {
          await this.audioContext.resume();
        }
        const source = this.audioContext.createMediaStreamSource(stream);
        const analyser = this.audioContext.createAnalyser();
        analyser.fftSize = 64;
        source.connect(analyser);

        const dataArray = new Uint8Array(analyser.frequencyBinCount);
        const updateLevel = () => {
          if (this.mediaRecorder && this.mediaRecorder.state === 'recording') {
            analyser.getByteFrequencyData(dataArray);
            const sum = dataArray.reduce((acc, v) => acc + v, 0);
            const avg = sum / dataArray.length;
            onAudioLevel(Math.min(100, Math.round((avg / 128) * 100)));
            requestAnimationFrame(updateLevel);
          }
        };
        requestAnimationFrame(updateLevel);
      } catch (e) {
        console.warn('Audio level monitoring exception:', e);
      }
    }

    const mimeType = MediaRecorder.isTypeSupported('audio/webm')
      ? 'audio/webm'
      : MediaRecorder.isTypeSupported('audio/mp4')
      ? 'audio/mp4'
      : '';

    this.mediaRecorder = mimeType
      ? new MediaRecorder(stream, { mimeType })
      : new MediaRecorder(stream);

    this.mediaRecorder.ondataavailable = (event) => {
      if (event.data && event.data.size > 0) {
        this.recordedChunks.push(event.data);
      }
    };

    this.mediaRecorder.start(100);
  }

  public stopRecording(): Promise<{ blob: Blob; base64: string; durationSec: number }> {
    return new Promise((resolve, reject) => {
      if (!this.mediaRecorder) {
        return reject(new Error('MediaRecorder is not initialized.'));
      }

      this.mediaRecorder.onstop = async () => {
        try {
          const blob = new Blob(this.recordedChunks, {
            type: this.mediaRecorder?.mimeType || 'audio/wav',
          });
          const base64 = await this.blobToBase64(blob);

          // Calculate duration using AudioContext or Audio element
          const durationSec = await this.getAudioDuration(blob);

          // Stop all audio tracks
          this.mediaRecorder?.stream.getTracks().forEach((track) => track.stop());
          this.mediaRecorder = null;

          resolve({ blob, base64, durationSec });
        } catch (e) {
          reject(e);
        }
      };

      this.mediaRecorder.stop();
    });
  }

  public isRecording(): boolean {
    return this.mediaRecorder?.state === 'recording';
  }

  // Read uploaded file (WAV, MP3, M4A)
  public async processUploadedAudio(
    file: File
  ): Promise<{ blob: Blob; base64: string; durationSec: number; format: string }> {
    const validExtensions = ['.wav', '.mp3', '.m4a', '.ogg', '.webm'];
    const fileName = file.name.toLowerCase();
    const isValid = validExtensions.some((ext) => fileName.endsWith(ext));

    if (!isValid) {
      throw new Error('Unsupported format. Please upload a WAV, MP3, or M4A audio file.');
    }

    if (file.size > 25 * 1024 * 1024) {
      throw new Error('File exceeds maximum size limit of 25MB.');
    }

    const base64 = await this.blobToBase64(file);
    const durationSec = await this.getAudioDuration(file);

    return {
      blob: file,
      base64,
      durationSec,
      format: file.type || 'audio/wav',
    };
  }

  // ==========================================
  // FEATURE 2: MY CUSTOM AI VOICE CLONING
  // ==========================================

  public async fetchBackendStatus(): Promise<VoiceBackendStatus> {
    try {
      const res = await fetch('/api/voice/status');
      if (res.ok) {
        return await res.json();
      }
    } catch (e) {
      console.warn('Failed to fetch voice status from server:', e);
    }
    return {
      elevenLabsConfigured: false,
      geminiConfigured: true,
      pricingInfo: {
        elevenlabs: 'ElevenLabs provides photorealistic cloud voice cloning. Starter plan: $5/mo.',
        gemini: 'Gemini 3.8 Flash Lite TTS provides ultra-low latency voice generation with acoustic styling.',
      },
    };
  }

  public async createVoiceProfile(
    voiceName: string,
    audioBase64: string,
    format: string,
    durationSec: number,
    consent: boolean
  ): Promise<VoiceProfile> {
    if (!consent) {
      throw new Error('Consent is required to create your custom AI voice profile.');
    }

    const response = await fetch('/api/voice/clone', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        voiceName,
        audioBase64,
        format,
        durationSec,
        consent,
      }),
    });

    if (!response.ok) {
      const err = await response.json();
      throw new Error(err.error || 'Failed to create custom voice clone profile.');
    }

    const data = await response.json();
    const profile: VoiceProfile = {
      ...data.profile,
      audioSampleUrl: audioBase64,
    };

    // Store in local storage
    this.saveProfileLocally(profile);
    this.saveConsent(consent);
    return profile;
  }

  public getSavedProfiles(): VoiceProfile[] {
    try {
      const raw = localStorage.getItem(this.PROFILES_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  }

  public getActiveProfile(): VoiceProfile | null {
    const list = this.getSavedProfiles();
    return list.length > 0 ? list[0] : null;
  }

  public saveProfileLocally(profile: VoiceProfile): void {
    const current = this.getSavedProfiles();
    const updated = [profile, ...current.filter((p) => p.id !== profile.id)];
    localStorage.setItem(this.PROFILES_KEY, JSON.stringify(updated));
  }

  public async deleteProfile(profileId: string): Promise<void> {
    try {
      await fetch(`/api/voice/profile/${profileId}`, { method: 'DELETE' });
    } catch (e) {
      console.warn('Backend delete voice profile warning:', e);
    }
    const current = this.getSavedProfiles();
    const updated = current.filter((p) => p.id !== profileId);
    localStorage.setItem(this.PROFILES_KEY, JSON.stringify(updated));
  }

  public saveActiveVoiceSelection(voice: VoiceSelectionType): void {
    localStorage.setItem(this.ACTIVE_VOICE_KEY, voice);
  }

  public getActiveVoiceSelection(): VoiceSelectionType {
    const val = localStorage.getItem(this.ACTIVE_VOICE_KEY) as VoiceSelectionType;
    return val || 'my-voice';
  }

  public saveConsent(consent: boolean): void {
    localStorage.setItem(
      this.CONSENT_KEY,
      JSON.stringify({
        hasConsented: consent,
        consentTimestamp: new Date().toISOString(),
        consentStatement:
          'I confirm that this voice sample belongs to me and grant AMMU permission to synthesize responses in my voice.',
      })
    );
  }

  public hasUserConsented(): boolean {
    try {
      const data = localStorage.getItem(this.CONSENT_KEY);
      return data ? JSON.parse(data).hasConsented : false;
    } catch {
      return false;
    }
  }

  // ==========================================
  // FEATURE 3 & 4: SPEAK IN MY VOICE & PLAYBACK
  // ==========================================

  public async speakText(
    text: string,
    voiceType: VoiceSelectionType = 'my-voice',
    speed: number = 1.0,
    pitch: number = 1.0,
    onStart?: () => void,
    onEnded?: () => void,
    onError?: (err: any) => void
  ): Promise<void> {
    this.stopPlayback();

    const activeProfile = this.getActiveProfile();

    try {
      const res = await fetch('/api/voice/generate-speech', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          text,
          voiceType,
          profile: activeProfile,
          speed,
          pitch,
        }),
      });

      if (!res.ok) {
        throw new Error(`Server speech synthesis returned ${res.status}`);
      }

      const data = await res.json();

      // If backend returned audio stream (ElevenLabs or Gemini 3.8 Flash TTS)
      if (data.audio) {
        const audioSrc = `data:${data.format || 'audio/wav'};base64,${data.audio}`;
        this.playAudioSource(audioSrc, speed, onStart, onEnded, onError);
        return;
      }

      // If fallback client synthesis is signaled
      if (data.fallbackClient) {
        this.speakWithClientDsp(
          text,
          voiceType,
          data.detectedLanguage,
          data.pitch || pitch,
          speed,
          onStart,
          onEnded,
          onError
        );
        return;
      }
    } catch (err) {
      console.warn('Server TTS request failed, falling back to client engine:', err);
      // Fallback
      this.speakWithClientDsp(
        text,
        voiceType,
        /[\u0B80-\u0BFF]/.test(text) ? 'ta' : 'en',
        voiceType === 'my-voice' ? 1.0 : voiceType === 'female' ? 1.25 : 0.85,
        speed,
        onStart,
        onEnded,
        onError
      );
    }
  }

  public playAudioSource(
    src: string,
    speed: number = 1.0,
    onStart?: () => void,
    onEnded?: () => void,
    onError?: (err: any) => void
  ): void {
    this.stopPlayback();

    const audio = new Audio(src);
    this.currentAudio = audio;
    audio.playbackRate = speed;

    audio.onplay = () => {
      this.isPaused = false;
      if (onStart) onStart();
    };

    audio.onended = () => {
      this.isPaused = false;
      this.currentAudio = null;
      if (onEnded) onEnded();
    };

    audio.onerror = (e) => {
      this.isPaused = false;
      this.currentAudio = null;
      if (onError) onError(e);
    };

    audio.play().catch((err) => {
      if (onError) onError(err);
    });
  }

  public pausePlayback(): void {
    if (this.currentAudio && !this.currentAudio.paused) {
      this.currentAudio.pause();
      this.isPaused = true;
    } else if (window.speechSynthesis && window.speechSynthesis.speaking) {
      window.speechSynthesis.pause();
      this.isPaused = true;
    }
  }

  public resumePlayback(): void {
    if (this.currentAudio && this.currentAudio.paused) {
      this.currentAudio.play();
      this.isPaused = false;
    } else if (window.speechSynthesis && window.speechSynthesis.paused) {
      window.speechSynthesis.resume();
      this.isPaused = false;
    }
  }

  public stopPlayback(): void {
    if (this.currentAudio) {
      this.currentAudio.pause();
      this.currentAudio.currentTime = 0;
      this.currentAudio = null;
    }
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    this.isPaused = false;
  }

  public isSpeaking(): boolean {
    const audioSpeaking = Boolean(this.currentAudio && !this.currentAudio.paused);
    const synthSpeaking = typeof window !== 'undefined' && Boolean(window.speechSynthesis?.speaking);
    return audioSpeaking || synthSpeaking;
  }

  public isPlaybackPaused(): boolean {
    return this.isPaused;
  }

  // Client speech synthesis fallback with pitch-shift mapping for custom voice
  private speakWithClientDsp(
    text: string,
    voiceType: VoiceSelectionType,
    lang: 'ta' | 'en',
    pitch: number,
    speed: number,
    onStart?: () => void,
    onEnded?: () => void,
    onError?: (err: any) => void
  ): void {
    if (!('speechSynthesis' in window)) {
      if (onError) onError('SpeechSynthesis is unavailable.');
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = lang === 'ta' ? 'ta-IN' : 'en-US';

    // Strictly apply distinct vocal properties so "My Voice" is NEVER generic female:
    if (voiceType === 'my-voice') {
      utterance.pitch = Math.max(0.7, Math.min(1.4, pitch));
      utterance.rate = speed;
      // Find a natural neutral voice to apply acoustic mapping
      const voices = window.speechSynthesis.getVoices();
      const matched = voices.find((v) => v.lang.startsWith(lang));
      if (matched) utterance.voice = matched;
    } else if (voiceType === 'female') {
      utterance.pitch = 1.25;
      utterance.rate = speed;
      const voices = window.speechSynthesis.getVoices();
      const femaleVoice = voices.find(
        (v) =>
          v.lang.startsWith(lang) &&
          ['female', 'samantha', 'victoria', 'kavya', 'priya', 'karen', 'zira'].some((k) =>
            v.name.toLowerCase().includes(k)
          )
      );
      if (femaleVoice) utterance.voice = femaleVoice;
    } else if (voiceType === 'male') {
      utterance.pitch = 0.82;
      utterance.rate = speed;
      const voices = window.speechSynthesis.getVoices();
      const maleVoice = voices.find(
        (v) =>
          v.lang.startsWith(lang) &&
          ['male', 'daniel', 'rishi', 'david', 'alex', 'george'].some((k) =>
            v.name.toLowerCase().includes(k)
          )
      );
      if (maleVoice) utterance.voice = maleVoice;
    }

    utterance.onstart = () => {
      if (onStart) onStart();
    };

    utterance.onend = () => {
      if (onEnded) onEnded();
    };

    utterance.onerror = (e) => {
      if (onError) onError(e);
    };

    window.speechSynthesis.speak(utterance);
  }

  // Utilities
  private blobToBase64(blob: Blob): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  }

  private getAudioDuration(blob: Blob): Promise<number> {
    return new Promise((resolve) => {
      const audio = new Audio();
      audio.src = URL.createObjectURL(blob);
      audio.onloadedmetadata = () => {
        const d = Math.round(audio.duration);
        URL.revokeObjectURL(audio.src);
        resolve(isNaN(d) ? 5 : d);
      };
      audio.onerror = () => resolve(5);
    });
  }
}

export const voiceCloneService = new VoiceCloneService();
