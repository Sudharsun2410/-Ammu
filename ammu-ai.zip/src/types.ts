export type AppLanguage = 'en' | 'ta';

export type ScreenType = 'home' | 'chatbot' | 'voice' | 'voiceagent' | 'imagegen' | 'projects' | 'login';

export interface UserProfile {
  name: string;
  email: string;
  avatar: string;
  isLoggedIn: boolean;
  role: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
  imageGrid?: string[];
  audioData?: string;
  voiceUsed?: string;
  detectedLang?: 'en' | 'ta';
}

export type ProjectCategory = 'image' | 'doc' | 'chat' | 'audio';

export interface ProjectItem {
  id: string;
  title: string;
  category: ProjectCategory;
  description: string;
  createdAt: string;
  previewUrl?: string;
  content?: string;
  synced: boolean;
  size?: string;
  audioDataUrl?: string;
}

export type VoiceSelectionType = 'my-voice' | 'female' | 'male';

export interface VoiceCloneConsent {
  hasConsented: boolean;
  consentTimestamp?: string;
  consentStatement: string;
}

export interface VoiceProfile {
  id: string;
  name: string;
  createdAt: string;
  audioSampleUrl?: string;
  audioDurationSec?: number;
  sampleFormat?: string;
  cloneProvider: 'elevenlabs' | 'gemini_custom';
  externalVoiceId?: string;
  isTrained: boolean;
  trainingStatus: 'idle' | 'recording' | 'uploaded' | 'training' | 'ready' | 'failed';
  statusMessage?: string;
  acousticFeatures?: {
    pitchShift: number;
    formantRatio: number;
    tempo: number;
    detectedGender?: string;
  };
}

export interface VoiceAssistantConfig {
  selectedVoice: VoiceSelectionType;
  femaleVoice: boolean; // backward compatibility
  pitch: number; // 0.6 - 1.5
  rate: number;  // 0.8 - 1.3
  volume: number;
  lang: 'en-US' | 'ta-IN' | 'auto';
  autoDetectLanguage: boolean;
  activeProfile?: VoiceProfile | null;
  hasCustomVoice: boolean;
  customVoiceName?: string;
  customVoiceAudioUrl?: string;
}

export interface VoiceConversationTurn {
  id: string;
  userQuery: string;
  assistantResponse: string;
  timestamp: string;
  detectedLang: 'en' | 'ta';
  voiceUsed: string;
  audioBase64?: string;
  audioDurationSec?: number;
}

export interface VoiceBackendStatus {
  elevenLabsConfigured: boolean;
  geminiConfigured: boolean;
  pricingInfo: {
    elevenlabs: string;
    gemini: string;
  };
}

export interface FirebaseSyncState {
  isConfigured: boolean;
  status: 'offline' | 'synced' | 'syncing' | 'error';
  lastSyncedAt?: string;
  pendingChangesCount: number;
  projectId: string;
}
