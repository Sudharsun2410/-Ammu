import React, { useEffect, useRef } from 'react';

interface GlowingOrbProps {
  isListening?: boolean;
  isSpeaking?: boolean;
  size?: number;
}

export const GlowingOrb: React.FC<GlowingOrbProps> = ({
  isListening = false,
  isSpeaking = false,
  size = 280,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let time = 0;

    // Particles for sparkling electric filaments
    const particles: { angle: number; radius: number; speed: number; size: number; alpha: number; hue: number }[] = [];
    for (let i = 0; i < 45; i++) {
      particles.push({
        angle: Math.random() * Math.PI * 2,
        radius: 20 + Math.random() * (size * 0.38),
        speed: (Math.random() * 0.02 + 0.01) * (Math.random() > 0.5 ? 1 : -1),
        size: Math.random() * 2.5 + 1,
        alpha: Math.random() * 0.8 + 0.2,
        hue: Math.random() > 0.6 ? 285 : Math.random() > 0.3 ? 310 : 265, // Purples & Magentas
      });
    }

    const render = () => {
      time += isListening ? 0.035 : isSpeaking ? 0.045 : 0.02;
      ctx.clearRect(0, 0, size, size);

      const centerX = size / 2;
      const centerY = size / 2;
      const baseRadius = size * 0.36;

      // Pulse multiplier
      const pulse = isListening 
        ? Math.sin(time * 3) * 6 
        : isSpeaking 
        ? Math.sin(time * 5) * 8 
        : Math.sin(time * 1.5) * 3;

      // Outer Deep Purple Glow
      const outerGlow = ctx.createRadialGradient(
        centerX,
        centerY,
        baseRadius * 0.3,
        centerX,
        centerY,
        baseRadius * 1.6 + pulse
      );
      outerGlow.addColorStop(0, 'rgba(192, 38, 211, 0.45)');
      outerGlow.addColorStop(0.3, 'rgba(147, 51, 234, 0.35)');
      outerGlow.addColorStop(0.65, 'rgba(88, 28, 135, 0.2)');
      outerGlow.addColorStop(1, 'rgba(15, 7, 26, 0)');

      ctx.fillStyle = outerGlow;
      ctx.beginPath();
      ctx.arc(centerX, centerY, baseRadius * 1.6 + pulse, 0, Math.PI * 2);
      ctx.fill();

      // Swirling Energetic Rings
      const ringCount = 7;
      for (let r = 0; r < ringCount; r++) {
        ctx.save();
        ctx.translate(centerX, centerY);
        const rotation = time * (0.4 + r * 0.15) * (r % 2 === 0 ? 1 : -1);
        ctx.rotate(rotation);

        const rx = baseRadius * (0.85 + Math.sin(time + r) * 0.1);
        const ry = baseRadius * (0.55 + Math.cos(time * 0.8 + r) * 0.15);

        ctx.beginPath();
        ctx.ellipse(0, 0, Math.max(10, rx), Math.max(10, ry), (r * Math.PI) / ringCount, 0, Math.PI * 2);
        ctx.lineWidth = r === 0 ? 3 : 1.5;
        ctx.strokeStyle = r % 2 === 0 
          ? `rgba(232, 121, 249, ${0.45 + Math.sin(time * 2 + r) * 0.2})` 
          : `rgba(192, 132, 252, ${0.4 + Math.cos(time * 2 + r) * 0.2})`;
        ctx.shadowColor = '#d946ef';
        ctx.shadowBlur = 12;
        ctx.stroke();
        ctx.restore();
      }

      // Mid Plasma Sphere
      const midGrad = ctx.createRadialGradient(
        centerX,
        centerY,
        0,
        centerX,
        centerY,
        baseRadius * 0.95
      );
      midGrad.addColorStop(0, 'rgba(255, 255, 255, 0.95)');
      midGrad.addColorStop(0.2, 'rgba(240, 171, 252, 0.9)');
      midGrad.addColorStop(0.45, 'rgba(192, 38, 211, 0.7)');
      midGrad.addColorStop(0.75, 'rgba(126, 34, 206, 0.5)');
      midGrad.addColorStop(1, 'rgba(88, 28, 135, 0)');

      ctx.fillStyle = midGrad;
      ctx.beginPath();
      ctx.arc(centerX, centerY, baseRadius * 0.95, 0, Math.PI * 2);
      ctx.fill();

      // Glowing Electric Core
      const coreGrad = ctx.createRadialGradient(
        centerX,
        centerY,
        0,
        centerX,
        centerY,
        baseRadius * 0.4
      );
      coreGrad.addColorStop(0, '#ffffff');
      coreGrad.addColorStop(0.3, '#f5d0fe');
      coreGrad.addColorStop(0.7, 'rgba(217, 70, 239, 0.9)');
      coreGrad.addColorStop(1, 'rgba(147, 51, 234, 0)');

      ctx.fillStyle = coreGrad;
      ctx.beginPath();
      ctx.arc(centerX, centerY, baseRadius * 0.4, 0, Math.PI * 2);
      ctx.fill();

      // Sparkling Orbiting Particles
      particles.forEach((p) => {
        p.angle += p.speed;
        const px = centerX + Math.cos(p.angle) * p.radius;
        const py = centerY + Math.sin(p.angle) * (p.radius * 0.75);

        ctx.fillStyle = `hsla(${p.hue}, 95%, 75%, ${p.alpha})`;
        ctx.shadowColor = `hsl(${p.hue}, 100%, 70%)`;
        ctx.shadowBlur = 8;
        ctx.beginPath();
        ctx.arc(px, py, p.size, 0, Math.PI * 2);
        ctx.fill();
      });

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [isListening, isSpeaking, size]);

  return (
    <div className="relative flex items-center justify-center">
      {/* Outer ambient glow halo */}
      <div 
        className="absolute rounded-full pointer-events-none filter blur-2xl opacity-60 animate-pulse-slow"
        style={{
          width: size * 1.1,
          height: size * 1.1,
          background: 'radial-gradient(circle, rgba(168,85,247,0.5) 0%, rgba(192,38,211,0.2) 50%, transparent 75%)',
        }}
      />
      
      <canvas
        ref={canvasRef}
        width={size}
        height={size}
        className="relative z-10 drop-shadow-[0_0_30px_rgba(168,85,247,0.6)]"
      />
    </div>
  );
};
