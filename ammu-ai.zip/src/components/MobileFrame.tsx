import React from 'react';
import { Wifi, Signal, Battery, ChevronLeft, Menu } from 'lucide-react';

interface MobileFrameProps {
  children: React.ReactNode;
  title?: string;
  showBack?: boolean;
  onBack?: () => void;
  onMenuClick?: () => void;
  isStandalonePhone?: boolean;
}

export const MobileFrame: React.FC<MobileFrameProps> = ({
  children,
  title,
  showBack = false,
  onBack,
  onMenuClick,
  isStandalonePhone = true,
}) => {
  return (
    <div className={`relative mx-auto flex flex-col overflow-hidden bg-[#0a0514] text-white select-none ${
      isStandalonePhone 
        ? 'w-full max-w-[390px] h-[812px] rounded-[48px] border-[6px] border-[#221438] shadow-[0_25px_60px_-15px_rgba(147,51,234,0.35),0_0_0_1px_rgba(168,85,247,0.25)] ring-1 ring-white/10'
        : 'w-full h-full rounded-3xl border border-purple-500/20 shadow-2xl'
    }`}>
      {/* Dynamic Ambient Background Nebulas */}
      <div className="absolute -top-24 -left-20 w-64 h-64 bg-purple-700/20 rounded-full blur-[80px] pointer-events-none" />
      <div className="absolute top-1/2 -right-24 w-72 h-72 bg-fuchsia-700/15 rounded-full blur-[90px] pointer-events-none" />
      <div className="absolute -bottom-20 left-1/3 w-64 h-64 bg-indigo-800/20 rounded-full blur-[85px] pointer-events-none" />

      {/* Android Top Status Bar */}
      <div className="relative z-30 flex items-center justify-between px-7 pt-3.5 pb-2 text-xs font-medium text-slate-300">
        <span className="font-semibold tracking-tight text-[13px] text-white">9:30 PM</span>
        
        {/* Android Camera Punch Hole */}
        <div className="w-4 h-4 bg-black/90 rounded-full border border-purple-900/40 shadow-inner flex items-center justify-center">
          <div className="w-1.5 h-1.5 bg-[#140b24] rounded-full" />
        </div>

        {/* Status Indicators */}
        <div className="flex items-center gap-1.5 text-slate-300">
          <Signal className="w-3.5 h-3.5" />
          <Wifi className="w-3.5 h-3.5" />
          <div className="flex items-center gap-0.5">
            <Battery className="w-4 h-4 text-white" />
          </div>
        </div>
      </div>

      {/* Optional In-Frame Header (Back button, Title, Menu button) */}
      {title !== undefined && (
        <div className="relative z-30 flex items-center justify-between px-5 py-2.5">
          {showBack ? (
            <button
              onClick={onBack}
              className="w-10 h-10 rounded-full bg-[#1b0f30]/80 border border-purple-500/25 flex items-center justify-center text-white/90 hover:text-white hover:border-purple-400 transition-colors shadow-lg active:scale-95"
              aria-label="Go back"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
          ) : (
            <div className="w-10 h-10" />
          )}

          <h1 className="text-base font-semibold tracking-tight text-white drop-shadow-sm">
            {title}
          </h1>

          <button
            onClick={onMenuClick}
            className="w-10 h-10 rounded-full bg-[#1b0f30]/80 border border-purple-500/25 flex items-center justify-center text-white/90 hover:text-white hover:border-purple-400 transition-colors shadow-lg active:scale-95"
            aria-label="Open menu"
          >
            <Menu className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Screen Body */}
      <div className="relative z-20 flex-1 flex flex-col overflow-y-auto overflow-x-hidden px-4 pb-2">
        {children}
      </div>

      {/* Android Bottom Home Navigation Bar Bar */}
      <div className="relative z-30 flex justify-center py-2.5 bg-gradient-to-t from-[#0a0514] to-transparent">
        <div className="w-32 h-1 bg-white/40 rounded-full shadow-sm" />
      </div>
    </div>
  );
};
