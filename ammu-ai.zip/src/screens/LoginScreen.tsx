import React, { useState } from 'react';
import { 
  Lock, 
  Mail, 
  Sparkles, 
  Fingerprint, 
  Globe, 
  ArrowRight,
  ShieldCheck
} from 'lucide-react';
import { AppLanguage, UserProfile } from '../types';
import { translations } from '../i18n/translations';

interface LoginScreenProps {
  language: AppLanguage;
  onLanguageChange: (lang: AppLanguage) => void;
  onLoginSuccess: (user: UserProfile) => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({
  language,
  onLanguageChange,
  onLoginSuccess,
}) => {
  const t = translations[language];
  const [email, setEmail] = useState('jack.johnson@ammu.ai');
  const [password, setPassword] = useState('••••••••••••');
  const [isAuthenticating, setIsAuthenticating] = useState(false);

  const handleAuth = (isBiometric = false) => {
    setIsAuthenticating(true);
    setTimeout(() => {
      onLoginSuccess({
        name: 'Jack Johnson',
        email: email || 'jack.johnson@ammu.ai',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80',
        isLoggedIn: true,
        role: 'Pro Member',
      });
      setIsAuthenticating(false);
    }, 900);
  };

  return (
    <div className="flex flex-col h-full justify-between pb-3 text-white">
      {/* Top bar with language switcher */}
      <div className="flex items-center justify-between py-1">
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-purple-950/60 border border-purple-500/25 text-[11px] text-purple-300">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>Firebase Auth</span>
        </div>

        <button
          onClick={() => onLanguageChange(language === 'en' ? 'ta' : 'en')}
          className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#1b0f30] border border-purple-500/30 text-xs font-semibold text-purple-200 hover:text-white hover:border-purple-400 transition-all active:scale-95 shadow-md"
        >
          <Globe className="w-3.5 h-3.5 text-fuchsia-400" />
          <span>{language === 'en' ? 'தமிழ்' : 'English'}</span>
        </button>
      </div>

      {/* Center Branding & Form */}
      <div className="my-auto space-y-5 px-2">
        {/* AMMU Glowing Orb Emblem */}
        <div className="flex flex-col items-center text-center">
          <div className="relative w-20 h-20 rounded-full p-[2px] bg-gradient-to-tr from-fuchsia-500 via-purple-600 to-indigo-600 shadow-[0_0_35px_rgba(168,85,247,0.65)] mb-3">
            <div className="w-full h-full rounded-full bg-[#110622] flex items-center justify-center overflow-hidden">
              <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-fuchsia-400 to-purple-400 animate-pulse-slow shadow-[0_0_15px_#d946ef] flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
            </div>
          </div>
          <h2 className="text-2xl font-extrabold tracking-tight text-white">
            {t.appName}
          </h2>
          <p className="text-xs text-slate-300 max-w-xs mt-1 leading-relaxed">
            {t.loginSubtitle}
          </p>
        </div>

        {/* Input fields */}
        <div className="space-y-3">
          <div className="flex items-center gap-2.5 px-3.5 py-2.5 rounded-2xl bg-[#170c2a]/90 border border-purple-500/30 focus-within:border-purple-400 transition-colors">
            <Mail className="w-4 h-4 text-purple-400 shrink-0" />
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Email address"
              className="w-full bg-transparent text-xs text-white placeholder-slate-400 outline-none"
            />
          </div>

          <div className="flex items-center gap-2.5 px-3.5 py-2.5 rounded-2xl bg-[#170c2a]/90 border border-purple-500/30 focus-within:border-purple-400 transition-colors">
            <Lock className="w-4 h-4 text-purple-400 shrink-0" />
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Password"
              className="w-full bg-transparent text-xs text-white placeholder-slate-400 outline-none"
            />
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2.5 pt-2">
          <button
            onClick={() => handleAuth(false)}
            disabled={isAuthenticating}
            className="w-full py-3 rounded-2xl bg-gradient-to-r from-purple-600 via-fuchsia-600 to-indigo-600 font-semibold text-xs text-white flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(168,85,247,0.5)] active:scale-98 transition-all disabled:opacity-50"
          >
            <span>{isAuthenticating ? 'Signing in...' : t.signInBtn}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => handleAuth(true)}
            className="w-full py-2.5 rounded-2xl bg-[#190b2e]/90 border border-purple-500/30 font-medium text-xs text-purple-200 hover:text-white hover:border-purple-400 flex items-center justify-center gap-2 transition-all active:scale-98"
          >
            <Fingerprint className="w-4 h-4 text-fuchsia-400" />
            <span>{language === 'ta' ? 'பயோமெட்ரிக் மூலம் தொடர்க' : 'Quick Biometric Sign-In'}</span>
          </button>
        </div>
      </div>

      {/* Footer Info */}
      <div className="text-center pt-2">
        <p className="text-[10px] text-slate-400">
          {t.offlineNotice}
        </p>
      </div>
    </div>
  );
};
