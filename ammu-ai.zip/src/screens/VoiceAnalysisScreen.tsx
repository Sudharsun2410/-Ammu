import React, { useState, useEffect, useRef } from 'react';
import { 
  ChevronLeft, 
  Menu, 
  RotateCcw, 
  Mic, 
  X, 
  Play,
  Pause,
  Square,
  Volume2, 
  Sliders, 
  Sparkles, 
  History, 
  User, 
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { AppLanguage, VoiceAssistantConfig, VoiceConversationTurn, VoiceSelectionType } from '../types';
import { translations } from '../i18n/translations';
import { GlowingOrb } from '../components/GlowingOrb';
import { ttsService } from '../services/ttsService';
import { geminiService } from '../services/geminiService';
import { voiceCloneService } from '../services/voiceCloneService';

interface VoiceAnalysisScreenProps {
  language: AppLanguage;
  onBack: () => void;
  onOpenMenu: () => void;
  onOpenVoiceSettings: () => void;
  onCommandGenerated: (commandText: string) => void;
  voiceConfig: VoiceAssistantConfig;
  onUpdateVoiceConfig: (config: VoiceAssistantConfig) => void;
  onOpenVoiceAgent?: () => void;
}

export const VoiceAnalysisScreen: React.FC<VoiceAnalysisScreenProps> = ({
  language,
  onBack,
  onOpenMenu,
  onOpenVoiceSettings,
  onCommandGenerated,
  voiceConfig,
  onUpdateVoiceConfig,
  onOpenVoiceAgent,
}) => {
  const t = translations[language];

  // Assistant Status: 'idle' | 'listening' | 'thinking' | 'speaking' | 'paused'
  const [assistantStatus, setAssistantStatus] = useState<
    'idle' | 'listening' | 'thinking' | 'speaking' | 'paused'
  >('idle');

  const [transcript, setTranscript] = useState('');
  const [statusMessage, setStatusMessage] = useState(t.listening);
  const [permissionError, setPermissionError] = useState<string | null>(null);

  // Active Voice Selection ('my-voice' | 'female' | 'male')
  const [selectedVoice, setSelectedVoice] = useState<VoiceSelectionType>(
    voiceConfig.selectedVoice || voiceCloneService.getActiveVoiceSelection() || 'my-voice'
  );

  // Voice Conversation History
  const [history, setHistory] = useState<VoiceConversationTurn[]>([]);
  const [showHistory, setShowHistory] = useState(false);

  const recognitionRef = useRef<{ stop: () => void } | null>(null);
  const activeProfile = voiceCloneService.getActiveProfile();

  // Initial welcome and greeting on mount
  useEffect(() => {
    setSelectedVoice(voiceConfig.selectedVoice || 'my-voice');

    const greeting =
      language === 'ta'
        ? selectedVoice === 'my-voice' && activeProfile
          ? `வணக்கம்! நான் உங்கள் சொந்த குரலில் பேசும் AMMU AI உதவியாளர். உங்களுக்கு என்ன உதவி வேண்டும்?`
          : `அம்மு குரல் உதவியாளர் கேட்கிறது. உங்கள் கட்டளையைக் கூறுங்கள்.`
        : selectedVoice === 'my-voice' && activeProfile
        ? `Hello! I am AMMU, ready to assist you in your own custom voice. What would you like to create?`
        : `AMMU Voice Assistant is active. What would you like to create?`;

    setStatusMessage(greeting);
    setAssistantStatus('speaking');

    ttsService.speak(
      greeting,
      language,
      { ...voiceConfig, selectedVoice },
      () => setAssistantStatus('speaking'),
      () => {
        setAssistantStatus('idle');
        startListening();
      },
      (err) => {
        console.warn('Speech error on greeting:', err);
        setAssistantStatus('idle');
        startListening();
      }
    );

    return () => {
      ttsService.stop();
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, [language]);

  // Start Speech Recognition
  const startListening = async () => {
    setPermissionError(null);
    ttsService.stop();

    setAssistantStatus('listening');
    setStatusMessage(language === 'ta' ? 'கவனித்துக் கொண்டிருக்கிறது...' : t.listening);

    recognitionRef.current = ttsService.startSpeechRecognition(
      language,
      (text) => {
        setTranscript(text);
        handleVoiceCommand(text);
      },
      (err) => {
        console.warn('Speech recognition status:', err);
        if (err.includes('denied') || err.includes('not-allowed')) {
          setPermissionError('Microphone permission denied. Please allow microphone access.');
        }
        setAssistantStatus('idle');
        setStatusMessage(t.tapToSpeak);
      },
      () => {
        if (assistantStatus === 'listening') {
          setAssistantStatus('idle');
        }
      }
    );
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      recognitionRef.current = null;
    }
    if (assistantStatus === 'listening') {
      setAssistantStatus('idle');
    }
  };

  const toggleListening = () => {
    if (assistantStatus === 'listening') {
      stopListening();
    } else {
      if (assistantStatus === 'speaking' || assistantStatus === 'paused') {
        ttsService.stop();
      }
      startListening();
    }
  };

  // Process User Command: STT -> Gemini AI Reasoning -> Selected Voice TTS
  const handleVoiceCommand = async (command: string) => {
    stopListening();
    setAssistantStatus('thinking');
    setStatusMessage(language === 'ta' ? 'சிந்திக்கிறது...' : 'AMMU is thinking...');

    try {
      // 1. Generate text response from backend Gemini
      const response = await geminiService.generateChatResponse(command, [], language);
      const replyText = response.text || '';

      // 2. Add to voice conversation turn history
      const turn: VoiceConversationTurn = {
        id: 'turn-' + Date.now(),
        userQuery: command,
        assistantResponse: replyText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        detectedLang: /[\u0B80-\u0BFF]/.test(replyText) ? 'ta' : 'en',
        voiceUsed:
          selectedVoice === 'my-voice'
            ? activeProfile
              ? `My Voice (${activeProfile.name})`
              : 'My Voice (Calibrated)'
            : selectedVoice === 'female'
            ? 'Female AI Voice'
            : 'Male AI Voice',
      };
      setHistory((prev) => [turn, ...prev]);

      // 3. Generate Speech in Selected Voice (My Voice / Female / Male)
      setAssistantStatus('speaking');
      setStatusMessage(
        selectedVoice === 'my-voice'
          ? language === 'ta'
            ? 'உங்கள் சொந்த குரலில் பேசுகிறது...'
            : 'Speaking in your custom voice...'
          : language === 'ta'
          ? 'பதிலளிக்கிறது...'
          : 'Speaking...'
      );

      await ttsService.speak(
        replyText,
        language,
        { ...voiceConfig, selectedVoice },
        () => setAssistantStatus('speaking'),
        () => {
          setAssistantStatus('idle');
          setStatusMessage(language === 'ta' ? 'முடிந்தது. மீண்டும் பேச தொடவும்.' : 'Tap mic to speak again.');
        },
        (err) => {
          console.error('Speech synthesis playback error:', err);
          setAssistantStatus('idle');
          setStatusMessage(t.tapToSpeak);
        }
      );
    } catch (err: any) {
      console.error('Command processing error:', err);
      setAssistantStatus('idle');
      setStatusMessage(t.listening);
    }
  };

  // Stop current playback
  const handleStopPlayback = () => {
    ttsService.stop();
    setAssistantStatus('idle');
    setStatusMessage(t.tapToSpeak);
  };

  // Pause / Resume playback
  const handleTogglePause = () => {
    if (assistantStatus === 'speaking') {
      ttsService.pause();
      setAssistantStatus('paused');
      setStatusMessage('Playback paused');
    } else if (assistantStatus === 'paused') {
      ttsService.resume();
      setAssistantStatus('speaking');
      setStatusMessage('Resuming speech...');
    }
  };

  // Replay latest assistant response
  const handleReplayLatest = () => {
    if (history.length === 0) return;
    const latest = history[0];
    setAssistantStatus('speaking');
    setStatusMessage(
      selectedVoice === 'my-voice' ? 'Replaying in your voice...' : 'Replaying response...'
    );

    ttsService.speak(
      latest.assistantResponse,
      language,
      { ...voiceConfig, selectedVoice },
      () => setAssistantStatus('speaking'),
      () => {
        setAssistantStatus('idle');
        setStatusMessage(t.tapToSpeak);
      }
    );
  };

  // Voice Selection Quick Toggle
  const handleVoiceTypeChange = (type: VoiceSelectionType) => {
    setSelectedVoice(type);
    voiceCloneService.saveActiveVoiceSelection(type);
    const updated = { ...voiceConfig, selectedVoice: type, femaleVoice: type === 'female' };
    onUpdateVoiceConfig(updated);
  };

  const handleReset = () => {
    stopListening();
    ttsService.stop();
    setAssistantStatus('idle');
    setTranscript('');
    setStatusMessage(t.listening);
    setTimeout(() => startListening(), 300);
  };

  return (
    <div className="flex flex-col h-full justify-between pb-2 text-white">
      {/* Top Header Row matching screenshot */}
      <div className="flex items-center justify-between py-1 mb-1">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full bg-[#1b0f30]/90 border border-purple-500/25 flex items-center justify-center text-white/90 hover:text-white hover:border-purple-400 transition-all shadow-md active:scale-95"
          aria-label="Back"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>

        <h2 className="text-[16px] font-bold tracking-tight text-white flex items-center gap-1.5">
          <Sparkles className="w-4 h-4 text-fuchsia-400" />
          <span>{t.voiceAnalysisTitle}</span>
        </h2>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setShowHistory(!showHistory)}
            className={`w-9 h-9 rounded-full border flex items-center justify-center transition-all ${
              showHistory
                ? 'bg-purple-600 border-purple-300 text-white shadow-[0_0_10px_rgba(168,85,247,0.5)]'
                : 'bg-[#1b0f30]/90 border-purple-500/25 text-slate-300 hover:text-white'
            }`}
            title="Voice Conversation History"
          >
            <History className="w-4 h-4" />
          </button>

          <button
            onClick={onOpenMenu}
            className="w-10 h-10 rounded-full bg-[#1b0f30]/90 border border-purple-500/25 flex items-center justify-center text-white/90 hover:text-white hover:border-purple-400 transition-all shadow-md active:scale-95"
            aria-label="Menu"
          >
            <Menu className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Voice Selection Pill Bar (FEATURE 3) */}
      <div className="flex items-center justify-center gap-1 p-1 rounded-full bg-[#180a2f]/90 border border-purple-500/25 mb-1 text-[11px]">
        {[
          { id: 'my-voice', label: activeProfile ? activeProfile.name : 'My Voice', icon: User },
          { id: 'female', label: 'Female AI', icon: Sparkles },
          { id: 'male', label: 'Male AI', icon: Volume2 },
        ].map((item) => {
          const Icon = item.icon;
          const isSelected = selectedVoice === item.id;
          return (
            <button
              key={item.id}
              onClick={() => handleVoiceTypeChange(item.id as VoiceSelectionType)}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-full transition-all truncate max-w-[110px] ${
                isSelected
                  ? 'bg-gradient-to-r from-purple-600 to-fuchsia-600 text-white font-bold shadow-[0_0_10px_rgba(168,85,247,0.5)]'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Icon className="w-3 h-3 shrink-0" />
              <span className="truncate">{item.label}</span>
            </button>
          );
        })}
      </div>

      {/* Main Center Area: Status + Glowing Plasma Orb */}
      <div className="flex-1 flex flex-col items-center justify-center -mt-1">
        {/* Permission warning if any */}
        {permissionError && (
          <div className="mb-2 px-3 py-1.5 rounded-xl bg-rose-950/80 border border-rose-500/30 text-[11px] text-rose-200 flex items-center gap-1.5">
            <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
            <span>{permissionError}</span>
          </div>
        )}

        {/* Dynamic Status text: Listening... / Thinking... / Speaking in My Voice... */}
        <div className="flex items-center gap-2 mb-2 px-3.5 py-1.5 rounded-full bg-[#1d0d36]/90 border border-purple-500/30 shadow-md">
          <span
            className={`w-2 h-2 rounded-full ${
              assistantStatus === 'listening'
                ? 'bg-fuchsia-400 animate-ping'
                : assistantStatus === 'thinking'
                ? 'bg-amber-400 animate-pulse'
                : assistantStatus === 'speaking'
                ? 'bg-emerald-400 animate-pulse'
                : 'bg-purple-400'
            }`}
          />
          <span className="text-[12px] font-semibold text-purple-200 tracking-wide truncate max-w-[240px]">
            {statusMessage}
          </span>
        </div>

        {/* Centerpiece Glowing Plasma Orb matching reference */}
        <div className="relative my-2 cursor-pointer" onClick={toggleListening}>
          <GlowingOrb
            isListening={assistantStatus === 'listening'}
            isSpeaking={assistantStatus === 'speaking'}
            size={230}
          />
        </div>

        {/* Live Audio Reactive Waveform Bars */}
        <div className="flex items-center justify-center gap-1.5 h-6 my-1.5">
          {[35, 75, 95, 60, 85, 100, 70, 90, 50, 80, 65].map((height, i) => (
            <span
              key={i}
              className={`w-1 rounded-full bg-gradient-to-t from-purple-500 to-fuchsia-400 transition-all duration-150 ${
                assistantStatus === 'listening' || assistantStatus === 'speaking'
                  ? 'opacity-90 animate-pulse'
                  : 'opacity-25'
              }`}
              style={{
                height:
                  assistantStatus === 'listening' || assistantStatus === 'speaking'
                    ? `${height * 0.22}px`
                    : '4px',
                animationDelay: `${i * 0.08}s`,
              }}
            />
          ))}
        </div>

        {/* Hero Text underneath orb matching reference */}
        <div className="text-center px-6 mt-1 max-w-xs">
          <h3 className="text-[16px] font-extrabold text-white tracking-tight leading-snug drop-shadow-sm">
            {t.voiceHeroTitle}
          </h3>
          <p className="text-[11px] font-normal text-slate-300 mt-1 leading-relaxed">
            {selectedVoice === 'my-voice' && activeProfile
              ? `AI responses will speak in your cloned voice (${activeProfile.name}) in Tamil & English.`
              : t.voiceHeroDesc}
          </p>
        </div>

        {/* Transcript preview if user spoke */}
        {transcript && (
          <div className="mt-2 px-3 py-1 rounded-xl bg-purple-950/70 border border-purple-500/30 text-xs text-purple-200 max-w-xs text-center truncate">
            &ldquo;{transcript}&rdquo;
          </div>
        )}

        {/* Interactive Playback Control Bar (Stop, Pause, Replay) */}
        {(assistantStatus === 'speaking' || assistantStatus === 'paused' || history.length > 0) && (
          <div className="flex items-center gap-2.5 mt-2.5 px-3 py-1.5 rounded-full bg-[#180a2f]/90 border border-purple-500/30">
            {/* Play/Pause Button */}
            {(assistantStatus === 'speaking' || assistantStatus === 'paused') && (
              <button
                onClick={handleTogglePause}
                className="p-1.5 rounded-full bg-purple-800 text-white hover:bg-purple-700"
                title={assistantStatus === 'speaking' ? 'Pause Speech' : 'Resume Speech'}
              >
                {assistantStatus === 'speaking' ? (
                  <Pause className="w-3.5 h-3.5" />
                ) : (
                  <Play className="w-3.5 h-3.5" />
                )}
              </button>
            )}

            {/* Stop Button */}
            {(assistantStatus === 'speaking' || assistantStatus === 'paused') && (
              <button
                onClick={handleStopPlayback}
                className="p-1.5 rounded-full bg-purple-900/60 text-slate-300 hover:text-white"
                title="Stop Speech"
              >
                <Square className="w-3.5 h-3.5" />
              </button>
            )}

            {/* Replay Latest Button */}
            {history.length > 0 && (
              <button
                onClick={handleReplayLatest}
                className="flex items-center gap-1 text-[11px] font-medium text-purple-200 hover:text-white"
                title="Replay in Selected Voice"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Replay</span>
              </button>
            )}
          </div>
        )}
      </div>

      {/* Voice Conversation History Slide-up Sheet */}
      {showHistory && (
        <div className="mb-2 p-3 rounded-2xl bg-[#140628]/95 border border-purple-500/40 max-h-48 overflow-y-auto space-y-2 text-xs">
          <div className="flex items-center justify-between pb-1 border-b border-purple-500/20">
            <span className="font-bold text-white flex items-center gap-1.5">
              <History className="w-3.5 h-3.5 text-fuchsia-400" />
              <span>Voice Conversation History</span>
            </span>
            <button
              onClick={() => setShowHistory(false)}
              className="text-slate-400 hover:text-white"
            >
              ✕
            </button>
          </div>

          {history.length === 0 ? (
            <p className="text-[11px] text-slate-400 py-2 text-center">
              No voice conversation recorded yet. Speak a query to begin.
            </p>
          ) : (
            history.map((turn) => (
              <div
                key={turn.id}
                className="p-2 rounded-xl bg-purple-950/40 border border-purple-500/20 space-y-1"
              >
                <p className="text-[11px] text-purple-200">
                  <strong>You:</strong> {turn.userQuery}
                </p>
                <p className="text-[11px] text-slate-300">
                  <strong>AMMU:</strong> {turn.assistantResponse}
                </p>
                <div className="flex items-center justify-between pt-1 text-[10px] text-slate-400">
                  <span>
                    {turn.voiceUsed} • {turn.timestamp}
                  </span>
                  <button
                    onClick={() => {
                      ttsService.speak(turn.assistantResponse, language, {
                        ...voiceConfig,
                        selectedVoice,
                      });
                    }}
                    className="text-fuchsia-300 hover:text-white flex items-center gap-1"
                  >
                    <Volume2 className="w-3 h-3" /> Replay
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Bottom Controls matching screenshot: [Refresh 🔄]  [Purple Mic 🎤]  [Cancel ✕] */}
      <div className="flex items-center justify-center gap-8 py-2 px-4">
        {/* Left: Refresh / Retry circular button */}
        <button
          onClick={handleReset}
          className="w-12 h-12 rounded-full bg-[#180a2d] border border-purple-500/25 flex items-center justify-center text-slate-300 hover:text-white hover:border-purple-400 transition-all active:scale-95 shadow-lg"
          title="Reset Voice Analysis"
        >
          <RotateCcw className="w-4 h-4" />
        </button>

        {/* Center: Large glowing purple microphone button with pulsing ring */}
        <div className="relative">
          {assistantStatus === 'listening' && (
            <div className="absolute inset-0 rounded-full bg-purple-500/30 animate-ping -z-10" />
          )}
          <button
            onClick={toggleListening}
            className={`w-16 h-16 rounded-full flex items-center justify-center text-white transition-all shadow-[0_0_30px_rgba(168,85,247,0.6)] active:scale-95 ${
              assistantStatus === 'listening'
                ? 'bg-gradient-to-tr from-fuchsia-600 via-pink-600 to-purple-600 border-2 border-white'
                : 'bg-gradient-to-tr from-purple-700 via-fuchsia-600 to-indigo-600 border border-purple-300/40'
            }`}
            title={assistantStatus === 'listening' ? 'Stop Listening' : 'Tap to Speak'}
          >
            <Mic className="w-7 h-7" />
          </button>
        </div>

        {/* Right: Close / Cancel circular button */}
        <button
          onClick={onBack}
          className="w-12 h-12 rounded-full bg-[#180a2d] border border-purple-500/25 flex items-center justify-center text-slate-300 hover:text-white hover:border-purple-400 transition-all active:scale-95 shadow-lg"
          title="Close Voice Analysis"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Mini quick preset bar for instant testing and custom voice settings trigger */}
      <div className="flex items-center justify-center gap-3 pt-1 text-[11px] text-purple-300/80">
        <button
          onClick={() =>
            handleVoiceCommand(
              language === 'ta'
                ? 'எனக்கு 4 கிராபிக் படங்களை காட்டுங்கள்'
                : 'Show me four cool graphic pictures'
            )
          }
          className="flex items-center gap-1 hover:text-white underline underline-offset-2 transition-colors"
        >
          <Sparkles className="w-3 h-3 text-fuchsia-400" />
          <span>{language === 'ta' ? 'டெமோ கட்டளை' : 'Try Demo Command'}</span>
        </button>
        <span>•</span>
        {onOpenVoiceAgent ? (
          <button
            onClick={onOpenVoiceAgent}
            className="flex items-center gap-1 hover:text-white text-fuchsia-300 transition-colors font-semibold"
          >
            <Sparkles className="w-3 h-3 text-fuchsia-400" />
            <span>Voice Agent</span>
          </button>
        ) : (
          <button
            onClick={onOpenVoiceSettings}
            className="flex items-center gap-1 hover:text-white text-purple-200 transition-colors font-semibold"
          >
            <Sliders className="w-3 h-3 text-fuchsia-400" />
            <span>{language === 'ta' ? 'குரல் அமைப்பு' : 'Voice Settings'}</span>
          </button>
        )}
      </div>
    </div>
  );
};
