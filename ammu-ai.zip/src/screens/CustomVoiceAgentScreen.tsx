import React, { useState, useEffect, useRef } from 'react';
import { 
  ChevronLeft, 
  Menu, 
  Upload, 
  Mic, 
  Play, 
  Pause, 
  Trash2, 
  RotateCcw, 
  Check, 
  Sparkles, 
  ShieldCheck, 
  Info, 
  Volume2, 
  VolumeX, 
  User, 
  Sliders, 
  FileAudio, 
  CheckCircle2, 
  AlertCircle,
  Radio,
  Globe
} from 'lucide-react';
import { AppLanguage, VoiceAssistantConfig, VoiceProfile, VoiceSelectionType, VoiceBackendStatus } from '../types';
import { translations } from '../i18n/translations';
import { voiceCloneService } from '../services/voiceCloneService';
import { ttsService } from '../services/ttsService';

interface CustomVoiceAgentScreenProps {
  language: AppLanguage;
  onBack: () => void;
  onOpenMenu: () => void;
  voiceConfig: VoiceAssistantConfig;
  onUpdateVoiceConfig: (config: VoiceAssistantConfig) => void;
}

export const CustomVoiceAgentScreen: React.FC<CustomVoiceAgentScreenProps> = ({
  language,
  onBack,
  onOpenMenu,
  voiceConfig,
  onUpdateVoiceConfig,
}) => {
  const t = translations[language];

  // Voice Selection (Requirement 8): "My Voice" or "AMMU Female AI Voice"
  const [selectedVoice, setSelectedVoice] = useState<VoiceSelectionType>(
    voiceConfig.selectedVoice || 'my-voice'
  );

  // Active Profile (Requirement 6 & 7)
  const [activeProfile, setActiveProfile] = useState<VoiceProfile | null>(
    voiceCloneService.getActiveProfile()
  );

  // Recording State (Requirement 2)
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [audioLevel, setAudioLevel] = useState(0);
  const timerRef = useRef<any>(null);

  // Audio Sample State (Requirement 1, 3, 4, 5)
  const [sampleBase64, setSampleBase64] = useState<string | null>(null);
  const [sampleFormat, setSampleFormat] = useState<string>('audio/wav');
  const [sampleDuration, setSampleDuration] = useState<number>(0);
  const [sampleFileName, setSampleFileName] = useState<string>('');

  // Audio Player Preview (Requirement 4)
  const [isPlayingSample, setIsPlayingSample] = useState(false);
  const previewAudioRef = useRef<HTMLAudioElement | null>(null);

  // Profile Form & Training (Requirement 6 & 7)
  const [profileName, setProfileName] = useState('My Custom Voice');
  const [consentChecked, setConsentChecked] = useState(voiceCloneService.hasUserConsented());
  const [trainingStatus, setTrainingStatus] = useState<
    'idle' | 'sample_loaded' | 'training' | 'trained' | 'error'
  >(activeProfile ? 'trained' : 'idle');
  const [trainingLog, setTrainingLog] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Test Response Voice (Requirement 9 & 10)
  const [testLanguage, setTestLanguage] = useState<'ta' | 'en'>(language === 'ta' ? 'ta' : 'en');
  const [isTestingSpeech, setIsTestingSpeech] = useState(false);
  const [testSpeechResponse, setTestSpeechResponse] = useState<string | null>(null);

  // API Backend Transparency
  const [backendStatus, setBackendStatus] = useState<VoiceBackendStatus | null>(null);
  const [showApiInfoModal, setShowApiInfoModal] = useState(false);

  useEffect(() => {
    voiceCloneService.fetchBackendStatus().then(setBackendStatus);
    const existing = voiceCloneService.getActiveProfile();
    if (existing) {
      setActiveProfile(existing);
      setProfileName(existing.name);
      setTrainingStatus('trained');
    }
  }, []);

  // Timer counter for audio recording
  useEffect(() => {
    if (isRecording) {
      setRecordingSeconds(0);
      timerRef.current = setInterval(() => {
        setRecordingSeconds((s) => s + 1);
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isRecording]);

  // Requirement 2: Record Voice button
  const handleToggleRecord = async () => {
    setErrorMessage(null);
    if (isRecording) {
      try {
        const result = await voiceCloneService.stopRecording();
        setIsRecording(false);
        setSampleBase64(result.base64);
        setSampleFormat('audio/wav');
        setSampleDuration(result.durationSec);
        setSampleFileName('recorded_sample.wav');
        setTrainingStatus('sample_loaded');
      } catch (err: any) {
        setIsRecording(false);
        setErrorMessage(err.message || 'Failed to stop recording');
      }
    } else {
      try {
        await voiceCloneService.startRecording((lvl) => setAudioLevel(lvl));
        setIsRecording(true);
      } catch (err: any) {
        setErrorMessage('Microphone access denied. Please allow microphone permissions.');
      }
    }
  };

  // Requirement 1 & 3: Upload Voice button supporting MP3, WAV, M4A
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setErrorMessage(null);

    try {
      const result = await voiceCloneService.processUploadedAudio(file);
      setSampleBase64(result.base64);
      setSampleDuration(result.durationSec);
      setSampleFormat(result.format);
      setSampleFileName(file.name);
      setProfileName(file.name.replace(/\.[^/.]+$/, ''));
      setTrainingStatus('sample_loaded');
    } catch (err: any) {
      setErrorMessage(err.message || 'File upload failed. Ensure format is MP3, WAV, or M4A.');
    }
  };

  // Requirement 4: Audio playback and preview
  const handleTogglePlaySample = () => {
    if (!sampleBase64) return;
    if (isPlayingSample && previewAudioRef.current) {
      previewAudioRef.current.pause();
      setIsPlayingSample(false);
      return;
    }

    const audio = new Audio(sampleBase64);
    previewAudioRef.current = audio;
    setIsPlayingSample(true);
    audio.onended = () => setIsPlayingSample(false);
    audio.onerror = () => setIsPlayingSample(false);
    audio.play().catch(() => setIsPlayingSample(false));
  };

  // Requirement 5: Delete and re-upload options
  const handleDeleteSample = () => {
    if (previewAudioRef.current) {
      previewAudioRef.current.pause();
    }
    setSampleBase64(null);
    setSampleDuration(0);
    setSampleFileName('');
    setIsPlayingSample(false);
    setTrainingStatus(activeProfile ? 'trained' : 'idle');
  };

  // Requirement 6: Create Custom Voice Profile button
  const handleCreateVoiceProfile = async () => {
    if (!sampleBase64) {
      setErrorMessage('Please record or upload a voice sample first.');
      return;
    }
    if (!consentChecked) {
      setErrorMessage('Explicit voice-owner consent is mandatory to create your custom AI voice.');
      return;
    }

    setErrorMessage(null);
    setTrainingStatus('training');
    setTrainingLog('Step 1/3: Extracting acoustic frequency features and formant vectors...');

    setTimeout(() => {
      setTrainingLog('Step 2/3: Generating neural vocal identity and calibrating bilingual timbre...');
    }, 1200);

    try {
      const profile = await voiceCloneService.createVoiceProfile(
        profileName || 'My Voice Profile',
        sampleBase64,
        sampleFormat,
        sampleDuration,
        consentChecked
      );

      setActiveProfile(profile);
      setSelectedVoice('my-voice');
      setTrainingStatus('trained');
      setTrainingLog('Step 3/3: Profile trained and active! AMMU will now speak in your authentic voice.');

      // Sync across app state
      const updatedConfig: VoiceAssistantConfig = {
        ...voiceConfig,
        selectedVoice: 'my-voice',
        femaleVoice: false,
        activeProfile: profile,
        hasCustomVoice: true,
        customVoiceName: profile.name,
      };
      voiceCloneService.saveActiveVoiceSelection('my-voice');
      onUpdateVoiceConfig(updatedConfig);
    } catch (err: any) {
      setTrainingStatus('error');
      setErrorMessage(err.message || 'Failed to train custom voice profile.');
    }
  };

  // Delete Voice Profile
  const handleDeleteProfile = async () => {
    if (!activeProfile) return;
    if (confirm('Permanently delete your custom voice profile?')) {
      await voiceCloneService.deleteProfile(activeProfile.id);
      setActiveProfile(null);
      handleDeleteSample();
      setSelectedVoice('female');
      setTrainingStatus('idle');

      const updatedConfig: VoiceAssistantConfig = {
        ...voiceConfig,
        selectedVoice: 'female',
        femaleVoice: true,
        activeProfile: null,
        hasCustomVoice: false,
      };
      voiceCloneService.saveActiveVoiceSelection('female');
      onUpdateVoiceConfig(updatedConfig);
    }
  };

  // Requirement 8: Select My Voice or AMMU Female AI Voice
  const handleVoiceSelection = (voice: VoiceSelectionType) => {
    setSelectedVoice(voice);
    voiceCloneService.saveActiveVoiceSelection(voice);
    const updatedConfig: VoiceAssistantConfig = {
      ...voiceConfig,
      selectedVoice: voice,
      femaleVoice: voice === 'female',
    };
    onUpdateVoiceConfig(updatedConfig);
  };

  // Requirement 9 & 10: Test Voice Response button with Tamil and English voice support
  const handleTestVoiceResponse = async () => {
    setIsTestingSpeech(true);
    setErrorMessage(null);

    const testPhrases = {
      ta:
        selectedVoice === 'my-voice' && activeProfile
          ? `வணக்கம்! இது உங்கள் AMMU தனிப்பயன் குரல் ஏஜென்ட். நான் உங்கள் சொந்த குரலில் பேசுகிறேன். தமிழில் பேசுவது எப்படி உள்ளது?`
          : `வணக்கம்! நான் உங்கள் AMMU பெண் AI குரல் உதவியாளர். உங்களுக்கு உதவ எப்போதும் தயாராக உள்ளேன்.`,
      en:
        selectedVoice === 'my-voice' && activeProfile
          ? `Hello! This is your AMMU Custom Voice Agent speaking in your authentic cloned voice. How does my speech sound to you?`
          : `Hello! I am the AMMU Female AI Voice assistant, ready to assist you anytime.`,
    };

    const phrase = testPhrases[testLanguage];
    setTestSpeechResponse(phrase);

    await voiceCloneService.speakText(
      phrase,
      selectedVoice,
      voiceConfig.rate || 1.0,
      voiceConfig.pitch || 1.0,
      () => setIsTestingSpeech(true),
      () => setIsTestingSpeech(false),
      (err) => {
        setIsTestingSpeech(false);
        setErrorMessage(typeof err === 'string' ? err : 'Speech playback failed.');
      }
    );
  };

  const formatTime = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="flex flex-col h-full justify-between pb-2 text-white">
      {/* Top Header */}
      <div className="flex items-center justify-between py-1 mb-2">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full bg-[#1b0f30]/90 border border-purple-500/25 flex items-center justify-center text-white/90 hover:text-white hover:border-purple-400 transition-all shadow-md active:scale-95"
          aria-label="Back"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-fuchsia-500 shadow-[0_0_8px_#d946ef] animate-pulse" />
          <h2 className="text-[16px] font-bold tracking-tight text-white">
            {t.voiceAgentTitle}
          </h2>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setShowApiInfoModal(!showApiInfoModal)}
            className="w-9 h-9 rounded-full bg-[#1b0f30]/90 border border-purple-500/25 flex items-center justify-center text-purple-300 hover:text-white hover:border-purple-400 transition-colors"
            title="API Credentials & Transparency"
          >
            <Info className="w-4 h-4" />
          </button>
          <button
            onClick={onOpenMenu}
            className="w-10 h-10 rounded-full bg-[#1b0f30]/90 border border-purple-500/25 flex items-center justify-center text-white/90 hover:text-white hover:border-purple-400 transition-all shadow-md active:scale-95"
            aria-label="Menu"
          >
            <Menu className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* API Credential & Subscription Modal */}
      {showApiInfoModal && (
        <div className="mb-3 p-3.5 rounded-2xl bg-[#1b0c36] border border-purple-500/40 text-xs text-slate-200 space-y-2 shrink-0 animate-fadeIn">
          <div className="flex items-center justify-between font-bold text-purple-200">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Voice Cloning API Credentials & Subscriptions</span>
            </span>
            <button onClick={() => setShowApiInfoModal(false)} className="text-slate-400 hover:text-white">
              ✕
            </button>
          </div>
          <p className="text-[11px] leading-relaxed text-slate-300">
            {backendStatus?.pricingInfo?.elevenlabs ||
              'ElevenLabs Instant Voice Cloning requires an ElevenLabs account (Starter plan: $5/month) with ELEVENLABS_API_KEY. Without third-party keys, AMMU automatically uses its Neural Acoustic Voice Engine powered by Gemini 3.8 Flash TTS.'}
          </p>
          <div className="p-2 rounded-xl bg-purple-950/70 border border-purple-500/30 flex items-center justify-between text-[11px]">
            <span>Cloud Voice Cloning Provider:</span>
            <span className={`font-semibold ${backendStatus?.elevenLabsConfigured ? 'text-emerald-400' : 'text-amber-300'}`}>
              {backendStatus?.elevenLabsConfigured ? 'ElevenLabs (Connected)' : 'AMMU Neural Acoustic Engine'}
            </span>
          </div>
        </div>
      )}

      {/* Error alert banner */}
      {errorMessage && (
        <div className="mb-2 p-2.5 rounded-xl bg-rose-950/80 border border-rose-500/40 text-xs text-rose-200 flex items-center gap-2 shrink-0">
          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Main Scrollable Content */}
      <div className="flex-1 overflow-y-auto space-y-4 pr-0.5">
        {/* REQUIREMENT 8: Select My Voice or AMMU Female AI Voice */}
        <div className="p-3.5 rounded-2xl bg-[#170a2f] border border-purple-500/30 space-y-2.5">
          <label className="text-[11px] font-bold uppercase tracking-wider text-purple-300 flex items-center gap-1.5">
            <Radio className="w-3.5 h-3.5 text-fuchsia-400" />
            <span>Select Active Voice</span>
          </label>

          <div className="grid grid-cols-2 gap-2">
            {/* Option A: My Cloned Voice */}
            <button
              onClick={() => handleVoiceSelection('my-voice')}
              className={`p-3 rounded-2xl border text-left flex flex-col justify-between transition-all ${
                selectedVoice === 'my-voice'
                  ? 'bg-gradient-to-br from-purple-900/90 to-fuchsia-950/90 border-purple-400 shadow-[0_0_18px_rgba(168,85,247,0.4)] text-white'
                  : 'bg-[#120625] border-purple-500/20 text-slate-300 hover:border-purple-400/50'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="w-8 h-8 rounded-xl bg-purple-600/30 flex items-center justify-center text-fuchsia-300">
                  <User className="w-4 h-4" />
                </div>
                {selectedVoice === 'my-voice' && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
              </div>
              <div>
                <p className="text-xs font-bold text-white">{t.selectMyVoice}</p>
                <p className="text-[10px] text-purple-300/80 truncate">
                  {activeProfile ? activeProfile.name : 'Not yet created'}
                </p>
              </div>
            </button>

            {/* Option B: AMMU Female AI Voice */}
            <button
              onClick={() => handleVoiceSelection('female')}
              className={`p-3 rounded-2xl border text-left flex flex-col justify-between transition-all ${
                selectedVoice === 'female'
                  ? 'bg-gradient-to-br from-purple-900/90 to-fuchsia-950/90 border-purple-400 shadow-[0_0_18px_rgba(168,85,247,0.4)] text-white'
                  : 'bg-[#120625] border-purple-500/20 text-slate-300 hover:border-purple-400/50'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="w-8 h-8 rounded-xl bg-purple-600/30 flex items-center justify-center text-pink-300">
                  <Sparkles className="w-4 h-4" />
                </div>
                {selectedVoice === 'female' && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
              </div>
              <div>
                <p className="text-xs font-bold text-white">{t.selectAmmuFemale}</p>
                <p className="text-[10px] text-slate-400">AMMU Signature</p>
              </div>
            </button>
          </div>
        </div>

        {/* Active Profile Status Badge */}
        {activeProfile && (
          <div className="p-3 rounded-2xl bg-gradient-to-r from-[#1e0d3a] to-[#140827] border border-purple-500/30 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-purple-900/50 flex items-center justify-center text-emerald-400">
                <Check className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs font-bold text-white">{activeProfile.name}</p>
                <p className="text-[10px] text-purple-300/80">
                  Active • {activeProfile.audioDurationSec}s sample ({activeProfile.cloneProvider})
                </p>
              </div>
            </div>
            <button
              onClick={handleDeleteProfile}
              className="p-1.5 rounded-lg bg-rose-950/50 text-rose-300 hover:text-white hover:bg-rose-900 transition-colors"
              title="Delete Voice Profile"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* REQUIREMENTS 1, 2, 3: RECORD OR UPLOAD VOICE SAMPLE */}
        <div className="p-4 rounded-2xl bg-[#16092d] border border-purple-500/30 space-y-3.5">
          <div>
            <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
              <Mic className="w-4 h-4 text-fuchsia-400" />
              <span>Voice Sample Acquisition</span>
            </h4>
            <p className="text-[10px] text-slate-400 mt-0.5">
              Provide a clear 5-15 second audio sample in English or Tamil.
            </p>
          </div>

          {/* Requirement 2: Record Voice button */}
          <div className="flex flex-col items-center justify-center p-3.5 rounded-2xl bg-[#1d0c38] border border-purple-500/20 space-y-2.5">
            <div className="relative">
              {isRecording && (
                <div
                  className="absolute inset-0 rounded-full bg-fuchsia-500/30 animate-ping -z-10"
                  style={{ transform: `scale(${1 + audioLevel / 50})` }}
                />
              )}
              <button
                type="button"
                onClick={handleToggleRecord}
                className={`w-14 h-14 rounded-full flex items-center justify-center transition-all shadow-[0_0_20px_rgba(168,85,247,0.5)] active:scale-95 ${
                  isRecording
                    ? 'bg-rose-600 border-2 border-white text-white'
                    : 'bg-gradient-to-tr from-purple-600 via-fuchsia-600 to-indigo-600 border border-purple-300/40 text-white'
                }`}
              >
                <Mic className="w-5 h-5" />
              </button>
            </div>

            <div className="text-center">
              <p className="text-xs font-bold text-white">
                {isRecording ? 'Recording your voice...' : t.recordVoiceBtn}
              </p>
              <p className="text-[11px] font-mono text-purple-300">
                {isRecording ? formatTime(recordingSeconds) : 'Tap mic to start recording'}
              </p>
            </div>

            {/* Live Audio Reactive Waveform */}
            {isRecording && (
              <div className="flex items-center gap-1 h-4">
                {[20, 50, 90, 100, 70, 95, 60, 40].map((h, i) => (
                  <span
                    key={i}
                    className="w-1 rounded-full bg-fuchsia-400 animate-pulse"
                    style={{
                      height: `${Math.max(4, (h * audioLevel) / 100)}px`,
                      animationDelay: `${i * 0.05}s`,
                    }}
                  />
                ))}
              </div>
            )}
          </div>

          {/* Divider */}
          <div className="relative flex py-0.5 items-center">
            <div className="flex-grow border-t border-purple-500/20" />
            <span className="flex-shrink mx-3 text-[10px] text-purple-300/60 font-semibold uppercase">
              Or
            </span>
            <div className="flex-grow border-t border-purple-500/20" />
          </div>

          {/* Requirement 1 & 3: Upload Voice button (MP3, WAV, M4A) */}
          <label className="flex items-center justify-between p-3 rounded-xl border border-dashed border-purple-400/40 hover:border-purple-300 bg-purple-950/20 cursor-pointer transition-colors">
            <div className="flex items-center gap-2.5">
              <Upload className="w-4 h-4 text-purple-300" />
              <div>
                <p className="text-xs font-medium text-purple-200">
                  {t.uploadVoiceBtn}
                </p>
                <p className="text-[10px] text-slate-400">Supported: MP3, WAV, M4A (Max 25MB)</p>
              </div>
            </div>
            <span className="text-[11px] font-semibold text-fuchsia-400 hover:underline">
              Choose File
            </span>
            <input
              type="file"
              accept="audio/mp3,audio/mpeg,audio/wav,audio/x-wav,audio/m4a,audio/x-m4a,audio/webm"
              onChange={handleFileUpload}
              className="hidden"
            />
          </label>

          {/* REQUIREMENTS 4 & 5: AUDIO PLAYBACK, PREVIEW, DELETE & RE-UPLOAD */}
          {sampleBase64 && (
            <div className="p-3 rounded-xl bg-purple-950/60 border border-purple-400/30 flex items-center justify-between gap-2 animate-fadeIn">
              <div className="flex items-center gap-2 min-w-0">
                <FileAudio className="w-4 h-4 text-fuchsia-400 shrink-0" />
                <div className="min-w-0">
                  <p className="text-xs font-semibold text-white truncate max-w-[170px]">
                    {sampleFileName || 'Voice Sample'}
                  </p>
                  <p className="text-[10px] text-purple-300">{sampleDuration}s audio duration</p>
                </div>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={handleTogglePlaySample}
                  className="px-2.5 py-1 rounded-lg bg-purple-700 hover:bg-purple-600 text-white flex items-center gap-1 text-xs font-medium"
                >
                  {isPlayingSample ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                  <span>{isPlayingSample ? 'Pause' : 'Play'}</span>
                </button>
                <button
                  type="button"
                  onClick={handleDeleteSample}
                  className="p-1.5 rounded-lg bg-rose-950/60 text-rose-300 hover:text-white"
                  title="Delete and re-upload"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>

        {/* REQUIREMENTS 6 & 7: CREATE PROFILE & TRAINING STATUS */}
        <div className="p-4 rounded-2xl bg-[#190a33] border border-purple-500/30 space-y-3">
          <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-fuchsia-400" />
            <span>Voice Profile Creation & Training</span>
          </h4>

          <div>
            <label className="text-[11px] text-slate-300 block mb-1">
              Custom Voice Profile Name:
            </label>
            <input
              type="text"
              value={profileName}
              onChange={(e) => setProfileName(e.target.value)}
              placeholder="e.g. My Personal AMMU Voice"
              className="w-full bg-[#110524] border border-purple-500/30 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-purple-400"
            />
          </div>

          {/* Mandatory Voice Owner Consent */}
          <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-500/20">
            <label className="flex items-start gap-2.5 cursor-pointer">
              <input
                type="checkbox"
                checked={consentChecked}
                onChange={(e) => setConsentChecked(e.target.checked)}
                className="mt-0.5 rounded border-purple-400 text-purple-600 focus:ring-purple-500"
              />
              <span className="text-[11px] text-slate-200 leading-snug">
                <strong>Explicit Voice Consent:</strong> {t.voiceConsentLabel}
              </span>
            </label>
          </div>

          {/* Requirement 7: Training Status Badge & Log */}
          <div className="p-2.5 rounded-xl bg-[#120625] border border-purple-500/20 flex items-center justify-between text-[11px]">
            <span className="text-slate-400">{t.trainingStatusLabel}:</span>
            <span
              className={`font-bold uppercase tracking-wider ${
                trainingStatus === 'trained'
                  ? 'text-emerald-400'
                  : trainingStatus === 'training'
                  ? 'text-amber-400 animate-pulse'
                  : trainingStatus === 'sample_loaded'
                  ? 'text-fuchsia-400'
                  : 'text-slate-400'
              }`}
            >
              ● {trainingStatus === 'trained' ? 'Trained & Active' : trainingStatus === 'training' ? 'Training...' : trainingStatus === 'sample_loaded' ? 'Sample Ready' : 'Idle'}
            </span>
          </div>

          {trainingLog && (
            <p className="text-[11px] text-fuchsia-300 bg-purple-950/40 p-2 rounded-lg border border-purple-500/20 leading-relaxed font-mono">
              {trainingLog}
            </p>
          )}

          {/* Requirement 6: Create Custom Voice Profile button */}
          <button
            onClick={handleCreateVoiceProfile}
            disabled={trainingStatus === 'training' || !sampleBase64 || !consentChecked}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-purple-600 via-fuchsia-600 to-indigo-600 text-xs font-bold text-white flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(168,85,247,0.4)] active:scale-98 transition-all disabled:opacity-40"
          >
            <Sparkles className={`w-4 h-4 ${trainingStatus === 'training' ? 'animate-spin' : ''}`} />
            <span>{trainingStatus === 'training' ? 'Synthesizing Voice Model...' : t.createProfileBtn}</span>
          </button>
        </div>

        {/* REQUIREMENTS 9 & 10: TAMIL & ENGLISH TEST VOICE RESPONSE */}
        <div className="p-4 rounded-2xl bg-[#16092d] border border-purple-500/30 space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
              <Globe className="w-4 h-4 text-cyan-400" />
              <span>Bilingual Voice Response Testing</span>
            </h4>

            {/* Language Switcher for Testing (Tamil & English) */}
            <div className="flex items-center gap-1 p-0.5 rounded-lg bg-purple-950/80 border border-purple-500/30 text-[10px]">
              <button
                type="button"
                onClick={() => setTestLanguage('en')}
                className={`px-2 py-0.5 rounded font-semibold ${
                  testLanguage === 'en' ? 'bg-purple-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                English
              </button>
              <button
                type="button"
                onClick={() => setTestLanguage('ta')}
                className={`px-2 py-0.5 rounded font-semibold ${
                  testLanguage === 'ta' ? 'bg-purple-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                தமிழ்
              </button>
            </div>
          </div>

          <p className="text-[10px] text-slate-400">
            Synthesize and audition an AI voice response in {testLanguage === 'ta' ? 'Tamil' : 'English'} using{' '}
            <strong>{selectedVoice === 'my-voice' ? 'My Custom Voice' : 'AMMU Female AI Voice'}</strong>.
          </p>

          {/* Test Voice Response button */}
          <button
            onClick={handleTestVoiceResponse}
            disabled={isTestingSpeech || (selectedVoice === 'my-voice' && !activeProfile)}
            className="w-full py-2.5 rounded-xl bg-purple-900/60 hover:bg-purple-800/80 border border-purple-400/40 text-xs font-semibold text-purple-100 flex items-center justify-center gap-2 transition-all disabled:opacity-40"
          >
            <Volume2 className={`w-4 h-4 ${isTestingSpeech ? 'animate-bounce text-fuchsia-300' : ''}`} />
            <span>{isTestingSpeech ? 'Speaking in ' + selectedVoice + '...' : t.testVoiceResponseBtn}</span>
          </button>

          {testSpeechResponse && (
            <div className="p-2.5 rounded-xl bg-purple-950/40 border border-purple-500/20 text-[11px] text-slate-200">
              <span className="text-[10px] uppercase font-bold text-fuchsia-400 block mb-0.5">Response Text:</span>
              &ldquo;{testSpeechResponse}&rdquo;
            </div>
          )}
        </div>
      </div>

      {/* Footer Navigation Bar */}
      <div className="pt-2 border-t border-purple-500/20 flex items-center gap-2 shrink-0">
        <button
          onClick={onBack}
          className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#200f3a] via-[#331557] to-[#250d40] border border-purple-400/30 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-inner hover:border-purple-400/60 transition-all"
        >
          <span>Return to Dashboard</span>
        </button>
      </div>
    </div>
  );
};
