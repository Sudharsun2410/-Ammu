import React from 'react';
import { 
  Menu, 
  ArrowRight, 
  Image as ImageIcon, 
  FileText, 
  Calendar, 
  Sparkles, 
  BarChart3, 
  HelpCircle,
  Mic
} from 'lucide-react';
import { AppLanguage, UserProfile } from '../types';
import { translations } from '../i18n/translations';

interface HomeScreenProps {
  language: AppLanguage;
  user: UserProfile;
  onNavigate: (screen: 'chatbot' | 'voice' | 'voiceagent' | 'imagegen' | 'projects' | 'login') => void;
  onQuickPrompt: (prompt: string) => void;
  onOpenMenu: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  language,
  user,
  onNavigate,
  onQuickPrompt,
  onOpenMenu,
}) => {
  const t = translations[language];

  return (
    <div className="flex flex-col h-full justify-between pb-1 pt-1 text-white">
      {/* Top Header Row */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div 
            onClick={() => onNavigate('login')}
            className="relative cursor-pointer group"
          >
            <div className="w-12 h-12 rounded-full p-[2px] bg-gradient-to-tr from-purple-500 via-fuchsia-500 to-indigo-500 shadow-md group-hover:scale-105 transition-transform">
              <img
                src={user.avatar}
                alt={user.name}
                className="w-full h-full rounded-full object-cover"
              />
            </div>
            <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-emerald-500 rounded-full border-2 border-[#0a0514]" />
          </div>
          <div>
            <p className="text-[11px] font-medium text-slate-400 tracking-wide">
              {t.greetingPrefix}
            </p>
            <p className="text-base font-bold text-white tracking-tight">
              {user.name}
            </p>
          </div>
        </div>

        <button
          onClick={onOpenMenu}
          className="w-10 h-10 rounded-full bg-[#1b0f30]/90 border border-purple-500/25 flex items-center justify-center text-white/90 hover:text-white hover:border-purple-400 transition-all shadow-lg active:scale-95"
          aria-label="Menu"
        >
          <Menu className="w-4 h-4" />
        </button>
      </div>

      {/* Hero Headline */}
      <div className="mb-4">
        <h1 className="text-[26px] font-extrabold leading-[1.18] tracking-tight text-white drop-shadow-sm">
          {t.heroLine1}
          <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-purple-100 to-fuchsia-200">
            {t.heroLine2}
          </span>
        </h1>
      </div>

      {/* Main Feature Cards Grid */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        {/* Left Tall Card: Generating Visual with Neon Ribbon Art */}
        <div
          onClick={() => onNavigate('imagegen')}
          className="relative h-[210px] rounded-3xl p-3.5 flex flex-col justify-between overflow-hidden cursor-pointer group border border-purple-500/30 transition-all duration-300 hover:border-purple-400/70 hover:shadow-[0_0_25px_rgba(168,85,247,0.35)]"
          style={{
            background: 'linear-gradient(145deg, #160a28 0%, #0d0617 100%)',
          }}
        >
          {/* Neon Light Ribbons Background Artwork matching reference */}
          <div className="absolute inset-0 opacity-85 group-hover:opacity-100 transition-opacity">
            <svg
              className="w-full h-full object-cover"
              viewBox="0 0 200 300"
              preserveAspectRatio="none"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <defs>
                <linearGradient id="neonGrad1" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#ec4899" />
                  <stop offset="40%" stopColor="#a855f7" />
                  <stop offset="100%" stopColor="#3b82f6" />
                </linearGradient>
                <linearGradient id="neonGrad2" x1="100%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#f43f5e" />
                  <stop offset="60%" stopColor="#c026d3" />
                  <stop offset="100%" stopColor="#6366f1" />
                </linearGradient>
                <filter id="glowFilter" x="-20%" y="-20%" width="140%" height="140%">
                  <feGaussianBlur stdDeviation="3" result="blur" />
                  <feComposite in="SourceGraphic" in2="blur" operator="over" />
                </filter>
              </defs>

              {/* Curving Abstract Neon Strands */}
              <path
                d="M-30,220 C40,240 120,180 180,60 C200,20 220,10 240,0"
                stroke="url(#neonGrad1)"
                strokeWidth="7"
                strokeLinecap="round"
                filter="url(#glowFilter)"
              />
              <path
                d="M-20,235 C50,250 130,195 185,80"
                stroke="url(#neonGrad2)"
                strokeWidth="4"
                strokeLinecap="round"
                opacity="0.9"
              />
              <path
                d="M-40,200 C30,220 100,160 160,40"
                stroke="#d946ef"
                strokeWidth="3"
                opacity="0.8"
              />
              <path
                d="M0,260 C60,265 140,210 190,110"
                stroke="#06b6d4"
                strokeWidth="2.5"
                opacity="0.85"
              />
              <path
                d="M-10,210 C50,190 90,120 140,20"
                stroke="#f472b6"
                strokeWidth="2"
                opacity="0.75"
              />
            </svg>
            <div className="absolute inset-0 bg-gradient-to-t from-[#0a0514] via-[#0a0514]/30 to-transparent" />
          </div>

          {/* Top Icon Pill */}
          <div className="relative z-10 w-9 h-9 rounded-xl bg-[#26133f]/80 backdrop-blur-md border border-purple-400/30 flex items-center justify-center text-purple-200">
            <ImageIcon className="w-4 h-4 text-fuchsia-300" />
          </div>

          {/* Bottom Label & Arrow */}
          <div className="relative z-10 flex items-center justify-between">
            <span className="text-[13px] font-semibold text-white/95 leading-tight">
              {t.cardGenVisual}
            </span>
            <div className="w-6 h-6 rounded-full bg-purple-500/20 flex items-center justify-center text-purple-300 group-hover:translate-x-1 transition-transform">
              <ArrowRight className="w-3.5 h-3.5" />
            </div>
          </div>
        </div>

        {/* Right Column: 2 Stacked Cards */}
        <div className="flex flex-col gap-3">
          {/* Generate Document Card */}
          <div
            onClick={() => onNavigate('projects')}
            className="h-[99px] rounded-3xl p-3.5 flex flex-col justify-between cursor-pointer group border border-purple-500/25 bg-gradient-to-br from-[#1d0f33]/90 to-[#120822]/90 backdrop-blur-md hover:border-purple-400/60 transition-all hover:shadow-[0_0_20px_rgba(168,85,247,0.25)]"
          >
            <div className="flex items-center justify-between">
              <div className="w-8 h-8 rounded-xl bg-purple-950/60 border border-purple-400/25 flex items-center justify-center text-purple-300">
                <FileText className="w-4 h-4 text-purple-300" />
              </div>
              <ArrowRight className="w-3.5 h-3.5 text-purple-400/70 group-hover:translate-x-1 transition-transform" />
            </div>
            <div>
              <p className="text-[12px] font-semibold text-white/95 leading-tight">
                {t.cardGenDoc}
              </p>
            </div>
          </div>

          {/* Organizing Meeting Card */}
          <div
            onClick={() => {
              onQuickPrompt(language === 'ta' ? 'அடுத்த சந்திப்பை திட்டமிடுங்கள்' : 'Organize my next calendar meeting with agenda');
              onNavigate('chatbot');
            }}
            className="h-[99px] rounded-3xl p-3.5 flex flex-col justify-between cursor-pointer group border border-purple-500/25 bg-gradient-to-br from-[#1d0f33]/90 to-[#120822]/90 backdrop-blur-md hover:border-purple-400/60 transition-all hover:shadow-[0_0_20px_rgba(168,85,247,0.25)]"
          >
            <div className="flex items-center justify-between">
              <div className="w-8 h-8 rounded-xl bg-purple-950/60 border border-purple-400/25 flex items-center justify-center text-purple-300">
                <Calendar className="w-4 h-4 text-purple-300" />
              </div>
              <ArrowRight className="w-3.5 h-3.5 text-purple-400/70 group-hover:translate-x-1 transition-transform" />
            </div>
            <div>
              <p className="text-[12px] font-semibold text-white/95 leading-tight">
                {t.cardOrgMeeting}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* AMMU Custom Voice Agent Shortcut Card */}
      <div
        onClick={() => onNavigate('voiceagent')}
        className="mb-3 p-2.5 rounded-2xl bg-gradient-to-r from-[#1f0d3a]/90 via-[#260e48]/90 to-[#190930]/90 border border-fuchsia-500/30 hover:border-fuchsia-400/60 shadow-[0_0_15px_rgba(217,70,239,0.15)] flex items-center justify-between cursor-pointer group transition-all"
      >
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-fuchsia-600/25 border border-fuchsia-400/30 flex items-center justify-center text-fuchsia-300">
            <Mic className="w-4 h-4" />
          </div>
          <div>
            <p className="text-[12px] font-bold text-white flex items-center gap-1.5">
              <span>{t.voiceAgentTitle}</span>
              <span className="px-1.5 py-0.5 rounded-full bg-fuchsia-500/20 text-fuchsia-300 text-[9px] font-semibold">New</span>
            </p>
            <p className="text-[10px] text-purple-200/80">
              {language === 'ta' ? 'உங்கள் சொந்த குரலை குளோன் செய்து பேச வைக்கலாம்' : 'Clone your voice & speak responses'}
            </p>
          </div>
        </div>
        <div className="w-6 h-6 rounded-full bg-purple-500/20 flex items-center justify-center text-purple-300 group-hover:translate-x-1 transition-transform">
          <ArrowRight className="w-3.5 h-3.5" />
        </div>
      </div>

      {/* Section: Recent Chat */}
      <div className="mb-3">
        <div className="flex items-center justify-between mb-2 px-1">
          <span className="text-[13px] font-semibold text-white/90">
            {t.recentChat}
          </span>
          <button 
            onClick={() => onNavigate('projects')}
            className="text-[11px] font-medium text-slate-400 hover:text-purple-300 transition-colors"
          >
            {t.seeAll}
          </button>
        </div>

        {/* 2x2 Action Pills matching reference */}
        <div className="grid grid-cols-2 gap-2">
          {/* Pill 1: Generate AI Image */}
          <button
            onClick={() => onNavigate('imagegen')}
            className="flex items-center gap-2 px-3 py-2.5 rounded-2xl bg-[#170c2a]/80 border border-purple-500/20 text-left hover:border-purple-400/50 hover:bg-[#20103a]/90 transition-all group"
          >
            <div className="w-5 h-5 rounded-lg bg-purple-500/15 flex items-center justify-center text-fuchsia-300 shrink-0">
              <Sparkles className="w-3 h-3" />
            </div>
            <span className="text-[11px] font-medium text-slate-200 group-hover:text-white truncate">
              {t.pillGenImage}
            </span>
          </button>

          {/* Pill 2: Summarize This Text */}
          <button
            onClick={() => {
              onQuickPrompt(language === 'ta' ? 'இந்த உரையை சுருக்கமாக விளக்குங்கள்' : 'Summarize key points from my text');
              onNavigate('chatbot');
            }}
            className="flex items-center gap-2 px-3 py-2.5 rounded-2xl bg-[#170c2a]/80 border border-purple-500/20 text-left hover:border-purple-400/50 hover:bg-[#20103a]/90 transition-all group"
          >
            <div className="w-5 h-5 rounded-lg bg-purple-500/15 flex items-center justify-center text-purple-300 shrink-0">
              <FileText className="w-3 h-3" />
            </div>
            <span className="text-[11px] font-medium text-slate-200 group-hover:text-white truncate">
              {t.pillSummarize}
            </span>
          </button>

          {/* Pill 3: Build Quick Report */}
          <button
            onClick={() => {
              onQuickPrompt(language === 'ta' ? 'விரைவு பகுப்பாய்வு அறிக்கை தயாரிக்கவும்' : 'Build a quick performance report');
              onNavigate('chatbot');
            }}
            className="flex items-center gap-2 px-3 py-2.5 rounded-2xl bg-[#170c2a]/80 border border-purple-500/20 text-left hover:border-purple-400/50 hover:bg-[#20103a]/90 transition-all group"
          >
            <div className="w-5 h-5 rounded-lg bg-purple-500/15 flex items-center justify-center text-cyan-300 shrink-0">
              <BarChart3 className="w-3 h-3" />
            </div>
            <span className="text-[11px] font-medium text-slate-200 group-hover:text-white truncate">
              {t.pillQuickReport}
            </span>
          </button>

          {/* Pill 4: Ask Anything Now */}
          <button
            onClick={() => {
              onQuickPrompt('');
              onNavigate('chatbot');
            }}
            className="flex items-center gap-2 px-3 py-2.5 rounded-2xl bg-[#170c2a]/80 border border-purple-500/20 text-left hover:border-purple-400/50 hover:bg-[#20103a]/90 transition-all group"
          >
            <div className="w-5 h-5 rounded-lg bg-purple-500/15 flex items-center justify-center text-amber-300 shrink-0">
              <HelpCircle className="w-3 h-3" />
            </div>
            <span className="text-[11px] font-medium text-slate-200 group-hover:text-white truncate">
              {t.pillAskAnything}
            </span>
          </button>
        </div>
      </div>

      {/* Bottom Action Bar: "Start New Chat →" + Circular Voice Assistant Trigger Button */}
      <div className="relative mt-2 flex items-center gap-2 p-1 rounded-full bg-[#150a26]/90 border border-purple-500/30 shadow-[0_8px_20px_rgba(0,0,0,0.4)]">
        <button
          onClick={() => {
            onQuickPrompt('');
            onNavigate('chatbot');
          }}
          className="flex-1 flex items-center justify-center gap-2 py-3 px-5 rounded-full bg-gradient-to-r from-[#200f3a] via-[#331557] to-[#250d40] border border-purple-400/30 text-white font-semibold text-[13px] hover:border-purple-400/60 active:scale-[0.98] transition-all shadow-inner"
        >
          <span>{t.startNewChat}</span>
          <ArrowRight className="w-3.5 h-3.5 text-purple-300" />
        </button>

        {/* Circular Assistant Voice Orb trigger button on the right */}
        <button
          onClick={() => onNavigate('voice')}
          className="w-12 h-12 rounded-full p-[2px] bg-gradient-to-tr from-fuchsia-600 via-purple-600 to-indigo-600 flex items-center justify-center shadow-[0_0_15px_rgba(168,85,247,0.5)] active:scale-95 transition-transform shrink-0"
          title="Open Voice Analysis Assistant"
        >
          <div className="w-full h-full rounded-full bg-[#130724] flex items-center justify-center">
            {/* Pulsing micro orb icon */}
            <div className="relative w-5 h-5 rounded-full bg-gradient-to-tr from-fuchsia-500 to-purple-400 flex items-center justify-center shadow-[0_0_8px_#d946ef]">
              <Mic className="w-3 h-3 text-white" />
            </div>
          </div>
        </button>
      </div>
    </div>
  );
};
