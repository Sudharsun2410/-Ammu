import React, { useState } from 'react';
import { 
  ChevronLeft, 
  Menu, 
  Sparkles, 
  Download, 
  Share2, 
  FolderPlus, 
  Wand2, 
  Check,
  Layers
} from 'lucide-react';
import { AppLanguage } from '../types';
import { translations } from '../i18n/translations';
import { storageService } from '../services/storageService';

interface ImageGeneratorScreenProps {
  language: AppLanguage;
  onBack: () => void;
  onOpenMenu: () => void;
}

export const ImageGeneratorScreen: React.FC<ImageGeneratorScreenProps> = ({
  language,
  onBack,
  onOpenMenu,
}) => {
  const t = translations[language];
  const [prompt, setPrompt] = useState(
    language === 'ta' 
      ? 'ஒளிரும் நியான் ஊதா ஆற்றல் அலைகள் மற்றும் சுழலும் வளையங்கள்' 
      : 'Glowing neon deep purple plasma orb with golden energetic rings and cosmic dust'
  );
  const [isGenerating, setIsGenerating] = useState(false);
  const [savedIndex, setSavedIndex] = useState<number | null>(null);

  // 4 high-fidelity graphic artworks directly aligned with the design reference
  const [generatedImages, setGeneratedImages] = useState<string[]>([
    'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=700&q=80', // Golden ring abstract
    'https://images.unsplash.com/photo-1634017839464-5c339ebe3cb4?auto=format&fit=crop&w=700&q=80', // Neon futuristic helmet/sphere
    'https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&w=700&q=80', // Color explosion powder
    'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?auto=format&fit=crop&w=700&q=80', // Cosmic liquid splash
  ]);

  const handleGenerate = () => {
    if (!prompt.trim()) return;
    setIsGenerating(true);

    setTimeout(() => {
      // Rotate or refresh with vibrant abstract art sets
      setGeneratedImages([
        'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=700&q=80',
        'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=700&q=80',
        'https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&w=700&q=80',
        'https://images.unsplash.com/photo-1634017839464-5c339ebe3cb4?auto=format&fit=crop&w=700&q=80',
      ]);
      setIsGenerating(false);
    }, 1200);
  };

  const handleSaveToProjects = (url: string, index: number) => {
    storageService.addProject({
      title: `${prompt.slice(0, 24)}... (Visual #${index + 1})`,
      category: 'image',
      description: `Generated with AMMU AI: ${prompt}`,
      previewUrl: url,
      size: '2.8 MB',
    });
    setSavedIndex(index);
    setTimeout(() => setSavedIndex(null), 2500);
  };

  return (
    <div className="flex flex-col h-full justify-between pb-2 text-white">
      {/* Header */}
      <div className="flex items-center justify-between py-1 mb-2">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full bg-[#1b0f30]/90 border border-purple-500/25 flex items-center justify-center text-white/90 hover:text-white hover:border-purple-400 transition-all shadow-md active:scale-95"
          aria-label="Back"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>

        <h2 className="text-[16px] font-bold tracking-tight text-white flex items-center gap-1.5">
          <Sparkles className="w-4 h-4 text-fuchsia-400" />
          <span>{t.imageGenTitle}</span>
        </h2>

        <button
          onClick={onOpenMenu}
          className="w-10 h-10 rounded-full bg-[#1b0f30]/90 border border-purple-500/25 flex items-center justify-center text-white/90 hover:text-white hover:border-purple-400 transition-all shadow-md active:scale-95"
          aria-label="Menu"
        >
          <Menu className="w-4 h-4" />
        </button>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto space-y-3 pr-0.5">
        {/* Prompt Input Box */}
        <div className="p-3 rounded-2xl bg-[#160a2b]/90 border border-purple-500/30 shadow-md">
          <label className="text-[11px] font-medium text-slate-300 block mb-1.5">
            {language === 'ta' ? 'பட விளக்கம் (Prompt)' : 'Visual Prompt'}
          </label>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder={t.imagePromptPlaceholder}
            rows={2}
            className="w-full bg-[#0d0519] border border-purple-500/20 rounded-xl p-2.5 text-xs text-white placeholder-slate-400 outline-none focus:border-purple-400 transition-colors resize-none"
          />

          {/* Quick Style Presets */}
          <div className="flex items-center gap-1.5 mt-2 overflow-x-auto pb-1 text-[10px]">
            {['Neon Cyber', 'Cosmic Fluid', '3D Gloss', 'Gold Glow'].map((preset) => (
              <button
                key={preset}
                onClick={() => setPrompt(p => `${p}, ${preset} style`)}
                className="px-2 py-0.5 rounded-full bg-purple-950/60 border border-purple-500/20 text-purple-200 hover:text-white hover:border-purple-400 shrink-0 transition-colors"
              >
                +{preset}
              </button>
            ))}
          </div>

          <button
            onClick={handleGenerate}
            disabled={isGenerating || !prompt.trim()}
            className="w-full mt-2 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 via-fuchsia-600 to-indigo-600 font-semibold text-xs text-white flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(168,85,247,0.4)] active:scale-98 transition-all disabled:opacity-50"
          >
            <Wand2 className={`w-3.5 h-3.5 ${isGenerating ? 'animate-spin' : ''}`} />
            <span>{isGenerating ? (language === 'ta' ? 'உருவாக்குகிறது...' : 'Generating 4 Visuals...') : t.generateImagesBtn}</span>
          </button>
        </div>

        {/* 4-Grid Graphic Artwork Showcase matching the screenshot! */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between px-1">
            <span className="text-[12px] font-semibold text-purple-200 flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-fuchsia-400" />
              <span>{language === 'ta' ? 'உருவாக்கப்பட்ட 4 கிராபிக் படங்கள்' : '4 Generated Graphic Artworks'}</span>
            </span>
            <span className="text-[10px] text-slate-400">4K UHD</span>
          </div>

          <div className="grid grid-cols-2 gap-2">
            {generatedImages.map((imgUrl, idx) => (
              <div
                key={idx}
                className="relative aspect-square rounded-2xl overflow-hidden group bg-black/60 border border-purple-500/25 shadow-lg"
              >
                <img
                  src={imgUrl}
                  alt={`Artwork ${idx + 1}`}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />

                {/* Glassmorphism Action Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity p-2 flex flex-col justify-end">
                  <div className="flex items-center justify-between gap-1">
                    <button
                      onClick={() => handleSaveToProjects(imgUrl, idx)}
                      className="p-1.5 rounded-lg bg-purple-900/80 border border-purple-400/30 text-white hover:bg-purple-700 transition-colors"
                      title="Save to My Projects"
                    >
                      {savedIndex === idx ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <FolderPlus className="w-3.5 h-3.5 text-purple-200" />
                      )}
                    </button>

                    <div className="flex items-center gap-1">
                      <a
                        href={imgUrl}
                        download={`ammu-graphic-${idx + 1}.jpg`}
                        target="_blank"
                        rel="noreferrer"
                        className="p-1.5 rounded-lg bg-purple-900/80 border border-purple-400/30 text-white hover:bg-purple-700 transition-colors"
                        title="Download"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </a>
                      <button
                        onClick={() => {
                          if (navigator.share) {
                            navigator.share({ title: 'AMMU AI Graphic', url: imgUrl }).catch(() => {});
                          }
                        }}
                        className="p-1.5 rounded-lg bg-purple-900/80 border border-purple-400/30 text-white hover:bg-purple-700 transition-colors"
                        title="Share"
                      >
                        <Share2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
