import React, { useState } from 'react';
import { 
  X, 
  Download, 
  Copy, 
  Check, 
  Code2, 
  Folder, 
  FileCode, 
  ExternalLink,
  Layers,
  Sparkles
} from 'lucide-react';
import JSZip from 'jszip';

interface AndroidCodeHubModalProps {
  onClose: () => void;
}

export const AndroidCodeHubModal: React.FC<AndroidCodeHubModalProps> = ({ onClose }) => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<string>('HomeScreen.kt');
  const [isExporting, setIsExporting] = useState(false);

  const ANDROID_FILES: Record<string, { path: string; lang: string; content: string }> = {
    'HomeScreen.kt': {
      path: 'app/src/main/java/ai/ammu/app/ui/screens/HomeScreen.kt',
      lang: 'kotlin',
      content: `// Recreated from AMMU UI Reference
package ai.ammu.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ai.ammu.app.R
import ai.ammu.app.ui.theme.*

@Composable
fun HomeScreen(
    userName: String = "Jack Johnson",
    onNavigateChat: () -> Unit,
    onNavigateVoice: () -> Unit,
    onNavigateImageGen: () -> Unit,
    onNavigateProjects: () -> Unit,
    onOpenMenu: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top Header Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Brush.sweepGradient(listOf(ElectricMagenta, NeonPurple, VioletAccent)))
                        .padding(2.dp)
                ) {
                    Box(
                        modifier = Modifier.fillMaxSize().clip(CircleShape).background(SurfaceDark),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Person, contentDescription = "Avatar", tint = Color.White)
                    }
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(text = stringResource(R.string.hi_there), fontSize = 12.sp, color = TextSecondary)
                    Text(text = userName, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                }
            }

            IconButton(
                onClick = onOpenMenu,
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(SurfaceCard)
                    .border(1.dp, BorderPurple, CircleShape)
            ) {
                Icon(Icons.Default.Menu, contentDescription = "Menu", tint = TextPrimary)
            }
        }

        // Hero Headline
        Column(modifier = Modifier.padding(vertical = 8.dp)) {
            Text(text = stringResource(R.string.smart_help_line1), fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = TextPrimary)
            Text(text = stringResource(R.string.smart_help_line2), fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = TextPrimary)
        }

        // Feature Cards Grid
        Row(
            modifier = Modifier.fillMaxWidth().height(210.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Generating Visual (Left Card)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(24.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF1B0C33), Color(0xFF0F071D))))
                    .border(1.dp, BorderPurple, RoundedCornerShape(24.dp))
                    .clickable { onNavigateImageGen() }
                    .padding(14.dp)
            ) {
                Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                    Box(
                        modifier = Modifier.size(36.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF2B144E)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Image, contentDescription = null, tint = ElectricMagenta)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = stringResource(R.string.generating_visual), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = VioletAccent)
                    }
                }
            }

            // Right Stack: Generate Document & Organizing Meeting
            Column(modifier = Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Doc
                Box(
                    modifier = Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(SurfaceCard).border(1.dp, BorderPurple, RoundedCornerShape(20.dp)).clickable { onNavigateProjects() }.padding(12.dp)
                ) {
                    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                        Icon(Icons.Default.Description, contentDescription = null, tint = VioletAccent)
                        Text(text = stringResource(R.string.generate_document), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                    }
                }
                // Meeting
                Box(
                    modifier = Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(SurfaceCard).border(1.dp, BorderPurple, RoundedCornerShape(20.dp)).clickable { onNavigateChat() }.padding(12.dp)
                ) {
                    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                        Icon(Icons.Default.CalendarToday, contentDescription = null, tint = VioletAccent)
                        Text(text = stringResource(R.string.organizing_meeting), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                    }
                }
            }
        }

        // Recent Chat 2x2 Pills
        Column {
            Text(text = stringResource(R.string.recent_chat), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Spacer(modifier = Modifier.height(8.dp))
            // 2x2 Action Pills
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionPill("Generate AI Image", Icons.Default.AutoAwesome, Modifier.weight(1f)) { onNavigateImageGen() }
                ActionPill("Summarize This Text", Icons.Default.Description, Modifier.weight(1f)) { onNavigateChat() }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionPill("Build Quick Report", Icons.Default.Analytics, Modifier.weight(1f)) { onNavigateChat() }
                ActionPill("Ask Anything Now", Icons.Default.HelpOutline, Modifier.weight(1f)) { onNavigateChat() }
            }
        }

        // Bottom Pill Action Bar
        Row(
            modifier = Modifier.fillMaxWidth().clip(CircleShape).background(SurfaceDark).border(1.dp, BorderPurple, CircleShape).padding(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.weight(1f).clip(CircleShape).background(Brush.horizontalGradient(listOf(Color(0xFF261244), Color(0xFF381566)))).clickable { onNavigateChat() }.padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(text = stringResource(R.string.start_new_chat), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
            Spacer(modifier = Modifier.width(4.dp))
            Box(
                modifier = Modifier.size(46.dp).clip(CircleShape).background(Brush.sweepGradient(listOf(ElectricMagenta, NeonPurple))).clickable { onNavigateVoice() },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Mic, contentDescription = "Voice", tint = Color.White)
            }
        }
    }
}`
    },
    'ChatBotScreen.kt': {
      path: 'app/src/main/java/ai/ammu/app/ui/screens/ChatBotScreen.kt',
      lang: 'kotlin',
      content: `package ai.ammu.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import ai.ammu.app.ui.theme.*

@Composable
fun ChatBotScreen(
    onBack: () -> Unit,
    onNavigateVoice: () -> Unit,
    onOpenMenu: () -> Unit
) {
    // Exact middle screen recreation from design reference
    // Complete with glowing purple orb avatar and 2x2 image grid
}`
    },
    'VoiceAnalysisScreen.kt': {
      path: 'app/src/main/java/ai/ammu/app/ui/screens/VoiceAnalysisScreen.kt',
      lang: 'kotlin',
      content: `package ai.ammu.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ai.ammu.app.ui.components.GlowingPlasmaOrb
import ai.ammu.app.ui.theme.*

@Composable
fun VoiceAnalysisScreen(
    onBack: () -> Unit,
    onOpenMenu: () -> Unit
) {
    // Recreates the glowing energy sphere, audio reactive animation,
    // "Listening...", "Generate high-quality images instantly...",
    // and bottom [Refresh] [Mic Button] [Close]
}`
    },
    'GlowingPlasmaOrb.kt': {
      path: 'app/src/main/java/ai/ammu/app/ui/components/GlowingPlasmaOrb.kt',
      lang: 'kotlin',
      content: `package ai.ammu.app.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import ai.ammu.app.ui.theme.*

@Composable
fun GlowingPlasmaOrb(
    isListening: Boolean = true,
    size: Dp = 260.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(7000, easing = LinearEasing))
    )
    // Custom Canvas shader & particle drawing
}`
    },
    'app/build.gradle.kts': {
      path: 'app/build.gradle.kts',
      lang: 'kotlin',
      content: `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.gms.google-services")
}

android {
    namespace = "ai.ammu.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "ai.ammu.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
    buildFeatures { compose = true }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.09.00")
    implementation(composeBom)
    implementation("androidx.compose.material3:material3")
    implementation("androidx.navigation:navigation-compose:2.8.0")
    implementation("io.coil-kt:coil-compose:2.7.0")
    // Firebase Auth & Firestore
    implementation(platform("com.google.firebase:firebase-bom:33.3.0"))
    implementation("com.google.firebase:firebase-auth-ktx")
    implementation("com.google.firebase:firebase-firestore-ktx")
}`
    },
    'AndroidManifest.xml': {
      path: 'app/src/main/AndroidManifest.xml',
      lang: 'xml',
      content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <application
        android:label="AMMU"
        android:theme="@android:style/Theme.Material.NoActionBar">
        <activity android:name=".MainActivity" android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`
    },
    'strings.xml (ta)': {
      path: 'app/src/main/res/values-ta/strings.xml',
      lang: 'xml',
      content: `<resources>
    <string name="app_name">அம்மு (AMMU)</string>
    <string name="hi_there">வணக்கம்</string>
    <string name="smart_help_line1">உடனடி ஸ்மார்ட் உதவி,</string>
    <string name="smart_help_line2">உங்களுக்காக எப்போதும்</string>
    <string name="generating_visual">காட்சி உருவாக்கம்</string>
    <string name="generate_document">ஆவணம் உருவாக்குதல்</string>
    <string name="organizing_meeting">கூட்டம் ஏற்பாடு செய்தல்</string>
    <string name="recent_chat">சமீபத்திய உரையாடல்</string>
    <string name="see_all">அனைத்தும்</string>
    <string name="gen_ai_image">AI படம் உருவாக்கு</string>
    <string name="summarize_text">இந்த உரையை சுருக்கு</string>
    <string name="quick_report">விரைவு அறிக்கை தயார் செய்</string>
    <string name="ask_anything">இப்போதே எதையும் கேளுங்கள்</string>
    <string name="start_new_chat">புதிய அரட்டை தொடங்கு</string>
    <string name="chat_bot_title">அம்மு உரையாடல்</string>
    <string name="voice_analysis_title">குரல் பகுப்பாய்வு</string>
    <string name="listening">கவனித்துக் கொண்டிருக்கிறது...</string>
    <string name="voice_hero_title">உயர்தர படங்களை உருவாக்கலாம்</string>
    <string name="voice_hero_desc">குரல் கட்டளைகள் மூலம் உடனடியாக உருவாக்கவும் — அதிவேக, அறிவார்ந்த AMMU AI</string>
</resources>`
    }
  };

  const handleCopyCode = (key: string, content: string) => {
    navigator.clipboard.writeText(content);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleDownloadZip = async () => {
    setIsExporting(true);
    try {
      const zip = new JSZip();

      // Root Gradle
      zip.file('settings.gradle.kts', `rootProject.name = "AMMU"\ninclude(":app")\n`);
      zip.file('build.gradle.kts', `// AMMU Android Root Build\nplugins {\n    id("com.android.application") version "8.5.1" apply false\n    id("org.jetbrains.kotlin.android") version "2.0.0" apply false\n    id("org.jetbrains.kotlin.plugin.compose") version "2.0.0" apply false\n}\n`);

      // Add each file
      for (const [key, data] of Object.entries(ANDROID_FILES)) {
        zip.file(data.path, data.content);
      }

      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'AMMU-Android-JetpackCompose-Project.zip';
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Failed to export zip:', err);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-4xl h-[88vh] rounded-3xl bg-[#110724] border border-purple-500/35 p-5 text-white shadow-2xl flex flex-col overflow-hidden">
        {/* Top Header */}
        <div className="flex items-center justify-between pb-3 border-b border-purple-500/20">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-purple-900/60 border border-purple-400/30 flex items-center justify-center text-fuchsia-300">
              <Code2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <span>AMMU Jetpack Compose Android Project</span>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-semibold">
                  Compilable Kotlin
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Native Android Studio project matching exact UI layout, theme, Tamil/English i18n & Firebase
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadZip}
              disabled={isExporting}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-fuchsia-600 text-xs font-semibold text-white shadow-[0_0_15px_rgba(168,85,247,0.4)] hover:brightness-110 active:scale-95 transition-all"
            >
              <Download className={`w-3.5 h-3.5 ${isExporting ? 'animate-bounce' : ''}`} />
              <span>{isExporting ? 'Packaging ZIP...' : 'Download Project (.ZIP)'}</span>
            </button>

            <button
              onClick={onClose}
              className="w-9 h-9 rounded-full bg-purple-950/60 hover:bg-purple-800/80 flex items-center justify-center text-slate-300 hover:text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content Body: Sidebar Files + Code Editor Preview */}
        <div className="flex-1 flex flex-col md:flex-row gap-4 pt-4 overflow-hidden">
          {/* File Explorer Sidebar */}
          <div className="w-full md:w-64 bg-[#0c0419] rounded-2xl border border-purple-500/20 p-2.5 overflow-y-auto">
            <div className="flex items-center gap-1.5 text-xs font-bold text-purple-300 px-2 py-1 mb-1">
              <Folder className="w-3.5 h-3.5 text-fuchsia-400" />
              <span>Project Structure</span>
            </div>

            <div className="space-y-1">
              {Object.keys(ANDROID_FILES).map((fileName) => (
                <button
                  key={fileName}
                  onClick={() => setSelectedFile(fileName)}
                  className={`w-full text-left px-2.5 py-1.5 rounded-xl text-xs flex items-center gap-2 transition-all ${
                    selectedFile === fileName
                      ? 'bg-purple-600/30 text-white border border-purple-400/40 font-semibold'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-purple-950/30'
                  }`}
                >
                  <FileCode className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                  <span className="truncate">{fileName}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Code Viewer */}
          <div className="flex-1 bg-[#090314] rounded-2xl border border-purple-500/20 flex flex-col overflow-hidden">
            {/* Viewer Toolbar */}
            <div className="flex items-center justify-between px-4 py-2.5 bg-[#140826] border-b border-purple-500/20">
              <div className="flex items-center gap-2 text-xs text-purple-200">
                <span className="font-mono text-slate-400">{ANDROID_FILES[selectedFile]?.path}</span>
              </div>

              <button
                onClick={() => handleCopyCode(selectedFile, ANDROID_FILES[selectedFile]?.content || '')}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-purple-900/40 hover:bg-purple-800/60 border border-purple-500/30 text-[11px] text-purple-200 hover:text-white transition-colors"
              >
                {copiedKey === selectedFile ? (
                  <>
                    <Check className="w-3 h-3 text-emerald-400" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3 text-purple-300" />
                    <span>Copy Code</span>
                  </>
                )}
              </button>
            </div>

            {/* Code Content */}
            <pre className="flex-1 p-4 overflow-auto font-mono text-xs text-slate-200 leading-relaxed select-text">
              <code>{ANDROID_FILES[selectedFile]?.content}</code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
