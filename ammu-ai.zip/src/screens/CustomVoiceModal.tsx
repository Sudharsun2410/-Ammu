import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Mic, 
  Upload, 
  Check, 
  Trash2, 
  Play, 
  Pause, 
  RotateCcw, 
  Volume2, 
  Sliders, 
  Sparkles, 
  ShieldCheck, 
  Info, 
  User, 
  Radio, 
  AudioWaveform as WaveformIcon,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { AppLanguage, VoiceAssistantConfig, VoiceProfile, VoiceSelectionType, VoiceBackendStatus } from '../types';
import { translations } from '../i18n/translations';
import { voiceCloneService } from '../services/voiceCloneService';

interface CustomVoiceModalProps {
  language: AppLanguage;
  voiceConfig: VoiceAssistantConfig;
  onUpdateConfig: (config: VoiceAssistantConfig) => void;
  onClose: () => void;
}

export const CustomVoiceModal: React.FC<CustomVoiceModalProps> = ({
  language,
  voiceConfig,
  onUpdateConfig,
  onClose,
}) => {
  const t = translations[language];

  // Active configuration
  const [selectedVoice, setSelectedVoice] = useState<VoiceSelectionType>(
    voiceConfig.selectedVoice || 'my-voice'
  );
  const [speed, setSpeed] = useState<number>(voiceConfig.rate || 1.0);
  const [pitch, setPitch] = useState<number>(voiceConfig.pitch || 1.0);

  // Recording State
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [audioLevel, setAudioLevel] = useState(0);
  const timerIntervalRef = useRef<any>(null);

  // Audio Sample State
  const [recordedAudioBase64, setRecordedAudioBase64] = useState<string | null>(null);
  const [recordedBlob, setRecordedBlob] = useState<Blob | null>(null);
  const [sampleDuration, setSampleDuration] = useState<number>(0);
  const [sampleFormat, setSampleFormat] = useState<string>('audio/wav');
  const [sampleFileName, setSampleFileName] = useState<string>('');

  // Audio Player Preview
  const [isPlayingSample, setIsPlayingSample] = useState(false);
  const sampleAudioRef = useRef<HTMLAudioElement | null>(null);

  // Voice Profile & Consent
  const [profileName, setProfileName] = useState('My Voice Profile');
  const [consentChecked, setConsentChecked] = useState(voiceCloneService.hasUserConsented());
  const [isTraining, setIsTraining] = useState(false);
  const [trainingMessage, setTrainingMessage] = useState<string | null>(null);
  const [activeProfile, setActiveProfile] = useState<VoiceProfile | null>(voiceCloneService.getActiveProfile());

  // Backend API Status & Pricing
  const [backendStatus, setBackendStatus] = useState<VoiceBackendStatus | null>(null);
  const [showPricingModal, setShowPricingModal] = useState(false);
  const [previewTestPlaying, setPreviewTestPlaying] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Load backend status on mount
  useEffect(() => {
    voiceCloneService.fetchBackendStatus().then(setBackendStatus);
    const existing = voiceCloneService.getActiveProfile();
    if (existing) {
      setActiveProfile(existing);
      setProfileName(existing.name);
    }
  }, []);

  // Timer logic for recording
  useEffect(() => {
    if (isRecording) {
      setRecordingSeconds(0);
      timerIntervalRef.current = setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
      }
    }
    return () => {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    };
  }, [isRecording]);

  // Handle Record My Voice
  const handleToggleRecording = async () => {
    setErrorMessage(null);
    if (isRecording) {
      try {
        const result = await voiceCloneService.stopRecording();
        setIsRecording(false);
        setRecordedBlob(result.blob);
        setRecordedAudioBase64(result.base64);
        setSampleDuration(result.durationSec);
        setSampleFormat('audio/wav');
        setSampleFileName('voice_recording.wav');
      } catch (err: any) {
        setIsRecording(false);
        setErrorMessage(err.message || 'Failed to stop recording.');
      }
    } else {
      try {
        await voiceCloneService.startRecording((level) => {
          setAudioLevel(level);
        });
        setIsRecording(true);
      } catch (err: any) {
        setErrorMessage(err.message || 'Failed to access microphone. Please check permissions.');
      }
    }
  };

  // Handle File Upload
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setErrorMessage(null);

    try {
      const result = await voiceCloneService.processUploadedAudio(file);
      setRecordedBlob(result.blob);
      setRecordedAudioBase64(result.base64);
      setSampleDuration(result.durationSec);
      setSampleFormat(result.format);
      setSampleFileName(file.name);
      setProfileName(file.name.replace(/\.[^/.]+$/, ''));
    } catch (err: any) {
      setErrorMessage(err.message || 'Upload failed.');
    }
  };

  // Play Sample Preview
  const handlePlaySample = () => {
    if (!recordedAudioBase64) return;
    if (isPlayingSample && sampleAudioRef.current) {
      sampleAudioRef.current.pause();
      setIsPlayingSample(false);
      return;
    }

    const audio = new Audio(recordedAudioBase64);
    sampleAudioRef.current = audio;
    setIsPlayingSample(true);
    audio.onended = () => setIsPlayingSample(false);
    audio.onerror = () => setIsPlayingSample(false);
    audio.play().catch(() => setIsPlayingSample(false));
  };

  // Clear Audio Sample
  const handleClearSample = () => {
    if (sampleAudioRef.current) {
      sampleAudioRef.current.pause();
    }
    setRecordedAudioBase64(null);
    setRecordedBlob(null);
    setSampleDuration(0);
    setSampleFileName('');
    setIsPlayingSample(false);
  };

  // Train / Create Voice Profile
  const handleTrainProfile = async () => {
    if (!recordedAudioBase64) {
      setErrorMessage('Please record or upload your voice sample first.');
      return;
    }
    if (!consentChecked) {
      setErrorMessage('Explicit consent is required to clone and create your AI voice profile.');
      return;
    }

    setErrorMessage(null);
    setIsTraining(true);
    setTrainingMessage('Analyzing acoustic timbre, pitch distribution and training neural profile...');

    try {
      const newProfile = await voiceCloneService.createVoiceProfile(
        profileName || 'My Voice',
        recordedAudioBase64,
        sampleFormat,
        sampleDuration,
        consentChecked
      );

      setActiveProfile(newProfile);
      setSelectedVoice('my-voice');
      voiceCloneService.saveActiveVoiceSelection('my-voice');

      setTrainingMessage('Voice profile created successfully! AMMU will now speak in your own voice.');
      setTimeout(() => {
        setIsTraining(false);
        setTrainingMessage(null);
      }, 2500);
    } catch (err: any) {
      setIsTraining(false);
      setErrorMessage(err.message || 'Failed to train voice profile.');
    }
  };

  // Delete Voice Profile
  const handleDeleteProfile = async () => {
    if (!activeProfile) return;
    if (confirm('Are you sure you want to delete your custom voice profile and all stored acoustic samples?')) {
      await voiceCloneService.deleteProfile(activeProfile.id);
      setActiveProfile(null);
      handleClearSample();
      setSelectedVoice('female');
      voiceCloneService.saveActiveVoiceSelection('female');
    }
  };

  // Preview Voice Speech
  const handlePreviewSpeech = async () => {
    setPreviewTestPlaying(true);
    setErrorMessage(null);

    const testText = language === 'ta'
      ? 'வணக்கம்! இது உங்கள் AMMU AI குரல் உதவியாளர். எனது குரல் உங்களுக்குப் பிடித்துள்ளதா?'
      : 'Hello! This is AMMU speaking in your selected voice. How does it sound to you?';

    await voiceCloneService.speakText(
      testText,
      selectedVoice,
      speed,
      pitch,
      () => setPreviewTestPlaying(true),
      () => setPreviewTestPlaying(false),
      (err) => {
        setPreviewTestPlaying(false);
        setErrorMessage(typeof err === 'string' ? err : 'Speech playback failed.');
      }
    );
  };

  // Save and Close
  const handleSaveAndClose = () => {
    const updated: VoiceAssistantConfig = {
      ...voiceConfig,
      selectedVoice,
      femaleVoice: selectedVoice === 'female',
      pitch,
      rate: speed,
      activeProfile,
      hasCustomVoice: Boolean(activeProfile),
      customVoiceName: activeProfile?.name || 'My Voice',
    };
    voiceCloneService.saveActiveVoiceSelection(selectedVoice);
    onUpdateConfig(updated);
    onClose();
  };

  const formatTime = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-xl max-h-[92vh] rounded-[32px] bg-[#120726] border border-purple-500/35 p-5 sm:p-6 text-white shadow-[0_20px_70px_rgba(0,0,0,0.85)] flex flex-col overflow-hidden relative">
        {/* Top Header */}
        <div className="flex items-center justify-between pb-3.5 border-b border-purple-500/20 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-fuchsia-600 to-purple-600 flex items-center justify-center text-white shadow-[0_0_15px_rgba(168,85,247,0.5)]">
              <Mic className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <span>AMMU Voice Cloning & Assistant</span>
                <span className="px-2 py-0.5 rounded-full bg-purple-500/20 border border-purple-400/30 text-[10px] font-semibold text-purple-300">
                  Dual-Engine
                </span>
              </h3>
              <p className="text-[11px] text-purple-300/80">
                Clone your personal voice for seamless Tamil & English AI responses
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowPricingModal(!showPricingModal)}
              className="px-2.5 py-1.5 rounded-xl bg-purple-950/60 hover:bg-purple-900 border border-purple-500/30 text-[11px] text-purple-300 hover:text-white flex items-center gap-1 transition-colors"
              title="API Subscription & Usage Details"
            >
              <Info className="w-3.5 h-3.5 text-fuchsia-400" />
              <span>API Pricing</span>
            </button>
            <button
              onClick={onClose}
              className="w-9 h-9 rounded-full bg-purple-950/60 hover:bg-purple-800/80 flex items-center justify-center text-slate-300 hover:text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Pricing / Status Banner */}
        {showPricingModal && (
          <div className="my-3 p-3.5 rounded-2xl bg-[#1b0c36] border border-purple-500/40 text-xs text-slate-200 space-y-2 shrink-0 animate-fadeIn">
            <div className="flex items-center justify-between font-bold text-purple-200">
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>AI Voice Cloning API & Subscription Information</span>
              </span>
              <button
                onClick={() => setShowPricingModal(false)}
                className="text-slate-400 hover:text-white text-xs"
              >
                ✕
              </button>
            </div>
            <p className="text-[11px] leading-relaxed text-slate-300">
              {backendStatus?.pricingInfo?.elevenlabs ||
                'ElevenLabs Instant Voice Cloning creates photorealistic voice clones in Tamil & English. Free tier provides 10,000 chars/month. Starter plan ($5/mo) unlocks Instant Voice Cloning.'}
            </p>
            <div className="p-2 rounded-xl bg-purple-950/70 border border-purple-500/30 flex items-center justify-between text-[11px]">
              <span>ElevenLabs Cloud API:</span>
              <span
                className={`font-semibold ${
                  backendStatus?.elevenLabsConfigured ? 'text-emerald-400' : 'text-amber-300'
                }`}
              >
                {backendStatus?.elevenLabsConfigured ? '● Connected' : '○ Offline (Using Neural Acoustic Engine)'}
              </span>
            </div>
          </div>
        )}

        {/* Error notification */}
        {errorMessage && (
          <div className="my-2 p-2.5 rounded-xl bg-rose-950/80 border border-rose-500/40 text-xs text-rose-200 flex items-center gap-2 shrink-0">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Scrollable Content Body */}
        <div className="flex-1 overflow-y-auto pr-1 py-3 space-y-5">
          {/* SECTION 1: VOICE SELECTION (FEATURE 3) */}
          <div className="space-y-2.5">
            <label className="text-xs font-bold uppercase tracking-wider text-purple-300 flex items-center gap-1.5">
              <Sliders className="w-3.5 h-3.5 text-fuchsia-400" />
              <span>Select Active Voice</span>
            </label>

            <div className="grid grid-cols-3 gap-2">
              {/* Option 1: My Voice */}
              <button
                type="button"
                onClick={() => setSelectedVoice('my-voice')}
                className={`p-3 rounded-2xl border text-left flex flex-col justify-between transition-all ${
                  selectedVoice === 'my-voice'
                    ? 'bg-gradient-to-br from-purple-900/90 to-fuchsia-950/90 border-purple-400 shadow-[0_0_18px_rgba(168,85,247,0.4)] text-white'
                    : 'bg-[#180a2f]/80 border-purple-500/20 text-slate-300 hover:border-purple-400/50'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="w-7 h-7 rounded-xl bg-purple-600/30 flex items-center justify-center text-fuchsia-300">
                    <User className="w-4 h-4" />
                  </div>
                  {selectedVoice === 'my-voice' && (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  )}
                </div>
                <div>
                  <p className="text-xs font-bold text-white">My Voice</p>
                  <p className="text-[10px] text-purple-300/80 truncate">
                    {activeProfile ? activeProfile.name : 'Not yet created'}
                  </p>
                </div>
              </button>

              {/* Option 2: Female AI Voice */}
              <button
                type="button"
                onClick={() => setSelectedVoice('female')}
                className={`p-3 rounded-2xl border text-left flex flex-col justify-between transition-all ${
                  selectedVoice === 'female'
                    ? 'bg-gradient-to-br from-purple-900/90 to-fuchsia-950/90 border-purple-400 shadow-[0_0_18px_rgba(168,85,247,0.4)] text-white'
                    : 'bg-[#180a2f]/80 border-purple-500/20 text-slate-300 hover:border-purple-400/50'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="w-7 h-7 rounded-xl bg-purple-600/30 flex items-center justify-center text-pink-300">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  {selectedVoice === 'female' && (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  )}
                </div>
                <div>
                  <p className="text-xs font-bold text-white">Female AI</p>
                  <p className="text-[10px] text-slate-400">AMMU Voice</p>
                </div>
              </button>

              {/* Option 3: Male AI Voice */}
              <button
                type="button"
                onClick={() => setSelectedVoice('male')}
                className={`p-3 rounded-2xl border text-left flex flex-col justify-between transition-all ${
                  selectedVoice === 'male'
                    ? 'bg-gradient-to-br from-purple-900/90 to-fuchsia-950/90 border-purple-400 shadow-[0_0_18px_rgba(168,85,247,0.4)] text-white'
                    : 'bg-[#180a2f]/80 border-purple-500/20 text-slate-300 hover:border-purple-400/50'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="w-7 h-7 rounded-xl bg-purple-600/30 flex items-center justify-center text-cyan-300">
                    <WaveformIcon className="w-4 h-4" />
                  </div>
                  {selectedVoice === 'male' && (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  )}
                </div>
                <div>
                  <p className="text-xs font-bold text-white">Male AI</p>
                  <p className="text-[10px] text-slate-400">Deep & Clear</p>
                </div>
              </button>
            </div>
          </div>

          {/* SECTION 2: ACTIVE VOICE PROFILE CARD (FEATURE 2 & 5) */}
          <div className="p-4 rounded-2xl bg-[#190a33] border border-purple-500/30 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-fuchsia-500 to-purple-600 flex items-center justify-center text-white">
                  <User className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">
                    {activeProfile ? activeProfile.name : 'No Voice Profile Created Yet'}
                  </h4>
                  <p className="text-[10px] text-purple-300/80">
                    {activeProfile
                      ? `Trained (${activeProfile.audioDurationSec}s sample • ${activeProfile.cloneProvider})`
                      : 'Record or upload your voice below to clone your voice'}
                  </p>
                </div>
              </div>

              {activeProfile && (
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={handleDeleteProfile}
                    className="p-1.5 rounded-xl bg-rose-950/50 border border-rose-500/30 text-rose-300 hover:text-white hover:bg-rose-900 transition-colors"
                    title="Delete Voice Profile"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>

            {/* Quick Preview Test Button */}
            <div className="flex items-center gap-2 pt-1">
              <button
                onClick={handlePreviewSpeech}
                disabled={previewTestPlaying || (selectedVoice === 'my-voice' && !activeProfile)}
                className="flex-1 py-2 px-3 rounded-xl bg-purple-900/60 hover:bg-purple-800/80 border border-purple-400/40 text-xs font-semibold text-purple-100 flex items-center justify-center gap-2 transition-all disabled:opacity-40"
              >
                <Volume2 className={`w-3.5 h-3.5 ${previewTestPlaying ? 'animate-bounce text-fuchsia-300' : ''}`} />
                <span>
                  {previewTestPlaying
                    ? 'Speaking in ' + selectedVoice + '...'
                    : `Preview ${selectedVoice === 'my-voice' ? 'My Voice' : selectedVoice === 'female' ? 'Female Voice' : 'Male Voice'}`}
                </span>
              </button>
            </div>
          </div>

          {/* SECTION 3: PERSONAL VOICE INPUT - RECORD OR UPLOAD (FEATURE 1) */}
          <div className="p-4 rounded-2xl bg-[#16092d] border border-purple-500/25 space-y-4">
            <div>
              <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                <Mic className="w-4 h-4 text-fuchsia-400" />
                <span>Personal Voice Input (Record or Upload)</span>
              </h4>
              <p className="text-[10px] text-slate-400 mt-0.5">
                Record at least 5-15 seconds of your normal speaking voice in English or Tamil.
              </p>
            </div>

            {/* Recording Controls */}
            <div className="flex flex-col items-center justify-center p-4 rounded-2xl bg-[#1d0c38] border border-purple-500/20 space-y-3">
              {/* Record Button with Animated Outer Wave */}
              <div className="relative">
                {isRecording && (
                  <div
                    className="absolute inset-0 rounded-full bg-fuchsia-500/30 animate-ping -z-10"
                    style={{ transform: `scale(${1 + audioLevel / 60})` }}
                  />
                )}
                <button
                  type="button"
                  onClick={handleToggleRecording}
                  className={`w-16 h-16 rounded-full flex flex-col items-center justify-center transition-all shadow-[0_0_25px_rgba(168,85,247,0.5)] active:scale-95 ${
                    isRecording
                      ? 'bg-rose-600 border-2 border-white text-white'
                      : 'bg-gradient-to-tr from-purple-600 via-fuchsia-600 to-indigo-600 border border-purple-300/40 text-white'
                  }`}
                >
                  <Mic className="w-6 h-6" />
                </button>
              </div>

              {/* Status and timer */}
              <div className="text-center">
                <p className="text-xs font-bold text-white">
                  {isRecording ? 'Recording your voice...' : 'Tap to Record My Voice'}
                </p>
                <p className="text-[11px] font-mono text-purple-300">
                  {isRecording ? formatTime(recordingSeconds) : 'Speak a short sentence'}
                </p>
              </div>

              {/* Live soundwave activity bars during recording */}
              {isRecording && (
                <div className="flex items-center gap-1 h-5">
                  {[20, 45, 80, 100, 60, 90, 70, 40].map((h, i) => (
                    <span
                      key={i}
                      className="w-1 rounded-full bg-fuchsia-400 animate-pulse"
                      style={{
                        height: `${Math.max(4, (h * audioLevel) / 100)}px`,
                        animationDelay: `${i * 0.05}s`,
                      }}
                    />
                  ))}
                </div>
              )}
            </div>

            {/* OR Upload Audio File Option */}
            <div className="relative flex py-1 items-center">
              <div className="flex-grow border-t border-purple-500/20" />
              <span className="flex-shrink mx-3 text-[10px] text-purple-300/70 font-semibold uppercase">
                Or Upload File
              </span>
              <div className="flex-grow border-t border-purple-500/20" />
            </div>

            <label className="flex items-center justify-between p-3 rounded-xl border border-dashed border-purple-400/40 hover:border-purple-300 bg-purple-950/20 cursor-pointer transition-colors">
              <div className="flex items-center gap-2.5">
                <Upload className="w-4 h-4 text-purple-300" />
                <div>
                  <p className="text-xs font-medium text-purple-200">
                    Upload Audio (WAV, MP3, M4A)
                  </p>
                  <p className="text-[10px] text-slate-400">Up to 25MB supported</p>
                </div>
              </div>
              <span className="text-[11px] font-semibold text-fuchsia-400 hover:underline">
                Browse
              </span>
              <input
                type="file"
                accept="audio/wav,audio/mp3,audio/mpeg,audio/m4a,audio/x-m4a,audio/webm"
                onChange={handleFileUpload}
                className="hidden"
              />
            </label>

            {/* Audio Preview & Playback Controls if sample is loaded */}
            {recordedAudioBase64 && (
              <div className="p-3 rounded-xl bg-purple-950/50 border border-purple-400/30 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-white truncate max-w-[200px]">
                    {sampleFileName || 'Recorded Sample'} ({sampleDuration}s)
                  </span>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={handlePlaySample}
                      className="p-1.5 rounded-lg bg-purple-800 text-white hover:bg-purple-700 flex items-center gap-1 text-xs"
                    >
                      {isPlayingSample ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                      <span>{isPlayingSample ? 'Pause' : 'Play'}</span>
                    </button>
                    <button
                      onClick={handleClearSample}
                      className="p-1.5 rounded-lg bg-purple-900/50 text-slate-300 hover:text-white"
                      title="Re-record / Delete Sample"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* SECTION 4: TRAIN / CREATE VOICE PROFILE WITH CONSENT (FEATURE 2 & 5) */}
          <div className="p-4 rounded-2xl bg-[#190a33] border border-purple-500/30 space-y-3">
            <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-fuchsia-400" />
              <span>Train / Create Custom Voice Profile</span>
            </h4>

            <div>
              <label className="text-[11px] text-slate-300 block mb-1">
                Voice Profile Name:
              </label>
              <input
                type="text"
                value={profileName}
                onChange={(e) => setProfileName(e.target.value)}
                placeholder="e.g. My Authentic Voice"
                className="w-full bg-[#110524] border border-purple-500/30 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-purple-400"
              />
            </div>

            {/* Mandatory Explicit Consent Checkbox as required by Feature 2 */}
            <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-500/20 space-y-1.5">
              <label className="flex items-start gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={consentChecked}
                  onChange={(e) => setConsentChecked(e.target.checked)}
                  className="mt-0.5 rounded border-purple-400 text-purple-600 focus:ring-purple-500"
                />
                <span className="text-[11px] text-slate-200 leading-snug">
                  <strong>Explicit Voice Consent:</strong> I verify that this voice sample is my own authentic voice, and I explicitly grant AMMU permission to train and synthesize AI speech in my voice.
                </span>
              </label>
            </div>

            {/* Train Button */}
            <button
              onClick={handleTrainProfile}
              disabled={isTraining || !recordedAudioBase64 || !consentChecked}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-purple-600 via-fuchsia-600 to-indigo-600 text-xs font-bold text-white flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(168,85,247,0.4)] active:scale-98 transition-all disabled:opacity-40"
            >
              <Sparkles className={`w-4 h-4 ${isTraining ? 'animate-spin' : ''}`} />
              <span>{isTraining ? 'Training Voice Model...' : 'Train / Create Voice Profile'}</span>
            </button>

            {trainingMessage && (
              <p className="text-[11px] text-emerald-300 text-center animate-fadeIn">
                {trainingMessage}
              </p>
            )}
          </div>

          {/* SECTION 5: SPEED & PITCH FINE-TUNING */}
          <div className="p-4 rounded-2xl bg-[#16092d] border border-purple-500/25 space-y-3">
            <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
              <Sliders className="w-4 h-4 text-purple-400" />
              <span>Speech Rate & Pitch Fine-Tuning</span>
            </h4>

            {/* Speed Slider */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs text-slate-300">
                <span>Speaking Speed</span>
                <span className="text-purple-300 font-semibold">{speed.toFixed(2)}x</span>
              </div>
              <input
                type="range"
                min="0.75"
                max="1.35"
                step="0.05"
                value={speed}
                onChange={(e) => setSpeed(parseFloat(e.target.value))}
                className="w-full accent-fuchsia-500"
              />
            </div>

            {/* Pitch Slider */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs text-slate-300">
                <span>Vocal Pitch</span>
                <span className="text-purple-300 font-semibold">{pitch.toFixed(2)}x</span>
              </div>
              <input
                type="range"
                min="0.8"
                max="1.3"
                step="0.05"
                value={pitch}
                onChange={(e) => setPitch(parseFloat(e.target.value))}
                className="w-full accent-fuchsia-500"
              />
            </div>
          </div>
        </div>

        {/* Modal Action Footer */}
        <div className="pt-3 border-t border-purple-500/20 flex items-center gap-2 shrink-0">
          <button
            onClick={onClose}
            className="flex-1 py-2.5 rounded-xl bg-purple-950/60 hover:bg-purple-900/80 border border-purple-500/30 text-xs font-semibold text-slate-300 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleSaveAndClose}
            className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 via-fuchsia-600 to-indigo-600 text-xs font-bold text-white shadow-[0_0_15px_rgba(168,85,247,0.4)] hover:brightness-110 active:scale-98 transition-all flex items-center justify-center gap-1.5"
          >
            <Check className="w-3.5 h-3.5" />
            <span>Apply Voice Settings</span>
          </button>
        </div>
      </div>
    </div>
  );
};
