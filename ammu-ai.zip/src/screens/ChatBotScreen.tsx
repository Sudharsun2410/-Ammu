import React, { useState, useRef, useEffect } from 'react';
import { 
  ChevronLeft, 
  Menu, 
  Plus, 
  Mic, 
  Send, 
  Copy, 
  Share2, 
  Download, 
  Check, 
  Volume2,
  Sparkles,
  RefreshCw
} from 'lucide-react';
import { AppLanguage, ChatMessage, VoiceAssistantConfig } from '../types';
import { translations } from '../i18n/translations';
import { geminiService } from '../services/geminiService';
import { ttsService } from '../services/ttsService';
import { storageService } from '../services/storageService';

interface ChatBotScreenProps {
  language: AppLanguage;
  onBack: () => void;
  onOpenVoice: () => void;
  onOpenMenu: () => void;
  voiceConfig: VoiceAssistantConfig;
  initialPrompt?: string;
}

export const ChatBotScreen: React.FC<ChatBotScreenProps> = ({
  language,
  onBack,
  onOpenVoice,
  onOpenMenu,
  voiceConfig,
  initialPrompt = '',
}) => {
  const t = translations[language];
  const [inputText, setInputText] = useState(initialPrompt);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isTyping, setIsTyping] = useState(false);
  const [activeSpeechId, setActiveSpeechId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  // Exact 4 graphic images matching the screenshot reference
  const REFERENCE_GRAPHICS = [
    'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=500&q=80', // Golden glowing fractal ring
    'https://images.unsplash.com/photo-1634017839464-5c339ebe3cb4?auto=format&fit=crop&w=500&q=80', // Neon 3D sphere helmet
    'https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&w=500&q=80', // Vibrant powder explosion
    'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?auto=format&fit=crop&w=500&q=80', // Cosmic liquid splash
  ];

  // Default seed messages strictly reproducing the screenshot
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const saved = storageService.getChatHistory();
    if (saved && saved.length > 0) return saved;

    return [
      {
        id: 'msg-1',
        sender: 'user',
        text: t.sampleChatQ1,
        timestamp: '9:28 PM',
      },
      {
        id: 'msg-2',
        sender: 'bot',
        text: t.sampleChatA1,
        timestamp: '9:28 PM',
      },
      {
        id: 'msg-3',
        sender: 'user',
        text: t.sampleChatQ2,
        timestamp: '9:29 PM',
      },
      {
        id: 'msg-4',
        sender: 'bot',
        text: t.sampleChatA2,
        timestamp: '9:30 PM',
        imageGrid: REFERENCE_GRAPHICS,
      },
    ];
  });

  useEffect(() => {
    storageService.saveChatHistory(messages);
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async (textToSend?: string) => {
    const text = (textToSend ?? inputText).trim();
    if (!text) return;

    const userMsg: ChatMessage = {
      id: 'usr-' + Date.now(),
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages(prev => [...prev, userMsg]);
    setInputText('');
    setIsTyping(true);

    try {
      const response = await geminiService.generateChatResponse(
        text,
        messages.map(m => ({ sender: m.sender, text: m.text })),
        language
      );

      const botMsg: ChatMessage = {
        id: 'bot-' + Date.now(),
        sender: 'bot',
        text: response.text,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        imageGrid: response.imageGrid,
      };

      setMessages(prev => [...prev, botMsg]);

      // Automatically speak with selected voice (My Voice / Female / Male) if configured
      if (voiceConfig.selectedVoice) {
        setActiveSpeechId(botMsg.id);
        ttsService.speak(botMsg.text, language, voiceConfig, () => {
          setActiveSpeechId(null);
        });
      }
    } catch (err) {
      console.error('Chat error:', err);
    } finally {
      setIsTyping(false);
    }
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handlePlayVoice = (id: string, text: string) => {
    if (activeSpeechId === id && ttsService.isSpeaking()) {
      ttsService.stop();
      setActiveSpeechId(null);
      return;
    }
    setActiveSpeechId(id);
    ttsService.speak(text, language, voiceConfig, () => {
      setActiveSpeechId(null);
    });
  };

  const handleDownloadImage = (url: string, index: number) => {
    const a = document.createElement('a');
    a.href = url;
    a.download = `ammu-graphic-${index + 1}.jpg`;
    a.target = '_blank';
    a.click();
  };

  return (
    <div className="flex flex-col h-full justify-between pb-1 text-white">
      {/* Header Row */}
      <div className="flex items-center justify-between py-1 mb-2">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full bg-[#1b0f30]/90 border border-purple-500/25 flex items-center justify-center text-white/90 hover:text-white hover:border-purple-400 transition-all shadow-md active:scale-95"
          aria-label="Back"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <h2 className="text-[16px] font-bold tracking-tight text-white">
            {t.chatBotTitle}
          </h2>
        </div>

        <button
          onClick={onOpenMenu}
          className="w-10 h-10 rounded-full bg-[#1b0f30]/90 border border-purple-500/25 flex items-center justify-center text-white/90 hover:text-white hover:border-purple-400 transition-all shadow-md active:scale-95"
          aria-label="Menu"
        >
          <Menu className="w-4 h-4" />
        </button>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto pr-1 space-y-4 pt-2">
        {messages.map((msg) => {
          const isUser = msg.sender === 'user';

          if (isUser) {
            return (
              <div key={msg.id} className="flex justify-end pl-8">
                <div className="px-4 py-3 rounded-[22px] rounded-tr-md bg-[#22103d] border border-purple-500/30 text-white text-[13px] leading-relaxed shadow-lg max-w-[85%]">
                  <p>{msg.text}</p>
                </div>
              </div>
            );
          }

          // Bot Message
          return (
            <div key={msg.id} className="flex items-start gap-2.5 pr-4">
              {/* Glowing Purple Orb Avatar matching screenshot */}
              <div className="w-8 h-8 rounded-full p-[1.5px] bg-gradient-to-tr from-fuchsia-500 via-purple-500 to-indigo-500 flex items-center justify-center shrink-0 shadow-[0_0_10px_rgba(168,85,247,0.5)]">
                <div className="w-full h-full rounded-full bg-[#10061e] flex items-center justify-center overflow-hidden">
                  <div className="w-3.5 h-3.5 rounded-full bg-gradient-to-r from-fuchsia-400 to-purple-300 animate-pulse-slow shadow-[0_0_6px_#c026d3]" />
                </div>
              </div>

              {/* Message Bubble + Actions */}
              <div className="flex-1 space-y-2">
                <div className="px-4 py-3 rounded-[22px] rounded-tl-md bg-[#160a29]/95 border border-purple-500/25 text-white text-[13px] leading-relaxed shadow-lg">
                  <p className="text-slate-100">{msg.text}</p>

                  {/* 2x2 Graphic Pictures Grid matching screenshot */}
                  {msg.imageGrid && msg.imageGrid.length > 0 && (
                    <div className="mt-3 grid grid-cols-2 gap-1.5 p-1 rounded-2xl bg-[#0e051a]/80 border border-purple-500/20">
                      {msg.imageGrid.map((imgUrl, idx) => (
                        <div
                          key={idx}
                          className="relative aspect-square rounded-xl overflow-hidden group bg-black/50 border border-purple-500/15"
                        >
                          <img
                            src={imgUrl}
                            alt={`AMMU generated graphic ${idx + 1}`}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-1.5">
                            <button
                              onClick={() => handleDownloadImage(imgUrl, idx)}
                              className="p-1.5 rounded-full bg-purple-900/90 text-white hover:bg-purple-700 transition-colors"
                              title="Download"
                            >
                              <Download className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Sub-actions under message: [Copy] [Share] [Voice] */}
                <div className="flex items-center gap-2 pl-1">
                  <button
                    onClick={() => handleCopy(msg.id, msg.text)}
                    className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-[#190b2e]/80 border border-purple-500/20 text-[10px] font-medium text-slate-300 hover:text-white hover:border-purple-400 transition-colors"
                  >
                    {copiedId === msg.id ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-400" />
                        <span>{t.copied}</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3 text-purple-300" />
                        <span>{t.copy}</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={() => {
                      if (navigator.share) {
                        navigator.share({ text: msg.text, title: 'AMMU AI Assistant' }).catch(() => {});
                      } else {
                        handleCopy(msg.id, msg.text);
                      }
                    }}
                    className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-[#190b2e]/80 border border-purple-500/20 text-[10px] font-medium text-slate-300 hover:text-white hover:border-purple-400 transition-colors"
                  >
                    <Share2 className="w-3 h-3 text-purple-300" />
                    <span>{t.share}</span>
                  </button>

                  {/* Selected Voice TTS playback button */}
                  <button
                    onClick={() => handlePlayVoice(msg.id, msg.text)}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded-full border text-[10px] font-medium transition-colors ${
                      activeSpeechId === msg.id
                        ? 'bg-purple-600/40 border-purple-400 text-white shadow-[0_0_8px_#c026d3]'
                        : 'bg-[#190b2e]/80 border-purple-500/20 text-slate-300 hover:text-white'
                    }`}
                    title={`Speak with ${voiceConfig.selectedVoice === 'my-voice' ? 'My Voice' : voiceConfig.selectedVoice === 'male' ? 'Male AI Voice' : 'Female AI Voice'}`}
                  >
                    <Volume2 className={`w-3 h-3 ${activeSpeechId === msg.id ? 'animate-pulse text-fuchsia-300' : 'text-purple-300'}`} />
                    <span>{voiceConfig.selectedVoice === 'my-voice' ? 'My Voice' : 'TTS'}</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}

        {isTyping && (
          <div className="flex items-start gap-2.5 pl-1">
            <div className="w-7 h-7 rounded-full bg-[#200f3a] border border-purple-500/40 flex items-center justify-center">
              <RefreshCw className="w-3.5 h-3.5 text-purple-300 animate-spin" />
            </div>
            <div className="px-4 py-2.5 rounded-2xl bg-[#160a29] border border-purple-500/20 text-xs text-purple-300 flex items-center gap-1.5">
              <span>AMMU is thinking</span>
              <span className="flex gap-0.5">
                <span className="w-1 h-1 bg-purple-400 rounded-full animate-bounce [animation-delay:-0.3s]" />
                <span className="w-1 h-1 bg-purple-400 rounded-full animate-bounce [animation-delay:-0.15s]" />
                <span className="w-1 h-1 bg-purple-400 rounded-full animate-bounce" />
              </span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Bottom Input Bar matching screenshot */}
      <div className="pt-2">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="flex items-center gap-1.5 p-1.5 rounded-full bg-[#170a2a]/95 border border-purple-500/35 shadow-[0_4px_25px_rgba(0,0,0,0.5)] focus-within:border-purple-400/80 transition-all"
        >
          {/* Plus icon on left */}
          <button
            type="button"
            onClick={() => {
              // Add a quick visual request prompt
              setInputText(language === 'ta' ? 'அழகான கிராபிக் படங்களை உருவாக்குங்கள்' : 'Generate 4 cool graphic pictures');
            }}
            className="w-8 h-8 rounded-full bg-purple-900/40 hover:bg-purple-800/60 flex items-center justify-center text-purple-300 transition-colors"
            title="Add Prompt Preset"
          >
            <Plus className="w-4 h-4" />
          </button>

          {/* Text Input */}
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={t.askAiPlaceholder}
            className="flex-1 bg-transparent px-2 text-[13px] text-white placeholder-slate-400 outline-none"
          />

          {/* Microphone trigger leading to Voice Analysis */}
          <button
            type="button"
            onClick={onOpenVoice}
            className="w-8 h-8 rounded-full hover:bg-purple-900/40 flex items-center justify-center text-slate-300 hover:text-white transition-colors"
            title="Open Voice Analysis"
          >
            <Mic className="w-4 h-4" />
          </button>

          {/* Send Button: purple circular button with paper plane icon */}
          <button
            type="submit"
            disabled={!inputText.trim()}
            className="w-9 h-9 rounded-full bg-gradient-to-tr from-purple-600 via-fuchsia-600 to-indigo-600 flex items-center justify-center text-white shadow-[0_0_12px_rgba(168,85,247,0.5)] active:scale-95 disabled:opacity-40 disabled:hover:scale-100 transition-all"
            title="Send Message"
          >
            <Send className="w-4 h-4 ml-0.5" />
          </button>
        </form>
      </div>
    </div>
  );
};
