import React, { useState, useEffect } from 'react';
import { 
  ChevronLeft, 
  Menu, 
  Cloud, 
  CloudCheck, 
  RefreshCw, 
  FolderGit2, 
  Image as ImageIcon, 
  FileText, 
  Mic, 
  MessageSquare,
  Trash2,
  HardDrive
} from 'lucide-react';
import { AppLanguage, ProjectItem, ProjectCategory, FirebaseSyncState } from '../types';
import { translations } from '../i18n/translations';
import { storageService } from '../services/storageService';

interface ProjectsScreenProps {
  language: AppLanguage;
  onBack: () => void;
  onOpenMenu: () => void;
}

export const ProjectsScreen: React.FC<ProjectsScreenProps> = ({
  language,
  onBack,
  onOpenMenu,
}) => {
  const t = translations[language];
  const [projects, setProjects] = useState<ProjectItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<ProjectCategory | 'all'>('all');
  const [syncState, setSyncState] = useState<FirebaseSyncState>(storageService.getSyncState());
  const [isSyncing, setIsSyncing] = useState(false);

  useEffect(() => {
    setProjects(storageService.getProjects());
    setSyncState(storageService.getSyncState());
  }, []);

  const handleSync = async () => {
    setIsSyncing(true);
    const updated = await storageService.syncWithCloud();
    setSyncState(updated);
    setProjects(storageService.getProjects());
    setIsSyncing(false);
  };

  const handleDelete = (id: string) => {
    storageService.deleteProject(id);
    setProjects(storageService.getProjects());
  };

  const filtered = selectedCategory === 'all'
    ? projects
    : projects.filter(p => p.category === selectedCategory);

  const getCategoryIcon = (cat: ProjectCategory) => {
    switch (cat) {
      case 'image': return <ImageIcon className="w-3.5 h-3.5 text-fuchsia-400" />;
      case 'doc': return <FileText className="w-3.5 h-3.5 text-purple-400" />;
      case 'audio': return <Mic className="w-3.5 h-3.5 text-pink-400" />;
      case 'chat': return <MessageSquare className="w-3.5 h-3.5 text-cyan-400" />;
    }
  };

  return (
    <div className="flex flex-col h-full justify-between pb-2 text-white">
      {/* Header */}
      <div className="flex items-center justify-between py-1 mb-2">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full bg-[#1b0f30]/90 border border-purple-500/25 flex items-center justify-center text-white/90 hover:text-white hover:border-purple-400 transition-all shadow-md active:scale-95"
          aria-label="Back"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>

        <h2 className="text-[16px] font-bold tracking-tight text-white flex items-center gap-1.5">
          <FolderGit2 className="w-4 h-4 text-purple-400" />
          <span>{t.myProjectsTitle}</span>
        </h2>

        <button
          onClick={onOpenMenu}
          className="w-10 h-10 rounded-full bg-[#1b0f30]/90 border border-purple-500/25 flex items-center justify-center text-white/90 hover:text-white hover:border-purple-400 transition-all shadow-md active:scale-95"
          aria-label="Menu"
        >
          <Menu className="w-4 h-4" />
        </button>
      </div>

      {/* Sync Status Banner */}
      <div className="p-3 mb-2 rounded-2xl bg-gradient-to-r from-[#1d0e37] to-[#140926] border border-purple-500/30 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-purple-900/50 flex items-center justify-center text-purple-300">
            {syncState.status === 'synced' ? (
              <CloudCheck className="w-4 h-4 text-emerald-400" />
            ) : (
              <HardDrive className="w-4 h-4 text-amber-400" />
            )}
          </div>
          <div>
            <p className="text-[11px] font-semibold text-white">
              {syncState.status === 'synced' ? t.cloudSyncedBadge : t.offlineReadyBadge}
            </p>
            <p className="text-[10px] text-slate-400">
              {syncState.pendingChangesCount > 0 
                ? `${syncState.pendingChangesCount} item(s) cached locally`
                : `Synced with Firestore (${syncState.lastSyncedAt || 'Active'})`}
            </p>
          </div>
        </div>

        <button
          onClick={handleSync}
          disabled={isSyncing}
          className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-purple-600/30 border border-purple-400/40 text-[11px] font-medium text-purple-200 hover:text-white hover:bg-purple-600/50 transition-all"
        >
          <RefreshCw className={`w-3 h-3 ${isSyncing ? 'animate-spin' : ''}`} />
          <span>{isSyncing ? 'Syncing...' : t.syncNow}</span>
        </button>
      </div>

      {/* Categories Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 mb-2 text-xs">
        {[
          { id: 'all', label: language === 'ta' ? 'அனைத்தும்' : 'All' },
          { id: 'image', label: language === 'ta' ? 'படங்கள்' : 'Images' },
          { id: 'doc', label: language === 'ta' ? 'ஆவணங்கள்' : 'Documents' },
          { id: 'audio', label: language === 'ta' ? 'குரல் குறிப்புகள்' : 'Voice' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setSelectedCategory(tab.id as any)}
            className={`px-3 py-1 rounded-full text-[11px] font-medium shrink-0 transition-all ${
              selectedCategory === tab.id
                ? 'bg-purple-600 text-white shadow-[0_0_10px_rgba(168,85,247,0.5)]'
                : 'bg-[#180b2e]/80 border border-purple-500/20 text-slate-300 hover:text-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Projects List */}
      <div className="flex-1 overflow-y-auto space-y-2.5 pr-0.5">
        {filtered.length === 0 ? (
          <div className="text-center py-12 text-slate-400 text-xs">
            {language === 'ta' ? 'திட்டங்கள் எதுவும் இல்லை' : 'No projects in this category'}
          </div>
        ) : (
          filtered.map((proj) => (
            <div
              key={proj.id}
              className="p-3 rounded-2xl bg-[#150a27]/90 border border-purple-500/25 flex items-center justify-between gap-3 hover:border-purple-400/50 transition-all group"
            >
              {/* Thumbnail or Icon */}
              {proj.previewUrl ? (
                <div className="w-12 h-12 rounded-xl overflow-hidden bg-black/60 shrink-0 border border-purple-500/30">
                  <img src={proj.previewUrl} alt={proj.title} className="w-full h-full object-cover" />
                </div>
              ) : (
                <div className="w-12 h-12 rounded-xl bg-purple-950/60 border border-purple-500/30 flex items-center justify-center shrink-0">
                  {getCategoryIcon(proj.category)}
                </div>
              )}

              {/* Title & metadata */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] font-semibold uppercase tracking-wider text-fuchsia-400">
                    {proj.category}
                  </span>
                  <span className="text-[9px] text-slate-400">• {proj.createdAt}</span>
                </div>
                <h4 className="text-[12px] font-semibold text-white truncate">
                  {proj.title}
                </h4>
                <p className="text-[10px] text-slate-300 line-clamp-1">
                  {proj.description || proj.content}
                </p>
              </div>

              {/* Action buttons */}
              <div className="flex items-center gap-1">
                <button
                  onClick={() => handleDelete(proj.id)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-950/30 transition-colors"
                  title="Delete"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
