package ai.ammu.app.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import ai.ammu.app.ui.theme.ElectricMagenta
import ai.ammu.app.ui.theme.NeonPurple

@Composable
fun GlowingPlasmaOrb(
    isListening: Boolean = true,
    size: Dp = 260.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb")

    val rotation1 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation1"
    )

    val rotation2 by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 6000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation2"
    )

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Box(
        modifier = Modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val center = Offset(this.size.width / 2, this.size.height / 2)
            val baseRadius = (this.size.minDimension / 2) * 0.72f * pulseScale

            // Outer Radiant Nebula Glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0x66D946EF),
                        Color(0x33A855F7),
                        Color(0x000A0514)
                    ),
                    center = center,
                    radius = baseRadius * 1.5f
                ),
                radius = baseRadius * 1.5f,
                center = center
            )

            // Dynamic Elliptical Rings
            rotate(rotation1, pivot = center) {
                drawOval(
                    brush = Brush.horizontalGradient(listOf(ElectricMagenta, NeonPurple, Color.White)),
                    topLeft = Offset(center.x - baseRadius * 0.9f, center.y - baseRadius * 0.5f),
                    size = androidx.compose.ui.geometry.Size(baseRadius * 1.8f, baseRadius * 1.0f),
                    style = Stroke(width = 4f)
                )
            }

            rotate(rotation2, pivot = center) {
                drawOval(
                    brush = Brush.verticalGradient(listOf(Color(0xFFE879F9), Color(0xFFC084FC), ElectricMagenta)),
                    topLeft = Offset(center.x - baseRadius * 0.7f, center.y - baseRadius * 0.9f),
                    size = androidx.compose.ui.geometry.Size(baseRadius * 1.4f, baseRadius * 1.8f),
                    style = Stroke(width = 3f)
                )
            }

            // Core Energy Sphere
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White,
                        Color(0xFFF5D0FE),
                        ElectricMagenta,
                        NeonPurple,
                        Color.Transparent
                    ),
                    center = center,
                    radius = baseRadius * 0.85f
                ),
                radius = baseRadius * 0.85f,
                center = center
            )

            // Bright Center Point
            drawCircle(
                color = Color.White,
                radius = baseRadius * 0.2f,
                center = center
            )
        }
    }
}
