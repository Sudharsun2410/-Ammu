package ai.ammu.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val AmmuColorScheme = darkColorScheme(
    primary = NeonPurple,
    secondary = ElectricMagenta,
    tertiary = VioletAccent,
    background = BackgroundDark,
    surface = SurfaceDark,
    onPrimary = TextPrimary,
    onSecondary = TextPrimary,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
)

@Composable
fun AmmuTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = AmmuColorScheme,
        content = content
    )
}
