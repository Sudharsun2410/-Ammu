package ai.ammu.app.ui.theme

import androidx.compose.ui.graphics.Color

val BackgroundDark = Color(0xFF0A0514)
val SurfaceDark = Color(0xFF130A24)
val SurfaceCard = Color(0xFF190C2F)
val SurfaceCardElevated = Color(0xFF22103E)

val NeonPurple = Color(0xFFA855F7)
val ElectricMagenta = Color(0xFFD946EF)
val VioletAccent = Color(0xFF8B5CF6)
val DeepIndigo = Color(0xFF4F46E5)
val CyanAccent = Color(0xFF06B6D4)

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFA19AB5)
val TextMuted = Color(0xFF6B6380)

val BorderPurple = Color(0x4DA855F7)
val GlowPurple = Color(0x66A855F7)
