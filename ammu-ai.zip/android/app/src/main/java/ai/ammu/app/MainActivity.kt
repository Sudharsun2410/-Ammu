package ai.ammu.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import ai.ammu.app.ui.screens.*
import ai.ammu.app.ui.theme.AmmuTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AmmuTheme {
                AmmuAppNavHost()
            }
        }
    }
}

@Composable
fun AmmuAppNavHost() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "home"
    ) {
        composable("home") {
            HomeScreen(
                userName = "Jack Johnson",
                onNavigateChat = { navController.navigate("chat") },
                onNavigateVoice = { navController.navigate("voice") },
                onNavigateImageGen = { navController.navigate("chat") },
                onNavigateProjects = { /* open projects */ },
                onOpenMenu = { /* open drawer */ }
            )
        }
        composable("chat") {
            ChatBotScreen(
                onBack = { navController.popBackStack() },
                onNavigateVoice = { navController.navigate("voice") },
                onOpenMenu = { /* open drawer */ }
            )
        }
        composable("voice") {
            VoiceAnalysisScreen(
                onBack = { navController.popBackStack() },
                onOpenMenu = { /* open drawer */ }
            )
        }
    }
}
