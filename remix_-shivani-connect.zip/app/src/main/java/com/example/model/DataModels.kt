package com.example.model

enum class UserRole(val displayName: String, val badgeColorHex: Long) {
    USER("User", 0xFFEC4899),
    ADMIN("Admin", 0xFF8B5CF6),
    AGENT("Village Agent", 0xFF10B981),
    VENDOR("Vendor Partner", 0xFFF59E0B)
}

enum class Language(val code: String, val label: String) {
    ENGLISH("EN", "English"),
    TAMIL("TA", "தமிழ்")
}

data class VillageLocation(
    val district: String,
    val districtTamil: String,
    val taluk: String,
    val talukTamil: String,
    val village: String,
    val villageTamil: String,
    val pinCode: String,
    val lat: Double,
    val lng: Double
)

data class EventCategory(
    val id: String,
    val nameEn: String,
    val nameTa: String,
    val iconEmoji: String,
    val colorHex: Long
)

data class VenueOrService(
    val id: String,
    val titleEn: String,
    val titleTa: String,
    val categoryId: String,
    val district: String,
    val taluk: String,
    val village: String,
    val villageTamil: String,
    val address: String,
    val pricePerDay: Double,
    val rating: Double,
    val reviewCount: Int,
    val capacity: String,
    val isLiveAvailable: Boolean,
    val bookedDates: List<String>, // "YYYY-MM-DD"
    val features: List<String>,
    val imageUrl: String,
    val phone: String,
    val vendorName: String,
    val mapUrl: String = ""
)

data class MarketProduct(
    val id: String,
    val titleEn: String,
    val titleTa: String,
    val price: Double,
    val originalPrice: Double,
    val rating: Double,
    val reviewCount: Int,
    val village: String,
    val vendorName: String,
    val category: String,
    val imageUrl: String,
    val description: String,
    val stock: Int,
    val meeshoUrl: String = "",
    val amazonUrl: String = "",
    val flipkartUrl: String = "",
    val ajioUrl: String = "",
    val marketplace: String = "Meesho", // Meesho, Flipkart, Amazon
    val isEnabled: Boolean = true,
    val isFeatured: Boolean = false,
    val productUrl: String = "",
    val discountPercent: Int = 15
)

data class AdminReferralSettings(
    val meeshoReferralLink: String = "https://www.meesho.com/r/shivani_connect",
    val flipkartAffiliateLink: String = "https://www.flipkart.com/affiliate/shivani_connect",
    val amazonAffiliateLink: String = "https://www.amazon.in/shop/shivani_connect",
    val whatsAppNumber: String = "+91 98765 43210",
    val telegramLink: String = "https://t.me/shivaniconnect",
    val instagramLink: String = "https://instagram.com/shivaniconnect",
    val facebookLink: String = "https://facebook.com/shivaniconnect",
    val youTubeLink: String = "https://youtube.com/@shivaniconnect",
    val websiteUrl: String = "https://shivaniconnect.com"
)

data class ChatMessage(
    val id: String,
    val senderName: String,
    val isUser: Boolean,
    val text: String,
    val time: String,
    val isAi: Boolean = false
)

data class UserProfile(
    val fullName: String = "Sudharsan R",
    val email: String = "sudharsun2410@gmail.com",
    val mobileNumber: String = "9345439018",
    val userType: String = "User", // User / Vendor / Admin
    val isVerified: Boolean = true,
    val selectedLanguage: String = "English",
    val profilePictureUrl: String = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80"
)

data class BackupState(
    val lastBackupTime: String = "2026-07-25 14:30 PM",
    val backupSizeMb: String = "4.2 MB",
    val isAutoBackupEnabled: Boolean = true,
    val isCloudSyncActive: Boolean = true
)

