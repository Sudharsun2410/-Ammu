package com.example.data

import android.util.Log
import com.example.model.UserProfile
import com.example.model.VenueOrService
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

/**
 * Firebase Firestore Data Repository providing full CRUD operations for:
 * 1. User Profiles (`users` collection)
 * 2. Vendor-Specific Venue & Service Listings (`venues` collection)
 * 3. User & Vendor Booking Records (`user_bookings` collection)
 */
class FirestoreRepository {
    private val db = FirebaseFirestore.getInstance()
    private val TAG = "FirestoreRepository"

    // =========================================================================
    // 1. USER PROFILES CRUD OPERATIONS (`users` collection)
    // =========================================================================

    /**
     * Create or update a user profile record in Firestore.
     */
    suspend fun saveUserProfile(userId: String, profile: UserProfile): Boolean {
        return try {
            val userMap = mapOf(
                "fullName" to profile.fullName,
                "email" to profile.email,
                "mobileNumber" to profile.mobileNumber,
                "userType" to profile.userType,
                "isVerified" to profile.isVerified,
                "selectedLanguage" to profile.selectedLanguage,
                "profilePictureUrl" to profile.profilePictureUrl,
                "updatedAt" to System.currentTimeMillis()
            )
            db.collection("users").document(userId.ifEmpty { profile.mobileNumber }).set(userMap, SetOptions.merge()).await()
            Log.d(TAG, "Successfully saved user profile for ID: $userId")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error saving user profile: ${e.message}", e)
            false
        }
    }

    /**
     * Read a single user profile from Firestore by User ID or Mobile Number.
     */
    suspend fun getUserProfile(userId: String): UserProfile? {
        return try {
            val doc = db.collection("users").document(userId).get().await()
            if (doc.exists()) {
                val data = doc.data
                UserProfile(
                    fullName = data?.get("fullName") as? String ?: "",
                    email = data?.get("email") as? String ?: "",
                    mobileNumber = data?.get("mobileNumber") as? String ?: "",
                    userType = data?.get("userType") as? String ?: "User",
                    isVerified = data?.get("isVerified") as? Boolean ?: true,
                    selectedLanguage = data?.get("selectedLanguage") as? String ?: "English",
                    profilePictureUrl = data?.get("profilePictureUrl") as? String ?: ""
                )
            } else null
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching user profile for ID: $userId", e)
            null
        }
    }

    /**
     * Real-time listener for a specific user profile.
     */
    fun getRealtimeUserProfile(userId: String): Flow<UserProfile?> = callbackFlow {
        val listener = db.collection("users").document(userId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(TAG, "User profile listener error", error)
                    trySend(null)
                    return@addSnapshotListener
                }
                if (snapshot != null && snapshot.exists()) {
                    val data = snapshot.data
                    val profile = UserProfile(
                        fullName = data?.get("fullName") as? String ?: "",
                        email = data?.get("email") as? String ?: "",
                        mobileNumber = data?.get("mobileNumber") as? String ?: "",
                        userType = data?.get("userType") as? String ?: "User",
                        isVerified = data?.get("isVerified") as? Boolean ?: true,
                        selectedLanguage = data?.get("selectedLanguage") as? String ?: "English",
                        profilePictureUrl = data?.get("profilePictureUrl") as? String ?: ""
                    )
                    trySend(profile)
                } else {
                    trySend(null)
                }
            }
        awaitClose { listener.remove() }
    }

    /**
     * Delete user profile from Firestore.
     */
    suspend fun deleteUserProfile(userId: String): Boolean {
        return try {
            db.collection("users").document(userId).delete().await()
            Log.d(TAG, "Successfully deleted user profile for ID: $userId")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error deleting user profile: ${e.message}", e)
            false
        }
    }


    // =========================================================================
    // 2. VENDOR-SPECIFIC VENUE & SERVICE CRUD OPERATIONS (`venues` collection)
    // =========================================================================

    /**
     * Create or Update a venue or service listing (Vendor action).
     */
    suspend fun saveVenue(venue: VenueOrService): Boolean {
        return try {
            val venueData = mapOf(
                "titleEn" to venue.titleEn,
                "titleTa" to venue.titleTa,
                "categoryId" to venue.categoryId,
                "district" to venue.district,
                "taluk" to venue.taluk,
                "village" to venue.village,
                "villageTamil" to venue.villageTamil,
                "address" to venue.address,
                "pricePerDay" to venue.pricePerDay,
                "rating" to venue.rating,
                "reviewCount" to venue.reviewCount,
                "capacity" to venue.capacity,
                "isLiveAvailable" to venue.isLiveAvailable,
                "bookedDates" to venue.bookedDates,
                "features" to venue.features,
                "imageUrl" to venue.imageUrl,
                "phone" to venue.phone,
                "vendorName" to venue.vendorName,
                "mapUrl" to venue.mapUrl,
                "updatedAt" to System.currentTimeMillis()
            )
            db.collection("venues").document(venue.id).set(venueData, SetOptions.merge()).await()
            Log.d(TAG, "Successfully saved venue listing: ${venue.id}")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error saving venue to Firestore", e)
            false
        }
    }

    /**
     * Alias for backward compatibility.
     */
    suspend fun saveVenueToFirestore(venue: VenueOrService): Boolean = saveVenue(venue)

    /**
     * Read single venue by ID.
     */
    suspend fun getVenueById(venueId: String): VenueOrService? {
        return try {
            val doc = db.collection("venues").document(venueId).get().await()
            if (doc.exists()) {
                mapDocumentToVenue(doc.id, doc.data)
            } else null
        } catch (e: Exception) {
            Log.e(TAG, "Error getting venue by ID: $venueId", e)
            null
        }
    }

    /**
     * Real-time listener for all active venue listings.
     */
    fun getRealtimeVenues(): Flow<List<Map<String, Any>>> = callbackFlow {
        val listenerRegistration = db.collection("venues")
            .addSnapshotListener { snapshot, e ->
                if (e != null) {
                    Log.e(TAG, "Listen failed for venues", e)
                    return@addSnapshotListener
                }

                if (snapshot != null) {
                    val venuesList = snapshot.documents.mapNotNull { doc ->
                        doc.data?.plus("id" to doc.id)
                    }
                    trySend(venuesList)
                }
            }

        awaitClose { listenerRegistration.remove() }
    }

    /**
     * Real-time listener for vendor-specific venue listings.
     */
    fun getVenuesForVendor(vendorName: String): Flow<List<VenueOrService>> = callbackFlow {
        val listener = db.collection("venues")
            .whereEqualTo("vendorName", vendorName)
            .addSnapshotListener { snapshot, e ->
                if (e != null) {
                    Log.e(TAG, "Vendor venues listener error", e)
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val list = snapshot.documents.mapNotNull { doc ->
                        mapDocumentToVenue(doc.id, doc.data)
                    }
                    trySend(list)
                }
            }
        awaitClose { listener.remove() }
    }

    /**
     * Update venue availability status or booked dates (Vendor/Admin operation).
     */
    suspend fun updateVenueAvailability(venueId: String, isAvailable: Boolean, bookedDates: List<String>): Boolean {
        return try {
            val updates = mapOf(
                "isLiveAvailable" to isAvailable,
                "bookedDates" to bookedDates,
                "updatedAt" to System.currentTimeMillis()
            )
            db.collection("venues").document(venueId).update(updates).await()
            Log.d(TAG, "Updated availability for venue $venueId")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error updating venue availability for $venueId", e)
            false
        }
    }

    /**
     * Delete a venue listing (Vendor / Admin action).
     */
    suspend fun deleteVenue(venueId: String): Boolean {
        return try {
            db.collection("venues").document(venueId).delete().await()
            Log.d(TAG, "Successfully deleted venue $venueId from Firestore")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error deleting venue $venueId", e)
            false
        }
    }


    // =========================================================================
    // 3. USER & VENDOR BOOKING RECORDS CRUD OPERATIONS (`user_bookings` collection)
    // =========================================================================

    /**
     * Create or Update booking record in Firestore.
     */
    suspend fun saveBooking(booking: BookingEntity): Boolean {
        return try {
            val bookingMap = mapOf(
                "bookingId" to booking.bookingId,
                "title" to booking.title,
                "category" to booking.category,
                "district" to booking.district,
                "village" to booking.village,
                "bookingDate" to booking.bookingDate,
                "timeSlot" to booking.timeSlot,
                "guestCount" to booking.guestCount,
                "totalPrice" to booking.totalPrice,
                "paymentMethod" to booking.paymentMethod,
                "status" to booking.status,
                "customerName" to booking.customerName,
                "customerPhone" to booking.customerPhone,
                "createdAt" to booking.timestamp
            )
            db.collection("user_bookings").document(booking.bookingId).set(bookingMap, SetOptions.merge()).await()
            Log.d(TAG, "Successfully synced booking #${booking.bookingId} to Firestore")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error saving booking to Firestore", e)
            false
        }
    }

    /**
     * Alias for backward compatibility.
     */
    suspend fun saveBookingToFirestore(booking: BookingEntity): Boolean = saveBooking(booking)

    /**
     * Read a single booking record by ID.
     */
    suspend fun getBookingById(bookingId: String): BookingEntity? {
        return try {
            val doc = db.collection("user_bookings").document(bookingId).get().await()
            if (doc.exists()) {
                mapDocumentToBooking(doc.data)
            } else null
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching booking by ID: $bookingId", e)
            null
        }
    }

    /**
     * Real-time listener for all user bookings.
     */
    fun getRealtimeBookings(): Flow<List<Map<String, Any>>> = callbackFlow {
        val listenerRegistration = db.collection("user_bookings")
            .addSnapshotListener { snapshot, e ->
                if (e != null) {
                    Log.e(TAG, "Listen failed for bookings", e)
                    return@addSnapshotListener
                }

                if (snapshot != null) {
                    val bookings = snapshot.documents.mapNotNull { doc ->
                        doc.data?.plus("id" to doc.id)
                    }
                    trySend(bookings)
                }
            }

        awaitClose { listenerRegistration.remove() }
    }

    /**
     * Real-time listener for customer-specific bookings.
     */
    fun getBookingsForCustomer(customerPhone: String): Flow<List<BookingEntity>> = callbackFlow {
        val listener = db.collection("user_bookings")
            .whereEqualTo("customerPhone", customerPhone)
            .addSnapshotListener { snapshot, e ->
                if (e != null) {
                    Log.e(TAG, "Customer bookings listener error", e)
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val bookings = snapshot.documents.mapNotNull { doc ->
                        mapDocumentToBooking(doc.data)
                    }
                    trySend(bookings)
                }
            }
        awaitClose { listener.remove() }
    }

    /**
     * Update booking status (e.g., CONFIRMED, COMPLETED, CANCELLED).
     */
    suspend fun updateBookingStatus(bookingId: String, newStatus: String): Boolean {
        return try {
            db.collection("user_bookings").document(bookingId)
                .update(mapOf("status" to newStatus, "updatedAt" to System.currentTimeMillis()))
                .await()
            Log.d(TAG, "Booking $bookingId status updated to $newStatus")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error updating booking status for $bookingId", e)
            false
        }
    }

    /**
     * Delete booking record (Admin / User cancellation action).
     */
    suspend fun deleteBooking(bookingId: String): Boolean {
        return try {
            db.collection("user_bookings").document(bookingId).delete().await()
            Log.d(TAG, "Successfully deleted booking record $bookingId")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error deleting booking record $bookingId", e)
            false
        }
    }

    // =========================================================================
    // 4. VENDOR PROFILE & METADATA MANAGEMENT (`vendors` collection)
    // =========================================================================

    /**
     * Save Vendor Info & Activity profile.
     */
    suspend fun saveVendorProfileToFirestore(vendorName: String, phone: String, village: String, category: String): Boolean {
        return try {
            val vendorData = mapOf(
                "vendorName" to vendorName,
                "phone" to phone,
                "village" to village,
                "category" to category,
                "updatedAt" to System.currentTimeMillis()
            )
            db.collection("vendors").document(phone.ifEmpty { vendorName }).set(vendorData, SetOptions.merge()).await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error saving vendor profile", e)
            false
        }
    }

    // =========================================================================
    // HELPER MAPPERS
    // =========================================================================

    @Suppress("UNCHECKED_CAST")
    private fun mapDocumentToVenue(id: String, data: Map<String, Any>?): VenueOrService? {
        if (data == null) return null
        return try {
            VenueOrService(
                id = id,
                titleEn = data["titleEn"] as? String ?: "",
                titleTa = data["titleTa"] as? String ?: "",
                categoryId = data["categoryId"] as? String ?: "",
                district = data["district"] as? String ?: "",
                taluk = data["taluk"] as? String ?: "",
                village = data["village"] as? String ?: "",
                villageTamil = data["villageTamil"] as? String ?: "",
                address = data["address"] as? String ?: "",
                pricePerDay = (data["pricePerDay"] as? Number)?.toDouble() ?: 0.0,
                rating = (data["rating"] as? Number)?.toDouble() ?: 4.5,
                reviewCount = (data["reviewCount"] as? Number)?.toInt() ?: 0,
                capacity = data["capacity"] as? String ?: "",
                isLiveAvailable = data["isLiveAvailable"] as? Boolean ?: true,
                bookedDates = data["bookedDates"] as? List<String> ?: emptyList(),
                features = data["features"] as? List<String> ?: emptyList(),
                imageUrl = data["imageUrl"] as? String ?: "",
                phone = data["phone"] as? String ?: "",
                vendorName = data["vendorName"] as? String ?: "",
                mapUrl = data["mapUrl"] as? String ?: ""
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error mapping venue document: $id", e)
            null
        }
    }

    private fun mapDocumentToBooking(data: Map<String, Any>?): BookingEntity? {
        if (data == null) return null
        return try {
            BookingEntity(
                bookingId = data["bookingId"] as? String ?: "",
                title = data["title"] as? String ?: "",
                category = data["category"] as? String ?: "",
                district = data["district"] as? String ?: "",
                village = data["village"] as? String ?: "",
                bookingDate = data["bookingDate"] as? String ?: "",
                timeSlot = data["timeSlot"] as? String ?: "",
                guestCount = data["guestCount"] as? String ?: "",
                totalPrice = data["totalPrice"] as? String ?: "₹0",
                paymentMethod = data["paymentMethod"] as? String ?: "UPI",
                status = data["status"] as? String ?: "CONFIRMED",
                customerName = data["customerName"] as? String ?: "",
                customerPhone = data["customerPhone"] as? String ?: "",
                timestamp = (data["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error mapping booking document", e)
            null
        }
    }
}
