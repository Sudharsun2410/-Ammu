package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "bookings")
data class BookingEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val bookingId: String,
    val title: String,
    val category: String,
    val district: String,
    val village: String,
    val bookingDate: String,
    val timeSlot: String,
    val guestCount: String,
    val totalPrice: String,
    val paymentMethod: String,
    val status: String = "CONFIRMED",
    val customerName: String,
    val customerPhone: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "cart_items")
data class CartItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val productId: String,
    val title: String,
    val price: Double,
    val quantity: Int = 1,
    val imageUrl: String,
    val village: String,
    val vendorName: String
)

@Entity(tableName = "wishlist_items")
data class WishlistItemEntity(
    @PrimaryKey val id: String,
    val title: String,
    val category: String,
    val price: String,
    val village: String,
    val rating: Double,
    val imageUrl: String = "",
    val vendorName: String = ""
)

@Entity(tableName = "ecommerce_products")
data class ECommerceProductEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val price: Double,
    val imageUrl: String,
    val sourceUrl: String,
    val platform: String,
    val category: String = "E-Commerce",
    val vendorName: String = "Verified Online Vendor",
    val rating: Double = 4.5,
    val timestamp: Long = System.currentTimeMillis()
)
