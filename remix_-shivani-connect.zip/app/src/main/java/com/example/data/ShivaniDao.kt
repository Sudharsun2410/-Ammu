package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ShivaniDao {
    @Query("SELECT * FROM bookings ORDER BY timestamp DESC")
    fun getAllBookings(): Flow<List<BookingEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBooking(booking: BookingEntity)

    @Query("DELETE FROM bookings WHERE id = :id")
    suspend fun deleteBooking(id: Int)

    @Query("UPDATE bookings SET status = :status WHERE id = :id")
    suspend fun updateBookingStatus(id: Int, status: String)

    // Cart Operations
    @Query("SELECT * FROM cart_items")
    fun getCartItems(): Flow<List<CartItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCartItem(item: CartItemEntity)

    @Query("DELETE FROM cart_items WHERE id = :id")
    suspend fun deleteCartItem(id: Int)

    @Query("DELETE FROM cart_items")
    suspend fun clearCart()

    // Wishlist Operations
    @Query("SELECT * FROM wishlist_items")
    fun getWishlistItems(): Flow<List<WishlistItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWishlist(item: WishlistItemEntity)

    @Query("DELETE FROM wishlist_items WHERE id = :id")
    suspend fun deleteWishlist(id: String)

    // E-Commerce Product Room Operations
    @Query("SELECT * FROM ecommerce_products ORDER BY timestamp DESC")
    fun getAllECommerceProducts(): Flow<List<ECommerceProductEntity>>

    @Query("SELECT * FROM ecommerce_products WHERE price >= :minPrice AND price <= :maxPrice ORDER BY timestamp DESC")
    fun getECommerceProductsByPriceRange(minPrice: Double, maxPrice: Double): Flow<List<ECommerceProductEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertECommerceProduct(product: ECommerceProductEntity): Long

    @Query("DELETE FROM ecommerce_products WHERE id = :id")
    suspend fun deleteECommerceProduct(id: Int)
}
