package com.example.data

import kotlinx.coroutines.flow.Flow

class ShivaniRepository(
    private val dao: ShivaniDao,
    val firestoreRepository: FirestoreRepository = FirestoreRepository()
) {
    val allBookings: Flow<List<BookingEntity>> = dao.getAllBookings()
    val cartItems: Flow<List<CartItemEntity>> = dao.getCartItems()
    val wishlistItems: Flow<List<WishlistItemEntity>> = dao.getWishlistItems()
    val eCommerceProducts: Flow<List<ECommerceProductEntity>> = dao.getAllECommerceProducts()

    fun getECommerceProductsByPriceRange(minPrice: Double, maxPrice: Double): Flow<List<ECommerceProductEntity>> {
        return dao.getECommerceProductsByPriceRange(minPrice, maxPrice)
    }

    suspend fun deleteECommerceProduct(id: Int) {
        dao.deleteECommerceProduct(id)
    }

    suspend fun createBooking(booking: BookingEntity) {
        dao.insertBooking(booking)
        firestoreRepository.saveBookingToFirestore(booking)
    }

    suspend fun cancelBooking(id: Int) {
        dao.deleteBooking(id)
    }

    suspend fun updateBookingStatus(id: Int, status: String) {
        dao.updateBookingStatus(id, status)
    }

    suspend fun addToCart(item: CartItemEntity) {
        dao.insertCartItem(item)
    }

    suspend fun removeFromCart(id: Int) {
        dao.deleteCartItem(id)
    }

    suspend fun clearCart() {
        dao.clearCart()
    }

    suspend fun toggleWishlist(item: WishlistItemEntity, isWishlisted: Boolean) {
        if (isWishlisted) {
            dao.deleteWishlist(item.id)
        } else {
            dao.insertWishlist(item)
        }
    }
}
