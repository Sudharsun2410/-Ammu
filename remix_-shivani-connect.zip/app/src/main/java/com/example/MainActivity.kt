package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.delay
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.EventCategory
import com.example.model.Language
import com.example.model.SampleData
import com.example.model.UserProfile
import com.example.model.UserRole
import com.example.service.FcmNotificationManager
import com.example.ui.components.BottomNavBar
import com.example.ui.components.CategoryBottomSheet
import com.example.ui.components.HeaderTitleCard
import com.example.ui.components.InvoiceModalDialog
import com.example.ui.components.LocationBreadcrumb
import com.example.ui.components.ProfileModalDialog
import com.example.ui.components.ThermalPrinterDialog
import com.example.ui.screens.AdminVendorScreen
import com.example.ui.screens.AiAssistantScreen
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.EventBookingScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.JobsWorkScreen
import com.example.ui.screens.MapScreen
import com.example.ui.screens.MarketplaceScreen
import com.example.ui.screens.ServiceCategoryDetailScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.theme.PinkPrimary
import com.example.ui.theme.ShivaniConnectTheme
import com.example.viewmodel.ShivaniViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: ShivaniViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()
            val currentLanguage by viewModel.currentLanguage.collectAsStateWithLifecycle()
            val currentRole by viewModel.currentRole.collectAsStateWithLifecycle()
            val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()

            val district by viewModel.selectedDistrict.collectAsStateWithLifecycle()
            val taluk by viewModel.selectedTaluk.collectAsStateWithLifecycle()
            val village by viewModel.selectedVillage.collectAsStateWithLifecycle()

            val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
            val categoryId by viewModel.selectedCategoryId.collectAsStateWithLifecycle()

            val selectedVenue by viewModel.selectedVenue.collectAsStateWithLifecycle()
            val selectedProduct by viewModel.selectedProduct.collectAsStateWithLifecycle()

            val bookingDate by viewModel.bookingDate.collectAsStateWithLifecycle()
            val bookingTimeSlot by viewModel.bookingTimeSlot.collectAsStateWithLifecycle()
            val guestCount by viewModel.guestCount.collectAsStateWithLifecycle()
            val showPaymentDialog by viewModel.showPaymentDialog.collectAsStateWithLifecycle()
            val lastCreatedBooking by viewModel.lastCreatedBooking.collectAsStateWithLifecycle()
            val showInvoiceModal by viewModel.showInvoiceModal.collectAsStateWithLifecycle()
            val savedBookings by viewModel.savedBookings.collectAsStateWithLifecycle()

            val cartItems by viewModel.cartItems.collectAsStateWithLifecycle()
            val wishlistItems by viewModel.wishlistItems.collectAsStateWithLifecycle()
            val eCommerceProducts by viewModel.eCommerceProducts.collectAsStateWithLifecycle()
            val priceRange by viewModel.priceRange.collectAsStateWithLifecycle()
            val chatMessages by viewModel.chatMessages.collectAsStateWithLifecycle()
            val referralSettings by viewModel.referralSettings.collectAsStateWithLifecycle()
            val marketProducts by viewModel.marketProducts.collectAsStateWithLifecycle()
            val toastMessage by viewModel.toastMessage.collectAsStateWithLifecycle()

            val context = LocalContext.current
            var showLocationPicker by remember { mutableStateOf(false) }

            // Initialize FCM Channels
            LaunchedEffect(Unit) {
                FcmNotificationManager.initNotificationChannels(context)
            }
            var showSplashScreen by remember { mutableStateOf(true) }
            var isSignedIn by remember { mutableStateOf(false) }
            var showCategoryBottomSheet by remember { mutableStateOf(false) }
            var activeSelectedCategory by remember { mutableStateOf<EventCategory?>(null) }
            var showAuthScreen by remember { mutableStateOf(false) }
            var showSettingsScreen by remember { mutableStateOf(false) }
            var showProfileDialog by remember { mutableStateOf(false) }
            var showThermalPrinterDialog by remember { mutableStateOf(false) }
            var userProfile by remember { mutableStateOf(UserProfile()) }
            var activeNotificationBanner by remember { mutableStateOf<String?>(null) }

            // Handle Toast Alerts & External Notifications
            LaunchedEffect(toastMessage) {
                toastMessage?.let { msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    // Trigger actual System Push Notification (Heads-Up)
                    FcmNotificationManager.showNotification(context, "Shivani Connect", msg)
                    activeNotificationBanner = msg
                    viewModel.clearToast()
                    delay(4000)
                    if (activeNotificationBanner == msg) {
                        activeNotificationBanner = null
                    }
                }
            }

            ShivaniConnectTheme(darkTheme = isDarkMode) {
                if (showSplashScreen) {
                    SplashScreen(
                        currentLanguage = currentLanguage,
                        isSignedIn = isSignedIn,
                        onSplashFinished = { navigateToAuth ->
                            showSplashScreen = false
                            if (navigateToAuth) {
                                showAuthScreen = true
                            }
                        }
                    )
                } else if (showAuthScreen) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .statusBarsPadding()
                            .background(MaterialTheme.colorScheme.background)
                    ) {
                        AuthScreen(
                            currentLanguage = currentLanguage,
                            onBackClick = { showAuthScreen = false },
                            onAuthSuccess = { identifier, role ->
                                userProfile = userProfile.copy(email = identifier, fullName = identifier.substringBefore("@"))
                                isSignedIn = true
                                viewModel.setRole(role)
                                showAuthScreen = false
                            },
                            onShowToast = { viewModel.showToast(it) }
                        )
                    }
                } else {
                    Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding(),
                    bottomBar = {
                        BottomNavBar(
                            selectedTab = selectedTab,
                            currentLanguage = currentLanguage,
                            onTabSelected = {
                                activeSelectedCategory = null
                                showAuthScreen = false
                                showSettingsScreen = false
                                viewModel.selectTab(it)
                            },
                            onAddClick = { showCategoryBottomSheet = true }
                        )
                    }
                ) { innerPadding ->
                    BoxWithConstraints(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .background(MaterialTheme.colorScheme.background)
                    ) {
                        // Floating Top Push Notification Banner ("notification veliya show agunum")
                        AnimatedVisibility(
                            visible = activeNotificationBanner != null,
                            enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
                            exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .padding(top = 8.dp, start = 12.dp, end = 12.dp)
                                .zIndex(999f)
                        ) {
                            activeNotificationBanner?.let { msg ->
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(16.dp)),
                                    color = PinkPrimary,
                                    shadowElevation = 10.dp
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.NotificationsActive, contentDescription = "Notification", tint = Color.White)
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = if (currentLanguage == Language.TAMIL) "🔔 நேரலை அறிவிப்பு (Push Notification)" else "🔔 Live Push Notification",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 10.5.sp,
                                                color = Color.White.copy(alpha = 0.85f)
                                            )
                                            Text(
                                                text = msg,
                                                fontWeight = FontWeight.Black,
                                                fontSize = 12.5.sp,
                                                color = Color.White
                                            )
                                        }
                                        IconButton(onClick = { activeNotificationBanner = null }, modifier = Modifier.size(24.dp)) {
                                            Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = Color.White, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }
                        }

                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .widthIn(max = 760.dp)
                                .align(Alignment.TopCenter)
                        ) {
                            // Header Title Card & Location Breadcrumb (Hidden on Home Screen as Home Screen has its own custom branded header)
                            if (selectedTab != 0 && !showSettingsScreen && activeSelectedCategory == null) {
                                HeaderTitleCard(
                                    currentLanguage = currentLanguage,
                                    isDarkMode = isDarkMode,
                                    currentRole = currentRole,
                                    onLanguageToggle = { viewModel.toggleLanguage() },
                                    onDarkModeToggle = { viewModel.toggleDarkMode() },
                                    onRoleSelect = { viewModel.setRole(it) },
                                    onSettingsClick = { showSettingsScreen = true },
                                    onPrinterClick = { showThermalPrinterDialog = true },
                                    onAuthClick = { showAuthScreen = true },
                                    onProfileClick = { showProfileDialog = true }
                                )

                                LocationBreadcrumb(
                                    district = district,
                                    taluk = taluk,
                                    village = village,
                                    currentLanguage = currentLanguage,
                                    onChangeClick = { showLocationPicker = true }
                                )
                            }

                            // Active Screen View
                            Box(modifier = Modifier.weight(1f)) {
                                if (showSettingsScreen) {
                                    SettingsScreen(
                                        userProfile = userProfile,
                                        currentRole = currentRole,
                                        currentLanguage = currentLanguage,
                                        isDarkMode = isDarkMode,
                                        onBackClick = { showSettingsScreen = false },
                                        onLanguageToggle = { viewModel.toggleLanguage() },
                                        onDarkModeToggle = { viewModel.toggleDarkMode() },
                                        onRoleSelect = { viewModel.setRole(it) },
                                        onOpenAdminPanel = {
                                            showSettingsScreen = false
                                            viewModel.selectTab(5)
                                        },
                                        onLogoutClick = {
                                            isSignedIn = false
                                            showSettingsScreen = false
                                            showAuthScreen = true
                                            viewModel.showToast("Logged out successfully!")
                                        },
                                        onShowToast = { viewModel.showToast(it) },
                                        savedBookings = savedBookings,
                                        onCancelBooking = { id -> viewModel.cancelBooking(id) },
                                        onUpdateBookingStatus = { id, status -> viewModel.updateBookingStatus(id, status) },
                                        onDeleteBooking = { id -> viewModel.deleteBooking(id) },
                                        onSeedSampleBookings = { viewModel.addSampleBookings() },
                                        onViewInvoice = { booking -> viewModel.viewInvoiceForBooking(booking) }
                                    )
                                } else if (activeSelectedCategory != null) {
                                    ServiceCategoryDetailScreen(
                                        category = activeSelectedCategory!!,
                                        currentDistrict = district,
                                        currentLanguage = currentLanguage,
                                        onBackClick = { activeSelectedCategory = null },
                                        onBookVenue = { venue ->
                                            viewModel.setSelectedVenue(venue)
                                            activeSelectedCategory = null
                                            viewModel.selectTab(1) // Event tab
                                        },
                                        onToggleWishlist = { venue ->
                                            viewModel.toggleVenueWishlist(venue)
                                        },
                                        onShowToast = { viewModel.showToast(it) }
                                    )
                                } else {
                                    when (selectedTab) {
                                        0 -> HomeScreen(
                                            district = district,
                                            village = village,
                                            searchQuery = searchQuery,
                                            selectedCategory = categoryId,
                                            lastBooking = lastCreatedBooking,
                                            currentLanguage = currentLanguage,
                                            onSearchChange = { viewModel.setSearchQuery(it) },
                                            onCategorySelect = { selectedCatId ->
                                                val foundCat = SampleData.sampleCategories.find { it.id == selectedCatId }
                                                if (foundCat != null) {
                                                    activeSelectedCategory = foundCat
                                                } else {
                                                    viewModel.setCategoryFilter(selectedCatId)
                                                    viewModel.selectTab(1)
                                                }
                                            },
                                            onBookVenueClick = {
                                                viewModel.setSelectedVenue(it)
                                                viewModel.selectTab(1)
                                            },
                                            onViewProductClick = {
                                                viewModel.setSelectedProduct(it)
                                                viewModel.selectTab(3)
                                            },
                                            onOpenMapClick = { viewModel.selectTab(1) },
                                            onOpenAiClick = { showAuthScreen = true },
                                            onPrinterClick = { showThermalPrinterDialog = true },
                                            onOpenSettingsClick = { showSettingsScreen = true },
                                            wishlistItems = wishlistItems,
                                            onToggleWishlist = { viewModel.toggleVenueWishlist(it) },
                                            onNextProcessClick = { viewModel.selectTab(1) }
                                        )

                                        1 -> EventBookingScreen(
                                            currentDistrict = district,
                                            currentVillage = village,
                                            selectedCategory = categoryId,
                                            selectedVenue = selectedVenue,
                                            showPaymentDialog = showPaymentDialog,
                                            bookingDate = bookingDate,
                                            bookingTimeSlot = bookingTimeSlot,
                                            guestCount = guestCount,
                                            currentLanguage = currentLanguage,
                                            savedBookings = savedBookings,
                                            onCategorySelect = { viewModel.setCategoryFilter(it) },
                                            onSelectVenue = { viewModel.setSelectedVenue(it) },
                                            onUpdateBookingDetails = { d, t, g -> viewModel.setBookingDetails(d, t, g) },
                                            onOpenPayment = { viewModel.openPaymentDialog() },
                                            onClosePayment = { viewModel.closePaymentDialog() },
                                            onConfirmBooking = { method -> viewModel.confirmBooking(method) },
                                            onCancelBooking = { viewModel.cancelBooking(it) },
                                            onAddSampleBookings = { viewModel.addSampleBookings() },
                                            onViewReceipt = { viewModel.viewInvoiceForBooking(it) },
                                            onShowToast = { viewModel.showToast(it) },
                                            wishlistItems = wishlistItems,
                                            onToggleWishlist = { viewModel.toggleVenueWishlist(it) }
                                        )

                                        2 -> JobsWorkScreen(
                                            currentLanguage = currentLanguage,
                                            onShowToast = { viewModel.showToast(it) }
                                        )

                                         3 -> MarketplaceScreen(
                                            currentVillage = village,
                                            cartItems = cartItems,
                                            wishlistItems = wishlistItems,
                                            eCommerceProducts = eCommerceProducts,
                                            priceRange = priceRange,
                                            selectedProduct = selectedProduct,
                                            currentLanguage = currentLanguage,
                                            referralSettings = referralSettings,
                                            marketProducts = marketProducts,
                                            onPriceRangeChange = { viewModel.setPriceRange(it) },
                                            onProductSelect = { viewModel.setSelectedProduct(it) },
                                            onAddToCart = { viewModel.addToCart(it) },
                                            onRemoveFromCart = { viewModel.removeFromCart(it) },
                                            onToggleWishlist = { viewModel.toggleWishlist(it) },
                                            onRemoveFromWishlist = { viewModel.removeFromWishlist(it) },
                                            onSaveEcommerceToWishlist = { viewModel.saveEcommerceToWishlist(it) },
                                            onFetchEcommerceLink = { viewModel.fetchAndStoreEcommerceLink(it) },
                                            onDeleteECommerceProduct = { viewModel.deleteECommerceProduct(it) },
                                            onShowToast = { viewModel.showToast(it) }
                                        )

                                        4 -> AiAssistantScreen(
                                            currentVillage = village,
                                            chatMessages = chatMessages,
                                            currentLanguage = currentLanguage,
                                            onSendMessage = { viewModel.sendChatMessage(it) }
                                        )

                                        5 -> AdminVendorScreen(
                                            currentRole = currentRole,
                                            currentVillage = village,
                                            currentLanguage = currentLanguage,
                                            referralSettings = referralSettings,
                                            marketProducts = marketProducts,
                                            onUpdateReferralSettings = { viewModel.updateReferralSettings(it) },
                                            onAddMarketProduct = { viewModel.addMarketProduct(it) },
                                            onUpdateMarketProduct = { viewModel.updateMarketProduct(it) },
                                            onDeleteMarketProduct = { viewModel.deleteMarketProduct(it) },
                                            onToggleProductEnabled = { viewModel.toggleProductEnabled(it) },
                                            onToggleProductFeatured = { viewModel.toggleProductFeatured(it) },
                                            onShowToast = { viewModel.showToast(it) }
                                        )
                                    }
                                }
                            }
                        }

                        // Thermal Printer Modal Dialog
                        if (showThermalPrinterDialog) {
                            ThermalPrinterDialog(
                                onDismissRequest = { showThermalPrinterDialog = false }
                            )
                        }

                        // Profile Modal Dialog triggered by profile/logo click
                        if (showProfileDialog) {
                            ProfileModalDialog(
                                userProfile = userProfile,
                                currentRole = currentRole,
                                district = district,
                                village = village,
                                onDismiss = { showProfileDialog = false },
                                onOpenSettings = { showSettingsScreen = true },
                                onRoleSelect = { viewModel.setRole(it) }
                            )
                        }

                        // Category Animated Bottom Sheet triggered by Center Floating + FAB
                        if (showCategoryBottomSheet) {
                            CategoryBottomSheet(
                                currentLanguage = currentLanguage,
                                onDismiss = { showCategoryBottomSheet = false },
                                onCategorySelected = { category ->
                                    activeSelectedCategory = category
                                    showCategoryBottomSheet = false
                                }
                            )
                        }

                        // Digital Invoice Dialog
                        if (showInvoiceModal && lastCreatedBooking != null) {
                            InvoiceModalDialog(
                                booking = lastCreatedBooking!!,
                                onDismiss = { viewModel.closeInvoiceModal() },
                                onShare = { viewModel.showToast("Shared Invoice #${lastCreatedBooking!!.bookingId} to WhatsApp") },
                                onPrintThermal = { showThermalPrinterDialog = true }
                            )
                        }

                        // Tamil Nadu Location Picker Sheet Dialog
                        if (showLocationPicker) {
                            Dialog(onDismissRequest = { showLocationPicker = false }) {
                                Surface(
                                    shape = RoundedCornerShape(24.dp),
                                    color = MaterialTheme.colorScheme.surface,
                                    modifier = Modifier.padding(8.dp)
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(16.dp)
                                    ) {
                                        Text(
                                            text = if (currentLanguage == Language.TAMIL) "கிராமத்தைத் தேர்ந்தெடுக்கவும்" else "Select Tamil Nadu Village",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 16.sp
                                        )
                                        Spacer(modifier = Modifier.height(12.dp))

                                        LazyColumn(
                                            modifier = Modifier.height(250.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            items(SampleData.sampleLocations) { loc ->
                                                val isCurrent = loc.village == village
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .clip(RoundedCornerShape(12.dp))
                                                        .background(if (isCurrent) PinkPrimary.copy(alpha = 0.15f) else Color.Transparent)
                                                        .border(0.5.dp, if (isCurrent) PinkPrimary else Color.LightGray, RoundedCornerShape(12.dp))
                                                        .clickable {
                                                            viewModel.setLocation(loc.district, loc.taluk, loc.village)
                                                            showLocationPicker = false
                                                        }
                                                        .padding(12.dp),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Column {
                                                        Text(
                                                            text = "📍 ${loc.village} (${loc.villageTamil})",
                                                            fontWeight = FontWeight.Bold,
                                                            fontSize = 13.sp
                                                        )
                                                        Text(
                                                            text = "${loc.taluk} Taluk, ${loc.district} • ${loc.pinCode}",
                                                            fontSize = 11.sp,
                                                            color = Color.Gray
                                                        )
                                                    }
                                                    if (isCurrent) {
                                                        Text(text = "Active", fontSize = 11.sp, color = PinkPrimary, fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(12.dp))

                                        Button(
                                            onClick = { showLocationPicker = false },
                                            colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text(text = "Done")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
}
