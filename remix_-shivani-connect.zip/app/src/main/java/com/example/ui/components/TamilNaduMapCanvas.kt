package com.example.ui.components

import android.content.Intent
import android.net.Uri
import android.util.Log
import androidx.compose.ui.platform.LocalContext
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CompassCalibration
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Language
import com.example.model.VenueOrService
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.PinkDark
import com.example.ui.theme.PinkPrimary
import com.example.ui.theme.SkyBluePrimary

data class DistrictRegion(
    val id: String,
    val nameEn: String,
    val nameTa: String,
    val regionZone: String,
    val centerNormalized: Offset, // (0.0 .. 1.0) relative on map canvas
    val polygonPoints: List<Offset>, // normalized points forming boundary
    val serviceCount: Int,
    val villageCount: Int
)

data class VillageServicePin(
    val id: String,
    val villageNameEn: String,
    val villageNameTa: String,
    val districtId: String,
    val offsetNormalized: Offset, // relative offset within district
    val categoryId: String, // "marriage_hall", "catering", "photography", "dj_orchestra", "decoration"
    val categoryEmoji: String,
    val serviceTitleEn: String,
    val serviceTitleTa: String,
    val priceText: String,
    val rating: Float,
    val phone: String,
    val pinColor: Color,
    val mapUrl: String = ""
)

object TamilNaduDistrictsData {
    val districts = listOf(
        DistrictRegion(
            id = "Dharmapuri",
            nameEn = "Dharmapuri",
            nameTa = "தர்மபுரி",
            regionZone = "North-Western Region",
            centerNormalized = Offset(0.38f, 0.28f),
            polygonPoints = listOf(
                Offset(0.32f, 0.22f), Offset(0.44f, 0.21f),
                Offset(0.46f, 0.32f), Offset(0.35f, 0.34f)
            ),
            serviceCount = 18,
            villageCount = 42
        ),
        DistrictRegion(
            id = "Krishnagiri",
            nameEn = "Krishnagiri",
            nameTa = "கிருஷ்ணகிரி",
            regionZone = "North Border Hub",
            centerNormalized = Offset(0.38f, 0.16f),
            polygonPoints = listOf(
                Offset(0.30f, 0.10f), Offset(0.48f, 0.11f),
                Offset(0.44f, 0.21f), Offset(0.32f, 0.22f)
            ),
            serviceCount = 14,
            villageCount = 38
        ),
        DistrictRegion(
            id = "Salem",
            nameEn = "Salem",
            nameTa = "சேலம்",
            regionZone = "Central Mango Belt",
            centerNormalized = Offset(0.42f, 0.38f),
            polygonPoints = listOf(
                Offset(0.35f, 0.34f), Offset(0.46f, 0.32f),
                Offset(0.50f, 0.42f), Offset(0.38f, 0.44f)
            ),
            serviceCount = 22,
            villageCount = 55
        ),
        DistrictRegion(
            id = "Chennai",
            nameEn = "Chennai",
            nameTa = "சென்னை",
            regionZone = "Capital Coast",
            centerNormalized = Offset(0.82f, 0.12f),
            polygonPoints = listOf(
                Offset(0.78f, 0.08f), Offset(0.86f, 0.08f),
                Offset(0.86f, 0.16f), Offset(0.78f, 0.16f)
            ),
            serviceCount = 45,
            villageCount = 20
        ),
        DistrictRegion(
            id = "Vellore",
            nameEn = "Vellore",
            nameTa = "வேலூர்",
            regionZone = "Northern Fort Gateway",
            centerNormalized = Offset(0.62f, 0.15f),
            polygonPoints = listOf(
                Offset(0.52f, 0.10f), Offset(0.72f, 0.10f),
                Offset(0.70f, 0.20f), Offset(0.52f, 0.20f)
            ),
            serviceCount = 16,
            villageCount = 30
        ),
        DistrictRegion(
            id = "Coimbatore",
            nameEn = "Coimbatore",
            nameTa = "கோயம்புத்தூர்",
            regionZone = "Western Textile Hub",
            centerNormalized = Offset(0.18f, 0.48f),
            polygonPoints = listOf(
                Offset(0.10f, 0.42f), Offset(0.26f, 0.42f),
                Offset(0.26f, 0.54f), Offset(0.12f, 0.54f)
            ),
            serviceCount = 30,
            villageCount = 40
        ),
        DistrictRegion(
            id = "Erode",
            nameEn = "Erode",
            nameTa = "ஈரோடு",
            regionZone = "Kongu Turmeric Belt",
            centerNormalized = Offset(0.28f, 0.38f),
            polygonPoints = listOf(
                Offset(0.22f, 0.32f), Offset(0.35f, 0.34f),
                Offset(0.35f, 0.44f), Offset(0.22f, 0.42f)
            ),
            serviceCount = 15,
            villageCount = 32
        ),
        DistrictRegion(
            id = "Tiruchirappalli",
            nameEn = "Tiruchirappalli",
            nameTa = "திருச்சிராப்பள்ளி",
            regionZone = "Central Cauvery Heartland",
            centerNormalized = Offset(0.52f, 0.52f),
            polygonPoints = listOf(
                Offset(0.44f, 0.46f), Offset(0.60f, 0.46f),
                Offset(0.60f, 0.58f), Offset(0.44f, 0.58f)
            ),
            serviceCount = 25,
            villageCount = 48
        ),
        DistrictRegion(
            id = "Thanjavur",
            nameEn = "Thanjavur",
            nameTa = "தஞ்சாவூர்",
            regionZone = "Delta Rice Bowl",
            centerNormalized = Offset(0.66f, 0.56f),
            polygonPoints = listOf(
                Offset(0.60f, 0.50f), Offset(0.74f, 0.50f),
                Offset(0.74f, 0.62f), Offset(0.60f, 0.62f)
            ),
            serviceCount = 20,
            villageCount = 50
        ),
        DistrictRegion(
            id = "Madurai",
            nameEn = "Madurai",
            nameTa = "மதுரை",
            regionZone = "Southern Cultural Capital",
            centerNormalized = Offset(0.38f, 0.70f),
            polygonPoints = listOf(
                Offset(0.30f, 0.64f), Offset(0.48f, 0.64f),
                Offset(0.48f, 0.76f), Offset(0.30f, 0.76f)
            ),
            serviceCount = 28,
            villageCount = 45
        ),
        DistrictRegion(
            id = "Tirunelveli",
            nameEn = "Tirunelveli",
            nameTa = "திருநெல்வேலி",
            regionZone = "Thamirabarani Basin",
            centerNormalized = Offset(0.34f, 0.86f),
            polygonPoints = listOf(
                Offset(0.26f, 0.80f), Offset(0.44f, 0.80f),
                Offset(0.42f, 0.92f), Offset(0.26f, 0.92f)
            ),
            serviceCount = 19,
            villageCount = 36
        ),
        DistrictRegion(
            id = "Kanyakumari",
            nameEn = "Kanyakumari",
            nameTa = "கன்னியாகுமரி",
            regionZone = "Southernmost Coast",
            centerNormalized = Offset(0.28f, 0.96f),
            polygonPoints = listOf(
                Offset(0.22f, 0.92f), Offset(0.34f, 0.92f),
                Offset(0.32f, 0.99f), Offset(0.22f, 0.98f)
            ),
            serviceCount = 12,
            villageCount = 22
        )
    )

    val villagePins = listOf(
        // Dharmapuri & Harur
        VillageServicePin(
            id = "v_dh_1",
            villageNameEn = "Harur Town",
            villageNameTa = "அரூர் டவுன்",
            districtId = "Dharmapuri",
            offsetNormalized = Offset(0.35f, 0.26f),
            categoryId = "marriage_hall",
            categoryEmoji = "🏰",
            serviceTitleEn = "Harur Sri Raja Mahal",
            serviceTitleTa = "அரூர் ஸ்ரீ ராஜா மஹால்",
            priceText = "₹12,000 / day",
            rating = 4.8f,
            phone = "+91 94432 10987",
            pinColor = Color(0xFFEC4899),
            mapUrl = "https://maps.app.goo.gl/VAn6vQPq6Qb3Jy829"
        ),
        VillageServicePin(
            id = "v_dh_2",
            villageNameEn = "Dharmapuri Town",
            villageNameTa = "தர்மபுரி டவுன்",
            districtId = "Dharmapuri",
            offsetNormalized = Offset(0.39f, 0.31f),
            categoryId = "catering",
            categoryEmoji = "🍲",
            serviceTitleEn = "Dharmapuri Sri Murugan Catering",
            serviceTitleTa = "தர்மபுரி ஸ்ரீ முருகன் சமையல்",
            priceText = "₹220 / leaf",
            rating = 4.9f,
            phone = "+91 98765 12340",
            pinColor = Color(0xFFF59E0B),
            mapUrl = "https://maps.app.goo.gl/SSPhEhtgKi2o8qA97"
        ),
        VillageServicePin(
            id = "v_dh_3",
            villageNameEn = "Pappireddipatti",
            villageNameTa = "பாப்பிரெட்டிப்பட்டி",
            districtId = "Dharmapuri",
            offsetNormalized = Offset(0.42f, 0.29f),
            categoryId = "dj_orchestra",
            categoryEmoji = "🎵",
            serviceTitleEn = "Harur Royal DJ Orchestra",
            serviceTitleTa = "அரூர் ராயல் DJ ஆர்கெஸ்ட்ரா",
            priceText = "₹15,000 / event",
            rating = 4.7f,
            phone = "+91 98421 99887",
            pinColor = Color(0xFF10B981),
            mapUrl = "https://maps.app.goo.gl/VAn6vQPq6Qb3Jy829"
        ),

        // Salem
        VillageServicePin(
            id = "v_slm_1",
            villageNameEn = "Kannankurichi",
            villageNameTa = "கண்ணங்குறிச்சி",
            districtId = "Salem",
            offsetNormalized = Offset(0.42f, 0.38f),
            categoryId = "marriage_hall",
            categoryEmoji = "🏰",
            serviceTitleEn = "Salem Royal Palace & Grand Banquet",
            serviceTitleTa = "சேலம் ராயல் பேலஸ் & மஹால்",
            priceText = "₹65,000 / day",
            rating = 5.0f,
            phone = "+91 98427 12345",
            pinColor = Color(0xFF8B5CF6),
            mapUrl = "https://maps.app.goo.gl/6RA4HBz7Q4WgkkGp9"
        ),

        // Madurai
        VillageServicePin(
            id = "v_md_1",
            villageNameEn = "Palamedu",
            villageNameTa = "பாலமேடு",
            districtId = "Madurai",
            offsetNormalized = Offset(0.36f, 0.68f),
            categoryId = "marriage_hall",
            categoryEmoji = "🏰",
            serviceTitleEn = "Meenakshi Amman Village Kalyana Mandapam",
            serviceTitleTa = "மீனாட்சி அம்மன் கல்யாண மண்டபம்",
            priceText = "₹15,000 / day",
            rating = 4.9f,
            phone = "+91 98765 43210",
            pinColor = Color(0xFFEC4899)
        ),
        VillageServicePin(
            id = "v_md_2",
            villageNameEn = "Alanganallur",
            villageNameTa = "அலங்காநல்லூர்",
            districtId = "Madurai",
            offsetNormalized = Offset(0.40f, 0.73f),
            categoryId = "photography",
            categoryEmoji = "📸",
            serviceTitleEn = "Jallikattu Village Studio & Drone",
            serviceTitleTa = "ஜல்லிக்கட்டு வில்லேஜ் ஸ்டுடியோ",
            priceText = "₹18,500 / event",
            rating = 4.8f,
            phone = "+91 94431 88221",
            pinColor = Color(0xFF38BDF8)
        ),

        // Coimbatore
        VillageServicePin(
            id = "v_cbe_1",
            villageNameEn = "Pollachi Rural",
            villageNameTa = "பொள்ளாச்சி கிராமம்",
            districtId = "Coimbatore",
            offsetNormalized = Offset(0.16f, 0.50f),
            categoryId = "decoration",
            categoryEmoji = "💐",
            serviceTitleEn = "Anamalai Coconut Leaf Floral Decor",
            serviceTitleTa = "ஆனைமலை இயற்கை பூ அலங்காரம்",
            priceText = "₹8,500 / Stage",
            rating = 4.9f,
            phone = "+91 98722 33441",
            pinColor = Color(0xFF8B5CF6)
        ),

        // Thanjavur
        VillageServicePin(
            id = "v_tj_1",
            villageNameEn = "Orathanadu",
            villageNameTa = "ஒரத்தநாடு",
            districtId = "Thanjavur",
            offsetNormalized = Offset(0.68f, 0.58f),
            categoryId = "catering",
            categoryEmoji = "🍲",
            serviceTitleEn = "Delta Traditional Banana Leaf Feast",
            serviceTitleTa = "டெல்டா பாரம்பரிய விருந்து",
            priceText = "₹220 / leaf",
            rating = 5.0f,
            phone = "+91 94420 55667",
            pinColor = Color(0xFFF59E0B)
        )
    )
}

/**
 * Interactive visual map component of Tamil Nadu supporting geographical visualizer,
 * polygon overlays, highway networks, category filters, and village-specific service drilldowns.
 */
@Composable
fun InteractiveTamilNaduMap(
    selectedDistrict: String,
    currentLanguage: Language,
    onDistrictSelect: (DistrictRegion) -> Unit,
    onBookServiceClick: ((VillageServicePin) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var activeDistrict by remember(selectedDistrict) {
        mutableStateOf(
            TamilNaduDistrictsData.districts.firstOrNull { it.id.equals(selectedDistrict, ignoreCase = true) }
                ?: TamilNaduDistrictsData.districts.first()
        )
    }

    var selectedCategoryFilter by remember { mutableStateOf("ALL") }
    var selectedVillagePin by remember { mutableStateOf<VillageServicePin?>(null) }
    var isZoomedIn by remember { mutableStateOf(false) }

    val filteredPins = remember(activeDistrict, selectedCategoryFilter) {
        TamilNaduDistrictsData.villagePins.filter { pin ->
            val matchDistrict = pin.districtId.equals(activeDistrict.id, ignoreCase = true)
            val matchCat = selectedCategoryFilter == "ALL" || pin.categoryId.equals(selectedCategoryFilter, ignoreCase = true)
            matchDistrict && matchCat
        }
    }

    // Pulse animation for active region pin
    val infiniteTransition = rememberInfiniteTransition(label = "mapPulse")
    val pulseRadius by infiniteTransition.animateFloat(
        initialValue = 10f,
        targetValue = 32f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulseRadius"
    )
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulseAlpha"
    )

    GlassCard(
        modifier = modifier,
        backgroundColor = Color(0xFF0F172A), // Deep dark navy canvas background
        borderColor = PinkPrimary.copy(alpha = 0.5f)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Interactive Geographic Map Canvas
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(isZoomedIn, activeDistrict) {
                        detectTapGestures { tapOffset ->
                            val width = size.width
                            val height = size.height

                            // First check if tapped near any village pin
                            var tappedPin: VillageServicePin? = null
                            var minPinDist = Float.MAX_VALUE

                            filteredPins.forEach { pin ->
                                val px = pin.offsetNormalized.x * width
                                val py = pin.offsetNormalized.y * height
                                val distSq = (tapOffset.x - px) * (tapOffset.x - px) + (tapOffset.y - py) * (tapOffset.y - py)
                                if (distSq < 1600f && distSq < minPinDist) { // 40px radius check
                                    minPinDist = distSq
                                    tappedPin = pin
                                }
                            }

                            if (tappedPin != null) {
                                selectedVillagePin = tappedPin
                                Log.d("sk", "Interactive Map: Tapped Village Pin ${tappedPin?.serviceTitleEn}")
                                return@detectTapGestures
                            }

                            // Otherwise find closest district center to tap point
                            var minDistance = Float.MAX_VALUE
                            var closestDistrict: DistrictRegion? = null

                            TamilNaduDistrictsData.districts.forEach { dist ->
                                val cx = dist.centerNormalized.x * width
                                val cy = dist.centerNormalized.y * height
                                val distSq = (tapOffset.x - cx) * (tapOffset.x - cx) + (tapOffset.y - cy) * (tapOffset.y - cy)
                                if (distSq < minDistance) {
                                    minDistance = distSq
                                    closestDistrict = dist
                                }
                            }

                            closestDistrict?.let { dist ->
                                Log.d("sk", "Interactive Map: Tapped district ${dist.id}")
                                activeDistrict = dist
                                selectedVillagePin = null
                                onDistrictSelect(dist)
                            }
                        }
                    }
            ) {
                val width = size.width
                val height = size.height

                // 1. Draw subtle lat/long grid lines
                drawMapGrid(width, height)

                // 2. Draw Tamil Nadu State Silhouette Contour Path
                drawTamilNaduBoundary(width, height)

                // 3. Draw Connecting Highways (NH44 / NH48 / NH83 backbone)
                drawHighways(width, height)

                // 4. Draw Coastal Bay of Bengal Water Wave Accents
                drawCoastalWaves(width, height)

                // 5. Draw Compass Rose & Scale Bar
                drawCompassAndScale(width, height)

                // 6. Draw District Region Polygons & District Pins
                TamilNaduDistrictsData.districts.forEach { dist ->
                    val isSelected = dist.id.equals(activeDistrict.id, ignoreCase = true)
                    val cx = dist.centerNormalized.x * width
                    val cy = dist.centerNormalized.y * height

                    // Polygon boundaries
                    if (dist.polygonPoints.isNotEmpty()) {
                        val polyPath = Path().apply {
                            val first = dist.polygonPoints.first()
                            moveTo(first.x * width, first.y * height)
                            for (i in 1 until dist.polygonPoints.size) {
                                val pt = dist.polygonPoints[i]
                                lineTo(pt.x * width, pt.y * height)
                            }
                            close()
                        }

                        val polyFill = if (isSelected) {
                            Color(0xFFEC4899).copy(alpha = 0.35f)
                        } else {
                            Color(0xFF38BDF8).copy(alpha = 0.12f)
                        }
                        val polyStroke = if (isSelected) Color(0xFFF59E0B) else Color(0xFF38BDF8).copy(alpha = 0.3f)

                        drawPath(polyPath, color = polyFill)
                        drawPath(polyPath, color = polyStroke, style = Stroke(width = if (isSelected) 3f else 1.5f))
                    }

                    // District Center Pin
                    if (isSelected) {
                        drawCircle(
                            color = Color(0xFFEC4899).copy(alpha = pulseAlpha),
                            radius = pulseRadius,
                            center = Offset(cx, cy)
                        )
                        drawCircle(Color(0xFFF59E0B), radius = 12f, center = Offset(cx, cy))
                        drawCircle(Color.White, radius = 5f, center = Offset(cx, cy))
                    } else {
                        drawCircle(Color(0xFF38BDF8), radius = 8f, center = Offset(cx, cy))
                        drawCircle(Color.White, radius = 3f, center = Offset(cx, cy))
                    }
                }

                // 7. Draw Village Service Pins inside active district
                filteredPins.forEach { pin ->
                    val px = pin.offsetNormalized.x * width
                    val py = pin.offsetNormalized.y * height
                    val isPinSelected = pin.id == selectedVillagePin?.id

                    // Glow background for village pin
                    drawCircle(
                        color = if (isPinSelected) Color.White else pin.pinColor.copy(alpha = 0.4f),
                        radius = if (isPinSelected) 18f else 12f,
                        center = Offset(px, py)
                    )
                    drawCircle(
                        color = pin.pinColor,
                        radius = if (isPinSelected) 12f else 8f,
                        center = Offset(px, py)
                    )
                    drawCircle(
                        color = Color.White,
                        radius = 4f,
                        center = Offset(px, py)
                    )
                }
            }

            // Top Status & Controls Overlay Bar
            Row(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .fillMaxWidth()
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Title Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF1E293B).copy(alpha = 0.9f))
                        .border(1.dp, PinkPrimary.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CompassCalibration,
                            contentDescription = null,
                            tint = SkyBluePrimary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (currentLanguage == Language.TAMIL) "நேரலை தமிழ்நாடு வரைபடம்" else "INTERACTIVE TN MAP",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }

                // Zoom Level Toggle Button
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color(0xFF1E293B).copy(alpha = 0.9f))
                        .border(1.dp, GoldPrimary.copy(alpha = 0.5f), CircleShape)
                        .clickable { isZoomedIn = !isZoomedIn }
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isZoomedIn) Icons.Default.ZoomOut else Icons.Default.ZoomIn,
                            contentDescription = "Zoom Toggle",
                            tint = GoldPrimary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isZoomedIn) "State View" else "Village Zoom",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }

            // Category Filter Chips Bar Overlay (Top Center)
            LazyRow(
                contentPadding = PaddingValues(horizontal = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 44.dp)
            ) {
                val filters = listOf(
                    "ALL" to "All Services",
                    "marriage_hall" to "🏰 Halls",
                    "catering" to "🍲 Catering",
                    "photography" to "📸 Photo",
                    "dj_orchestra" to "🎵 DJ & Band",
                    "decoration" to "💐 Decor"
                )

                items(filters) { (key, label) ->
                    val isSel = selectedCategoryFilter == key
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSel) PinkPrimary else Color(0xFF1E293B).copy(alpha = 0.85f))
                            .border(
                                1.dp,
                                if (isSel) PinkPrimary else Color.White.copy(alpha = 0.2f),
                                RoundedCornerShape(12.dp)
                            )
                            .clickable {
                                selectedCategoryFilter = key
                                selectedVillagePin = null
                            }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = label,
                            fontSize = 10.sp,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                            color = Color.White
                        )
                    }
                }
            }

            // Interactive Pin Callout Card OR Floating District Tooltip Card Overlay (Bottom)
            if (selectedVillagePin != null) {
                val pin = selectedVillagePin!!
                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(10.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFF0F172A).copy(alpha = 0.98f),
                    tonalElevation = 10.dp
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(text = pin.categoryEmoji, fontSize = 20.sp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = if (currentLanguage == Language.TAMIL) pin.serviceTitleTa else pin.serviceTitleEn,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "📍 ${pin.villageNameEn} (${pin.villageNameTa}) • ${pin.districtId}",
                                        fontSize = 11.sp,
                                        color = Color(0xFF94A3B8)
                                    )
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = 0.1f))
                                    .clickable { selectedVillagePin = null }
                                    .padding(6.dp)
                            ) {
                                Text("✕", color = Color.White, fontSize = 12.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Star, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(text = "${pin.rating}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(text = pin.priceText, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = PinkPrimary)
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                if (pin.mapUrl.isNotBlank()) {
                                    OutlinedButton(
                                        onClick = {
                                            try {
                                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(pin.mapUrl))
                                                context.startActivity(intent)
                                            } catch (e: Exception) {
                                                Log.e("sk", "Error opening map", e)
                                            }
                                        },
                                        shape = RoundedCornerShape(10.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, PinkPrimary)
                                    ) {
                                        Text(text = "📍 Maps", fontSize = 10.5.sp, color = PinkPrimary, fontWeight = FontWeight.Bold)
                                    }
                                }

                                Button(
                                    onClick = {
                                        if (onBookServiceClick != null) {
                                            onBookServiceClick(pin)
                                        } else {
                                            onDistrictSelect(activeDistrict)
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                                    shape = RoundedCornerShape(10.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = if (currentLanguage == Language.TAMIL) "முன்பதிவு" else "Book",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(10.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFF1E293B).copy(alpha = 0.95f),
                    tonalElevation = 8.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.linearGradient(
                                            colors = listOf(PinkPrimary, GoldPrimary)
                                        )
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Place,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = if (currentLanguage == Language.TAMIL) activeDistrict.nameTa else activeDistrict.nameEn,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = Color.White
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "(${activeDistrict.nameTa})",
                                        fontSize = 12.sp,
                                        color = GoldPrimary,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                                Text(
                                    text = "${activeDistrict.regionZone} • ${activeDistrict.serviceCount} Services • ${filteredPins.size} Village Pins",
                                    fontSize = 10.sp,
                                    color = Color(0xFF94A3B8)
                                )
                            }
                        }

                        Button(
                            onClick = {
                                Log.d("sk", "Interactive Map: Confirmed selection of ${activeDistrict.id}")
                                onDistrictSelect(activeDistrict)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Navigation,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (currentLanguage == Language.TAMIL) "தேர்வு" else "Select",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun DrawScope.drawMapGrid(width: Float, height: Float) {
    val cols = 8
    val rows = 8
    val dx = width / cols
    val dy = height / rows

    val gridColor = Color.White.copy(alpha = 0.05f)
    for (i in 1 until cols) {
        drawLine(gridColor, start = Offset(i * dx, 0f), end = Offset(i * dx, height), strokeWidth = 1f)
    }
    for (j in 1 until rows) {
        drawLine(gridColor, start = Offset(0f, j * dy), end = Offset(width, j * dy), strokeWidth = 1f)
    }
}

private fun DrawScope.drawTamilNaduBoundary(width: Float, height: Float) {
    val contourPath = Path().apply {
        // Tamil Nadu Geographic Outline Silhouette
        moveTo(width * 0.30f, height * 0.10f) // North-West Hosur
        lineTo(width * 0.50f, height * 0.08f) // North Border
        lineTo(width * 0.85f, height * 0.10f) // Chennai North Coast
        lineTo(width * 0.80f, height * 0.35f) // Pondicherry / Cuddalore Coast
        lineTo(width * 0.75f, height * 0.58f) // Nagapattinam / Delta
        lineTo(width * 0.60f, height * 0.78f) // Palk Strait / Ramanathapuram
        lineTo(width * 0.42f, height * 0.88f) // Tuticorin Coast
        lineTo(width * 0.28f, height * 0.98f) // Kanyakumari Tip
        lineTo(width * 0.22f, height * 0.88f) // Western Ghats Tenkasi
        lineTo(width * 0.25f, height * 0.68f) // Theni / Anamalai
        lineTo(width * 0.12f, height * 0.48f) // Nilgiris / Coimbatore
        lineTo(width * 0.28f, height * 0.22f) // Salem / Krishnagiri West
        close()
    }

    drawPath(
        path = contourPath,
        color = Color(0xFF1E293B).copy(alpha = 0.5f)
    )
    drawPath(
        path = contourPath,
        color = Color(0xFF38BDF8).copy(alpha = 0.4f),
        style = Stroke(
            width = 2.5f,
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 6f), 0f)
        )
    )
}

private fun DrawScope.drawHighways(width: Float, height: Float) {
    // NH44 Backbone Route: Chennai -> Krishnagiri -> Dharmapuri -> Salem -> Trichy -> Madurai -> Kanyakumari
    val highwayPath = Path().apply {
        moveTo(width * 0.82f, height * 0.12f) // Chennai
        lineTo(width * 0.62f, height * 0.15f) // Vellore
        lineTo(width * 0.38f, height * 0.16f) // Krishnagiri
        lineTo(width * 0.38f, height * 0.28f) // Dharmapuri
        lineTo(width * 0.42f, height * 0.38f) // Salem
        lineTo(width * 0.52f, height * 0.52f) // Trichy
        lineTo(width * 0.38f, height * 0.70f) // Madurai
        lineTo(width * 0.34f, height * 0.86f) // Tirunelveli
        lineTo(width * 0.28f, height * 0.96f) // Kanyakumari
    }

    drawPath(
        path = highwayPath,
        color = Color(0xFFF59E0B).copy(alpha = 0.35f),
        style = Stroke(width = 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 4f), 0f))
    )
}

private fun DrawScope.drawCoastalWaves(width: Float, height: Float) {
    val seaColor = Color(0xFF0284C7).copy(alpha = 0.15f)
    // Bay of Bengal Coastline Shading Right Side
    val seaPath = Path().apply {
        moveTo(width * 0.85f, height * 0.10f)
        lineTo(width, height * 0.10f)
        lineTo(width, height)
        lineTo(width * 0.28f, height)
        lineTo(width * 0.42f, height * 0.88f)
        lineTo(width * 0.60f, height * 0.78f)
        lineTo(width * 0.75f, height * 0.58f)
        lineTo(width * 0.80f, height * 0.35f)
        close()
    }
    drawPath(seaPath, color = seaColor)
}

private fun DrawScope.drawCompassAndScale(width: Float, height: Float) {
    // Compass Rose (Top Right)
    val cx = width * 0.90f
    val cy = height * 0.22f

    val compassColor = Color.White.copy(alpha = 0.4f)
    drawLine(compassColor, start = Offset(cx, cy - 14f), end = Offset(cx, cy + 14f), strokeWidth = 1.5f)
    drawLine(compassColor, start = Offset(cx - 14f, cy), end = Offset(cx + 14f, cy), strokeWidth = 1.5f)
    drawCircle(Color(0xFFEC4899), radius = 3f, center = Offset(cx, cy - 14f)) // North Red Point

    // Scale Bar (Bottom Right)
    val sx = width * 0.72f
    val sy = height * 0.92f
    drawLine(Color.White.copy(alpha = 0.5f), start = Offset(sx, sy), end = Offset(sx + 40f, sy), strokeWidth = 2f)
    drawLine(Color.White.copy(alpha = 0.5f), start = Offset(sx, sy - 3f), end = Offset(sx, sy + 3f), strokeWidth = 2f)
    drawLine(Color.White.copy(alpha = 0.5f), start = Offset(sx + 40f, sy - 3f), end = Offset(sx + 40f, sy + 3f), strokeWidth = 2f)
}
