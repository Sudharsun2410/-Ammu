package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Mouse
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.R
import com.example.model.AdminReferralSettings
import com.example.model.Language
import com.example.model.MarketProduct
import com.example.model.UserRole
import com.example.ui.components.BackupManagerCard
import com.example.ui.components.GlassBadge
import com.example.ui.components.GlassCard
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.PinkDark
import com.example.ui.theme.PinkPrimary

@Composable
fun AdminVendorScreen(
    currentRole: UserRole,
    currentVillage: String,
    currentLanguage: Language,
    referralSettings: AdminReferralSettings = AdminReferralSettings(),
    marketProducts: List<MarketProduct> = emptyList(),
    onUpdateReferralSettings: (AdminReferralSettings) -> Unit = {},
    onAddMarketProduct: (MarketProduct) -> Unit = {},
    onUpdateMarketProduct: (MarketProduct) -> Unit = {},
    onDeleteMarketProduct: (String) -> Unit = {},
    onToggleProductEnabled: (String) -> Unit = {},
    onToggleProductFeatured: (String) -> Unit = {},
    onShowToast: (String) -> Unit
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
            .padding(bottom = 80.dp)
    ) {
        // Workspace Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "${currentRole.displayName} Portal",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Shivani Connect Enterprise Control Panel",
                    fontSize = 11.sp,
                    color = PinkPrimary,
                    fontWeight = FontWeight.Bold
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(currentRole.badgeColorHex).copy(alpha = 0.15f))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    text = currentRole.displayName.uppercase(),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Black,
                    color = Color(currentRole.badgeColorHex)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        when (currentRole) {
            UserRole.ADMIN -> AdminView(
                referralSettings = referralSettings,
                marketProducts = marketProducts,
                onUpdateReferralSettings = onUpdateReferralSettings,
                onAddMarketProduct = onAddMarketProduct,
                onUpdateMarketProduct = onUpdateMarketProduct,
                onDeleteMarketProduct = onDeleteMarketProduct,
                onToggleProductEnabled = onToggleProductEnabled,
                onToggleProductFeatured = onToggleProductFeatured,
                onShowToast = onShowToast
            )
            UserRole.VENDOR -> VendorView(currentVillage = currentVillage, onShowToast = onShowToast)
            UserRole.AGENT -> AgentView(currentVillage = currentVillage, onShowToast = onShowToast)
            UserRole.USER -> UserWorkspaceView(onShowToast = onShowToast)
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Data Backup & Archival System
        BackupManagerCard(onShowToast = onShowToast)
    }
}

@Composable
fun AdminView(
    referralSettings: AdminReferralSettings,
    marketProducts: List<MarketProduct>,
    onUpdateReferralSettings: (AdminReferralSettings) -> Unit,
    onAddMarketProduct: (MarketProduct) -> Unit,
    onUpdateMarketProduct: (MarketProduct) -> Unit,
    onDeleteMarketProduct: (String) -> Unit,
    onToggleProductEnabled: (String) -> Unit,
    onToggleProductFeatured: (String) -> Unit,
    onShowToast: (String) -> Unit
) {
    var activeAdminTab by remember { mutableStateOf(0) } // 0: Overview, 1: Info Services, 2: Referral, 3: Products, 4: All Access

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Sub Navigation Bar inside Admin Panel (All Access Controls)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(PinkPrimary.copy(alpha = 0.08f))
                .padding(4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            val tabs = listOf("📊 Overview", "ℹ️ Info Services", "🔗 Referral", "🛍️ Products", "👑 All Access")
            tabs.forEachIndexed { index, title ->
                val isSelected = activeAdminTab == index
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isSelected) PinkPrimary else Color.Transparent)
                        .clickable { activeAdminTab = index }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = title,
                        fontSize = 10.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onBackground
                    )
                }
            }
        }

        when (activeAdminTab) {
            0 -> AdminOverviewSection(onShowToast = onShowToast)
            1 -> AdminInfoServicesSection(onShowToast = onShowToast)
            2 -> AdminReferralSettingsSection(
                settings = referralSettings,
                onSave = onUpdateReferralSettings,
                onShowToast = onShowToast
            )
            3 -> AdminProductManagementSection(
                marketProducts = marketProducts,
                onAddProduct = onAddMarketProduct,
                onUpdateProduct = onUpdateMarketProduct,
                onDeleteProduct = onDeleteMarketProduct,
                onToggleEnabled = onToggleProductEnabled,
                onToggleFeatured = onToggleProductFeatured,
                onShowToast = onShowToast
            )
            4 -> AdminAllAccessSection(onShowToast = onShowToast)
        }
    }
}

@Composable
fun AdminOverviewSection(onShowToast: (String) -> Unit) {
    var selectedTimeframe by remember { mutableStateOf("30 Days") }

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        // Control Center Header Card with Logo
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .border(2.dp, Brush.linearGradient(listOf(PinkPrimary, GoldPrimary)), CircleShape)
                                .background(Color.Black),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.sk_shivani_skhub_logo_1785082786285),
                                contentDescription = "SHIVANI SKHub Logo",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                            )
                        }

                        Column {
                            Text(
                                text = "SHIVANI SKHub Control Center",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Text(
                                text = "Summary Analytics & Performance Metrics",
                                fontSize = 11.sp,
                                color = PinkPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    IconButton(onClick = { onShowToast("Realtime Metrics Refreshed!") }) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = "Refresh", tint = PinkPrimary)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Timeframe Selector Pills
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.5f))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    val timeframes = listOf("24 Hours", "7 Days", "30 Days", "YTD")
                    timeframes.forEach { timeframe ->
                        val isSelected = selectedTimeframe == timeframe
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) PinkPrimary else Color.Transparent)
                                .clickable { selectedTimeframe = timeframe }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = timeframe,
                                fontSize = 10.5.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onBackground
                            )
                        }
                    }
                }
            }
        }

        // Key Metric KPI Summary Cards (2x2 Grid)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Card 1: Total Bookings
            GlassCard(modifier = Modifier.weight(1f)) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "TOTAL BOOKINGS", fontSize = 9.sp, fontWeight = FontWeight.Black, color = Color.Gray)
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = PinkPrimary, modifier = Modifier.size(16.dp))
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "184", fontWeight = FontWeight.Black, fontSize = 22.sp, color = MaterialTheme.colorScheme.onBackground)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(imageVector = Icons.Default.TrendingUp, contentDescription = null, tint = Color(0xFF16A34A), modifier = Modifier.size(12.dp))
                        Text(text = "+24.2% YoY", fontSize = 10.sp, color = Color(0xFF16A34A), fontWeight = FontWeight.Bold)
                    }
                    Text(text = "₹4.85 L Volume", fontSize = 9.5.sp, color = Color.Gray)
                }
            }

            // Card 2: Active Vendor Listings
            GlassCard(modifier = Modifier.weight(1f)) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "ACTIVE VENDORS", fontSize = 9.sp, fontWeight = FontWeight.Black, color = Color.Gray)
                        Icon(imageVector = Icons.Default.Store, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(16.dp))
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "52 Verified", fontWeight = FontWeight.Black, fontSize = 22.sp, color = MaterialTheme.colorScheme.onBackground)
                    Text(text = "38 TN Districts", fontSize = 10.sp, color = GoldPrimary, fontWeight = FontWeight.Bold)
                    Text(text = "4.9⭐ Avg Rating", fontSize = 9.5.sp, color = Color.Gray)
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Card 3: Marketplace Clicks
            GlassCard(modifier = Modifier.weight(1f)) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "MARKET CLICKS", fontSize = 9.sp, fontWeight = FontWeight.Black, color = Color.Gray)
                        Icon(imageVector = Icons.Default.Mouse, contentDescription = null, tint = Color(0xFF2874F0), modifier = Modifier.size(16.dp))
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "3,840", fontWeight = FontWeight.Black, fontSize = 22.sp, color = MaterialTheme.colorScheme.onBackground)
                    Text(text = "14.8% Conv Rate", fontSize = 10.sp, color = Color(0xFF2874F0), fontWeight = FontWeight.Bold)
                    Text(text = "Meesho, Flipkart, Amazon", fontSize = 9.5.sp, color = Color.Gray)
                }
            }

            // Card 4: Referral Commission
            GlassCard(modifier = Modifier.weight(1f)) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "REFERRAL EARNINGS", fontSize = 9.sp, fontWeight = FontWeight.Black, color = Color.Gray)
                        Icon(imageVector = Icons.Default.BarChart, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(16.dp))
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "₹32,450", fontWeight = FontWeight.Black, fontSize = 22.sp, color = Color(0xFF10B981))
                    Text(text = "128 Shared Links", fontSize = 10.sp, color = Color(0xFF10B981), fontWeight = FontWeight.Bold)
                    Text(text = "Payout Ready", fontSize = 9.5.sp, color = Color.Gray)
                }
            }
        }

        // D3-Style Chart 1: Marketplace Affiliate Clicks Bar Chart
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "MARKETPLACE CLICK ANALYTICS (D3 DYNAMIC CANVAS)", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                        Text(text = "Total Affiliate Clicks per Partner Channel", fontSize = 10.sp, color = Color.Gray)
                    }
                    GlassBadge(text = "3,840 CLICKS", containerColor = PinkPrimary.copy(alpha = 0.15f), contentColor = PinkPrimary)
                }

                Spacer(modifier = Modifier.height(16.dp))

                val marketClicks = listOf(
                    MarketClickData("Meesho", 1450, Color(0xFFE91E63)),
                    MarketClickData("Flipkart", 1120, Color(0xFF2874F0)),
                    MarketClickData("Amazon", 820, Color(0xFFFF9900)),
                    MarketClickData("Direct", 450, Color(0xFF25D366))
                )

                // D3 Bar Chart Canvas
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val maxClicks = 1600f
                        val barWidth = size.width / (marketClicks.size * 2)
                        val maxBarHeight = size.height - 40.dp.toPx()

                        // Draw Grid Lines
                        for (i in 1..3) {
                            val y = maxBarHeight * (1 - i / 3f)
                            drawLine(
                                color = Color.Gray.copy(alpha = 0.2f),
                                start = androidx.compose.ui.geometry.Offset(0f, y),
                                end = androidx.compose.ui.geometry.Offset(size.width, y),
                                strokeWidth = 1.dp.toPx()
                            )
                        }

                        // Draw Bars
                        marketClicks.forEachIndexed { index, data ->
                            val x = (index * 2 + 0.5f) * barWidth
                            val barHeight = (data.clicks / maxClicks) * maxBarHeight
                            val topY = maxBarHeight - barHeight

                            drawRoundRect(
                                color = data.color,
                                topLeft = androidx.compose.ui.geometry.Offset(x, topY),
                                size = androidx.compose.ui.geometry.Size(barWidth, barHeight),
                                cornerRadius = androidx.compose.ui.geometry.CornerRadius(6.dp.toPx(), 6.dp.toPx())
                            )
                        }
                    }

                    // Bar Labels and Counts Overlay
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(bottom = 0.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        marketClicks.forEach { data ->
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Bottom,
                                modifier = Modifier.weight(1f)
                            ) {
                                GlassBadge(
                                    text = "${data.clicks}",
                                    containerColor = data.color.copy(alpha = 0.2f),
                                    contentColor = data.color
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = data.channel,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                            }
                        }
                    }
                }
            }
        }

        // D3-Style Chart 2: Bookings & Revenue Trend Line Graph
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "MONTHLY BOOKING & REVENUE TREND", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                        Text(text = "Growth trajectory over 7 months (Tamil Nadu)", fontSize = 10.sp, color = Color.Gray)
                    }
                    GlassBadge(text = "+24% GROWTH", containerColor = Color(0xFF10B981).copy(alpha = 0.15f), contentColor = Color(0xFF10B981))
                }

                Spacer(modifier = Modifier.height(16.dp))

                val monthlyPoints = listOf(
                    "Jan" to 42f,
                    "Feb" to 65f,
                    "Mar" to 98f,
                    "Apr" to 110f,
                    "May" to 145f,
                    "Jun" to 162f,
                    "Jul" to 184f
                )

                // D3 Bézier Line Chart Canvas
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp)
                ) {
                    val lineColor = PinkPrimary
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val maxVal = 200f
                        val graphHeight = size.height - 30.dp.toPx()
                        val stepX = size.width / (monthlyPoints.size - 1)

                        val path = Path()
                        val fillPath = Path()

                        monthlyPoints.forEachIndexed { index, pair ->
                            val x = index * stepX
                            val y = graphHeight - (pair.second / maxVal) * graphHeight

                            if (index == 0) {
                                path.moveTo(x, y)
                                fillPath.moveTo(x, graphHeight)
                                fillPath.lineTo(x, y)
                            } else {
                                val prevX = (index - 1) * stepX
                                val prevY = graphHeight - (monthlyPoints[index - 1].second / maxVal) * graphHeight
                                val controlX1 = prevX + stepX / 2
                                val controlX2 = x - stepX / 2

                                path.cubicTo(controlX1, prevY, controlX2, y, x, y)
                                fillPath.cubicTo(controlX1, prevY, controlX2, y, x, y)
                            }

                            if (index == monthlyPoints.size - 1) {
                                fillPath.lineTo(x, graphHeight)
                                fillPath.close()
                            }
                        }

                        // Draw Gradient Area under Curve
                        drawPath(
                            path = fillPath,
                            brush = Brush.verticalGradient(
                                colors = listOf(lineColor.copy(alpha = 0.35f), Color.Transparent)
                            )
                        )

                        // Draw Curve Line
                        drawPath(
                            path = path,
                            color = lineColor,
                            style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                        )

                        // Draw Data Point Circles
                        monthlyPoints.forEachIndexed { index, pair ->
                            val x = index * stepX
                            val y = graphHeight - (pair.second / maxVal) * graphHeight
                            drawCircle(color = Color.White, radius = 5.dp.toPx(), center = androidx.compose.ui.geometry.Offset(x, y))
                            drawCircle(color = lineColor, radius = 3.5.dp.toPx(), center = androidx.compose.ui.geometry.Offset(x, y))
                        }
                    }

                    // Month Labels Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        monthlyPoints.forEach { (month, count) ->
                            Text(
                                text = month,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                            )
                        }
                    }
                }
            }
        }

        // Recent Real-time Clicks Activity Feed
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "LIVE MARKETPLACE CLICK STREAM", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                    Icon(imageVector = Icons.Default.Mouse, contentDescription = null, tint = PinkPrimary, modifier = Modifier.size(16.dp))
                }

                Spacer(modifier = Modifier.height(10.dp))

                val liveClicks = listOf(
                    LiveClickLog("Madurai User", "Meesho Silk Saree (₹1,299)", "₹129 Comm.", "5m ago", Color(0xFFE91E63)),
                    LiveClickLog("Salem User", "Flipkart Smartphone (₹14,999)", "₹450 Comm.", "12m ago", Color(0xFF2874F0)),
                    LiveClickLog("Coimbatore", "Grand Wedding Hall (₹45,000)", "Booked", "28m ago", PinkPrimary),
                    LiveClickLog("Tirunelveli", "Amazon Agri Sprayer (₹8,500)", "₹250 Comm.", "1h ago", Color(0xFFFF9900))
                )

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    liveClicks.forEach { log ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.5f))
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(log.color)
                                )
                                Column {
                                    Text(text = log.item, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                                    Text(text = "${log.location} • ${log.timeAgo}", fontSize = 9.5.sp, color = Color.Gray)
                                }
                            }

                            GlassBadge(
                                text = log.status,
                                containerColor = log.color.copy(alpha = 0.15f),
                                contentColor = log.color
                            )
                        }
                    }
                }
            }
        }

        // Action Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = { onShowToast("Exporting Analytics PDF Report...") },
                colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(imageVector = Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "PDF Report", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = { onShowToast("Exported Clicks Log CSV!") },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(imageVector = Icons.Default.BarChart, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "CSV Export", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

private data class MarketClickData(val channel: String, val clicks: Int, val color: Color)
private data class LiveClickLog(val location: String, val item: String, val status: String, val timeAgo: String, val color: Color)

@Composable
fun AdminReferralSettingsSection(
    settings: AdminReferralSettings,
    onSave: (AdminReferralSettings) -> Unit,
    onShowToast: (String) -> Unit
) {
    val context = LocalContext.current

    var meeshoLink by remember(settings) { mutableStateOf(settings.meeshoReferralLink) }
    var flipkartLink by remember(settings) { mutableStateOf(settings.flipkartAffiliateLink) }
    var amazonLink by remember(settings) { mutableStateOf(settings.amazonAffiliateLink) }
    var whatsAppNo by remember(settings) { mutableStateOf(settings.whatsAppNumber) }
    var telegramLink by remember(settings) { mutableStateOf(settings.telegramLink) }
    var instagramLink by remember(settings) { mutableStateOf(settings.instagramLink) }
    var facebookLink by remember(settings) { mutableStateOf(settings.facebookLink) }
    var youtubeLink by remember(settings) { mutableStateOf(settings.youTubeLink) }
    var websiteUrl by remember(settings) { mutableStateOf(settings.websiteUrl) }

    fun validateAndSave() {
        // Validate URLs
        val urlsToTest = listOf(
            "Meesho" to meeshoLink,
            "Flipkart" to flipkartLink,
            "Amazon" to amazonLink,
            "Telegram" to telegramLink,
            "Instagram" to instagramLink,
            "Facebook" to facebookLink,
            "YouTube" to youtubeLink,
            "Website" to websiteUrl
        )

        for ((name, url) in urlsToTest) {
            if (url.isNotBlank() && !url.startsWith("http://") && !url.startsWith("https://")) {
                onShowToast("Invalid $name URL: Must start with http:// or https://")
                return
            }
        }

        val updated = AdminReferralSettings(
            meeshoReferralLink = meeshoLink.trim(),
            flipkartAffiliateLink = flipkartLink.trim(),
            amazonAffiliateLink = amazonLink.trim(),
            whatsAppNumber = whatsAppNo.trim(),
            telegramLink = telegramLink.trim(),
            instagramLink = instagramLink.trim(),
            facebookLink = facebookLink.trim(),
            youTubeLink = youtubeLink.trim(),
            websiteUrl = websiteUrl.trim()
        )

        onSave(updated)
    }

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Referral & Affiliate Link Configuration",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "Configure links for Meesho, Flipkart, Amazon & Social Media",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }
                Icon(imageVector = Icons.Default.Link, contentDescription = null, tint = PinkPrimary)
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Marketplace Referral Links
            Text(text = "MARKETPLACE REFERRAL & AFFILIATE LINKS", fontSize = 11.sp, fontWeight = FontWeight.Black, color = PinkPrimary)
            Spacer(modifier = Modifier.height(8.dp))

            ReferralInputField(
                label = "Meesho Referral Link",
                value = meeshoLink,
                onValueChange = { meeshoLink = it },
                onTestLink = { openTestUrl(context, meeshoLink, onShowToast) }
            )

            Spacer(modifier = Modifier.height(8.dp))

            ReferralInputField(
                label = "Flipkart Affiliate Link",
                value = flipkartLink,
                onValueChange = { flipkartLink = it },
                onTestLink = { openTestUrl(context, flipkartLink, onShowToast) }
            )

            Spacer(modifier = Modifier.height(8.dp))

            ReferralInputField(
                label = "Amazon Affiliate Link",
                value = amazonLink,
                onValueChange = { amazonLink = it },
                onTestLink = { openTestUrl(context, amazonLink, onShowToast) }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Social Media & Support Channels
            Text(text = "SOCIAL MEDIA & SUPPORT CHANNELS", fontSize = 11.sp, fontWeight = FontWeight.Black, color = PinkPrimary)
            Spacer(modifier = Modifier.height(8.dp))

            ReferralInputField(
                label = "WhatsApp Contact Number",
                value = whatsAppNo,
                onValueChange = { whatsAppNo = it },
                onTestLink = {
                    val num = whatsAppNo.replace(" ", "").replace("+", "")
                    openTestUrl(context, "https://wa.me/$num", onShowToast)
                }
            )

            Spacer(modifier = Modifier.height(8.dp))

            ReferralInputField(
                label = "Telegram Link / Channel",
                value = telegramLink,
                onValueChange = { telegramLink = it },
                onTestLink = { openTestUrl(context, telegramLink, onShowToast) }
            )

            Spacer(modifier = Modifier.height(8.dp))

            ReferralInputField(
                label = "Instagram Handle / Page",
                value = instagramLink,
                onValueChange = { instagramLink = it },
                onTestLink = { openTestUrl(context, instagramLink, onShowToast) }
            )

            Spacer(modifier = Modifier.height(8.dp))

            ReferralInputField(
                label = "Facebook Page Link",
                value = facebookLink,
                onValueChange = { facebookLink = it },
                onTestLink = { openTestUrl(context, facebookLink, onShowToast) }
            )

            Spacer(modifier = Modifier.height(8.dp))

            ReferralInputField(
                label = "YouTube Channel URL",
                value = youtubeLink,
                onValueChange = { youtubeLink = it },
                onTestLink = { openTestUrl(context, youtubeLink, onShowToast) }
            )

            Spacer(modifier = Modifier.height(8.dp))

            ReferralInputField(
                label = "Website URL",
                value = websiteUrl,
                onValueChange = { websiteUrl = it },
                onTestLink = { openTestUrl(context, websiteUrl, onShowToast) }
            )

            Spacer(modifier = Modifier.height(18.dp))

            Button(
                onClick = { validateAndSave() },
                colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "Save Referral & Affiliate Settings", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun ReferralInputField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    onTestLink: () -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, fontSize = 12.sp) },
        trailingIcon = {
            IconButton(onClick = onTestLink) {
                Icon(
                    imageVector = Icons.Default.OpenInNew,
                    contentDescription = "Test Link",
                    tint = PinkPrimary,
                    modifier = Modifier.size(18.dp)
                )
            }
        },
        singleLine = true,
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = PinkPrimary,
            unfocusedBorderColor = MaterialTheme.colorScheme.outline
        ),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun AdminProductManagementSection(
    marketProducts: List<MarketProduct>,
    onAddProduct: (MarketProduct) -> Unit,
    onUpdateProduct: (MarketProduct) -> Unit,
    onDeleteProduct: (String) -> Unit,
    onToggleEnabled: (String) -> Unit,
    onToggleFeatured: (String) -> Unit,
    onShowToast: (String) -> Unit
) {
    var showAddModal by remember { mutableStateOf(false) }
    var productToEdit by remember { mutableStateOf<MarketProduct?>(null) }

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Marketplace Product Management",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "Manage ${marketProducts.size} products, assign categories & featured items",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }

                Button(
                    onClick = { showAddModal = true },
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Add Product", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                marketProducts.forEach { product ->
                    ProductManagementCard(
                        product = product,
                        onEdit = { productToEdit = product },
                        onDelete = { onDeleteProduct(product.id) },
                        onToggleEnabled = { onToggleEnabled(product.id) },
                        onToggleFeatured = { onToggleFeatured(product.id) }
                    )
                }
            }
        }
    }

    if (showAddModal) {
        AddEditProductDialog(
            initialProduct = null,
            onDismiss = { showAddModal = false },
            onSave = {
                onAddProduct(it)
                showAddModal = false
            },
            onShowToast = onShowToast
        )
    }

    if (productToEdit != null) {
        AddEditProductDialog(
            initialProduct = productToEdit,
            onDismiss = { productToEdit = null },
            onSave = {
                onUpdateProduct(it)
                productToEdit = null
            },
            onShowToast = onShowToast
        )
    }
}

@Composable
fun ProductManagementCard(
    product: MarketProduct,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onToggleEnabled: () -> Unit,
    onToggleFeatured: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AsyncImage(
                model = product.imageUrl,
                contentDescription = product.titleEn,
                modifier = Modifier
                    .size(60.dp)
                    .clip(RoundedCornerShape(10.dp)),
                contentScale = ContentScale.Crop
            )

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Marketplace Badge
                    val bg = when (product.marketplace.lowercase()) {
                        "meesho" -> Color(0xFFE91E63)
                        "flipkart" -> Color(0xFF2874F0)
                        "amazon" -> Color(0xFFFF9900)
                        else -> PinkPrimary
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(bg)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(text = product.marketplace, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    if (product.isFeatured) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(GoldPrimary.copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(text = "★ FEATURED", fontSize = 9.sp, fontWeight = FontWeight.Black, color = GoldPrimary)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = product.titleEn,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    maxLines = 1
                )

                Text(
                    text = "₹${product.price.toInt()} | ${product.category}",
                    fontSize = 11.sp,
                    color = PinkPrimary,
                    fontWeight = FontWeight.Bold
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Featured Star Toggle
                IconButton(onClick = onToggleFeatured) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "Toggle Featured",
                        tint = if (product.isFeatured) GoldPrimary else Color.LightGray,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Enable/Disable Switch
                Switch(
                    checked = product.isEnabled,
                    onCheckedChange = { onToggleEnabled() },
                    colors = SwitchDefaults.colors(checkedThumbColor = PinkPrimary, checkedTrackColor = PinkPrimary.copy(alpha = 0.3f)),
                    modifier = Modifier.size(24.dp)
                )

                Spacer(modifier = Modifier.width(8.dp))

                // Edit Button
                IconButton(onClick = onEdit) {
                    Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit", tint = PinkPrimary, modifier = Modifier.size(18.dp))
                }

                // Delete Button
                IconButton(onClick = onDelete) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red.copy(alpha = 0.7f), modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

@Composable
fun AddEditProductDialog(
    initialProduct: MarketProduct?,
    onDismiss: () -> Unit,
    onSave: (MarketProduct) -> Unit,
    onShowToast: (String) -> Unit
) {
    val isEdit = initialProduct != null

    var titleEn by remember { mutableStateOf(initialProduct?.titleEn ?: "") }
    var titleTa by remember { mutableStateOf(initialProduct?.titleTa ?: "") }
    var price by remember { mutableStateOf(initialProduct?.price?.toInt()?.toString() ?: "") }
    var origPrice by remember { mutableStateOf(initialProduct?.originalPrice?.toInt()?.toString() ?: "") }
    var category by remember { mutableStateOf(initialProduct?.category ?: "Bridal Wear") }
    var marketplace by remember { mutableStateOf(initialProduct?.marketplace ?: "Meesho") }
    var imageUrl by remember { mutableStateOf(initialProduct?.imageUrl ?: "https://images.unsplash.com/photo-1606293926075-69a00dbfde81?auto=format&fit=crop&w=800&q=80") }
    var productUrl by remember { mutableStateOf(initialProduct?.productUrl ?: "") }
    var description by remember { mutableStateOf(initialProduct?.description ?: "") }
    var isEnabled by remember { mutableStateOf(initialProduct?.isEnabled ?: true) }
    var isFeatured by remember { mutableStateOf(initialProduct?.isFeatured ?: false) }

    val categories = listOf("Bridal Wear", "Return Gifts & Pooja", "Wedding Garlands", "Pooja & Decor", "Gift Box", "Artisanal Crafts")
    val marketplaces = listOf("Meesho", "Flipkart", "Amazon")

    fun submit() {
        if (titleEn.isBlank() || price.isBlank()) {
            onShowToast("Title and Price are required!")
            return
        }

        if (productUrl.isNotBlank() && !productUrl.startsWith("http://") && !productUrl.startsWith("https://")) {
            onShowToast("Product URL must start with http:// or https://")
            return
        }

        val pDouble = price.toDoubleOrNull() ?: 0.0
        val origDouble = origPrice.toDoubleOrNull() ?: (pDouble * 1.2)
        val discPercent = if (origDouble > pDouble) (((origDouble - pDouble) / origDouble) * 100).toInt() else 15

        val product = MarketProduct(
            id = initialProduct?.id ?: ("prod_" + System.currentTimeMillis()),
            titleEn = titleEn.trim(),
            titleTa = titleTa.ifBlank { titleEn }.trim(),
            price = pDouble,
            originalPrice = origDouble,
            rating = initialProduct?.rating ?: 4.8,
            reviewCount = initialProduct?.reviewCount ?: 25,
            village = initialProduct?.village ?: "Dharmapuri Town",
            vendorName = initialProduct?.vendorName ?: "Verified Partner Vendor",
            category = category,
            imageUrl = imageUrl.trim(),
            description = description.ifBlank { "Authentic $category available for direct village delivery or online ordering." }.trim(),
            stock = 50,
            marketplace = marketplace,
            isEnabled = isEnabled,
            isFeatured = isFeatured,
            productUrl = productUrl.trim(),
            discountPercent = discPercent
        )

        onSave(product)
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(18.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isEdit) "Edit Marketplace Product" else "Add Marketplace Product",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                HorizontalDivider()

                // Marketplace Selector
                Text(text = "SELECT MARKETPLACE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = PinkPrimary)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    marketplaces.forEach { m ->
                        val sel = m == marketplace
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (sel) PinkPrimary else MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { marketplace = m }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(text = m, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (sel) Color.White else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                // Category Selector
                Text(text = "ASSIGN CATEGORY", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = PinkPrimary)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.take(3).forEach { cat ->
                        val sel = cat == category
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (sel) GoldPrimary else MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { category = cat }
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                        ) {
                            Text(text = cat, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (sel) Color.White else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                OutlinedTextField(
                    value = titleEn,
                    onValueChange = { titleEn = it },
                    label = { Text("Product Title (English)") },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = titleTa,
                    onValueChange = { titleTa = it },
                    label = { Text("Product Title (Tamil)") },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = price,
                        onValueChange = { price = it },
                        label = { Text("Offer Price (₹)") },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = origPrice,
                        onValueChange = { origPrice = it },
                        label = { Text("Original Price (₹)") },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = productUrl,
                    onValueChange = { productUrl = it },
                    label = { Text("Product Marketplace URL") },
                    placeholder = { Text("https://meesho.com/...") },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = imageUrl,
                    onValueChange = { imageUrl = it },
                    label = { Text("Product Image URL") },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Short Description") },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(checked = isEnabled, onCheckedChange = { isEnabled = it })
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = if (isEnabled) "Enabled" else "Disabled", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(checked = isFeatured, onCheckedChange = { isFeatured = it })
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "Featured", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GoldPrimary)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = { submit() },
                    colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(text = if (isEdit) "Save Changes" else "Add Product", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun AdminInfoServicesSection(onShowToast: (String) -> Unit) {
    var infoCategory by remember { mutableStateOf("Emergency & Helplines") }
    var serviceTitle by remember { mutableStateOf("") }
    var contactNumber by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var villageName by remember { mutableStateOf("Dharmapuri Town") }

    val infoCategories = listOf(
        "Emergency & Helplines",
        "Marriage Halls Directory",
        "Bus Routes & Schedules",
        "Government Welfare Schemes",
        "Local Artisan Directory",
        "Health & Agriculture"
    )

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "➕ ADD INFORMATION SERVICE",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Black,
                            color = PinkPrimary
                        )
                        Text(
                            text = "Admin Option: Publish local directory & civic information",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(PinkPrimary.copy(alpha = 0.15f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("ALL ACCESS", fontSize = 9.sp, fontWeight = FontWeight.Black, color = PinkPrimary)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text("SELECT INFORMATION CATEGORY", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = PinkPrimary)
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    infoCategories.take(3).forEach { cat ->
                        val isSel = cat == infoCategory
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSel) PinkPrimary else MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { infoCategory = cat }
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = cat,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSel) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = serviceTitle,
                    onValueChange = { serviceTitle = it },
                    label = { Text("Service Title (e.g. Village Ambulance / Marriage Hall Info)") },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = contactNumber,
                        onValueChange = { contactNumber = it },
                        label = { Text("Helpline / Contact Number") },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = villageName,
                        onValueChange = { villageName = it },
                        label = { Text("Village / District") },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Details & Description") },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = {
                        if (serviceTitle.isBlank()) {
                            onShowToast("Please enter a service title!")
                        } else {
                            onShowToast("Published Info Service: '$serviceTitle' in $villageName!")
                            serviceTitle = ""
                            contactNumber = ""
                            description = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("PUBLISH INFORMATION SERVICE", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun AdminAllAccessSection(onShowToast: (String) -> Unit) {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(imageVector = Icons.Default.AdminPanelSettings, contentDescription = null, tint = PinkPrimary)
                Text(text = "ADMIN ALL-ACCESS CONTROLS", fontWeight = FontWeight.Black, fontSize = 15.sp)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Full system privileges granted: Override pricing, manage vendors, create information services, and review user activity logs.",
                fontSize = 11.5.sp,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
            )

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = { onShowToast("System Audit Log generated for All-Access Admin!") },
                colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("RUN FULL SYSTEM AUDIT", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun VendorView(currentVillage: String, onShowToast: (String) -> Unit) {
    var selectedTab by remember { mutableStateOf(0) } // 0: Vendor Access, 1: User Access
    var title by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Dual Mode Switch: Vendor Access + User Access
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(PinkPrimary.copy(alpha = 0.1f))
                .padding(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (selectedTab == 0) PinkPrimary else Color.Transparent)
                    .clickable { selectedTab = 0 }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "🏪 VENDOR ACCESS",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = if (selectedTab == 0) Color.White else MaterialTheme.colorScheme.onBackground
                )
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (selectedTab == 1) PinkPrimary else Color.Transparent)
                    .clickable { selectedTab = 1 }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "👤 USER ACCESS",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = if (selectedTab == 1) Color.White else MaterialTheme.colorScheme.onBackground
                )
            }
        }

        if (selectedTab == 0) {
            // VENDOR PORTAL ACCESS
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "ADD NEW SERVICE / PRODUCT", fontWeight = FontWeight.Black, fontSize = 14.sp)
                    Text(text = "Vendor Listing in $currentVillage village", fontSize = 11.sp, color = Color.Gray)

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        placeholder = { Text("Service Title (e.g., Temple Stage Decor)") },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = price,
                        onValueChange = { price = it },
                        placeholder = { Text("Price per Day (₹)") },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            if (title.isBlank()) {
                                onShowToast("Please enter a service title!")
                            } else {
                                onShowToast("Published '$title' in $currentVillage village!")
                                title = ""
                                price = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(text = "PUBLISH VENDOR LISTING", fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            // USER ACCESS (VENDOR AS CUSTOMER)
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "USER ACCESS MODE (CUSTOMER VIEW)", fontWeight = FontWeight.Black, fontSize = 14.sp)
                    Text(text = "Browse events, book local marriage halls & buy marketplace products.", fontSize = 11.sp, color = Color.Gray)

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = { onShowToast("Switched to Customer Event & Marketplace Browsing!") },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(text = "EXPLORE USER MARKETPLACE & EVENTS", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun AgentView(currentVillage: String, onShowToast: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.PersonAdd, contentDescription = null, tint = PinkPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "Village Agent Onboarding", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(text = "Verify marriage halls, catering vendors, and artisans in $currentVillage.", fontSize = 12.sp, color = Color.Gray)

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = { onShowToast("Field Inspection verified for 3 new vendors in $currentVillage!") },
                    colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(text = "Submit Field Verification")
                }
            }
        }
    }
}

@Composable
fun UserWorkspaceView(onShowToast: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "CUSTOMER PORTAL (USER ONLY)", fontWeight = FontWeight.Black, fontSize = 15.sp)
                        Text(text = "Standard Customer privileges: Book events & shop marketplace", fontSize = 11.sp, color = Color.Gray)
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF2563EB).copy(alpha = 0.15f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("USER ACCESS", fontSize = 9.sp, fontWeight = FontWeight.Black, color = Color(0xFF2563EB))
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = { onShowToast("Customer Saved Invoices & Bookings Loaded!") },
                    colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(text = "VIEW MY BOOKING INVOICES", fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = { onShowToast("Marketplace Orders History Loaded!") },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(text = "VIEW MARKETPLACE ORDERS", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

fun openTestUrl(context: Context, url: String, onShowToast: (String) -> Unit) {
    if (url.isBlank()) {
        onShowToast("URL is empty!")
        return
    }
    try {
        val targetUrl = if (!url.startsWith("http://") && !url.startsWith("https://")) "https://$url" else url
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl))
        context.startActivity(intent)
    } catch (e: Exception) {
        onShowToast("Failed to open link: ${e.localizedMessage}")
    }
}
