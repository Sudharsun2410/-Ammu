package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Language
import com.example.ui.theme.PinkPrimary

@Composable
fun OpenSourceVenueMap(
    venueTitle: String,
    villageLocation: String,
    districtLocation: String,
    currentLanguage: Language,
    mapUrl: String = "",
    onShowToast: (String) -> Unit = {}
) {
    val context = LocalContext.current
    var zoomLevel by remember { mutableFloatStateOf(14.5f) } // Default 14.5x HD Zoom
    var isSatelliteLayer by remember { mutableStateOf(false) }

    fun openGoogleMaps() {
        val targetUrl = if (mapUrl.isNotBlank()) {
            mapUrl
        } else {
            "https://www.google.com/maps/search/?api=1&query=${Uri.encode("$venueTitle $villageLocation $districtLocation")}"
        }
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl))
            context.startActivity(intent)
            onShowToast("Opening Google Maps: $venueTitle")
        } catch (e: Exception) {
            onShowToast("Opening Map Link...")
        }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            // Header Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF10B981).copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = "Map Pin",
                            tint = Color(0xFF059669),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = if (currentLanguage == Language.TAMIL) "இடம் & வரைபடம் (OpenStreetMap)" else "Venue Location (OpenStreetMap HD)",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "$venueTitle • $villageLocation, $districtLocation",
                            fontSize = 9.5.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Zoom Level Tag
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(PinkPrimary.copy(alpha = 0.12f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "Zoom: ${"%.1f".format(zoomLevel)}x HD",
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = PinkPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // OpenSource Tile Canvas View
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.5.dp, Color(0xFFCBD5E1), RoundedCornerShape(16.dp))
                    .background(if (isSatelliteLayer) Color(0xFF1E293B) else Color(0xFFF1F5F9))
                    .pointerInput(Unit) {
                        detectTransformGestures { _, _, zoom, _ ->
                            zoomLevel = (zoomLevel * zoom).coerceIn(10f, 20f)
                        }
                    }
            ) {
                // Vector Map Grid Rendering
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val width = size.width
                    val height = size.height
                    val tileSize = 40.dp.toPx() * (zoomLevel / 12f)

                    // Draw OpenStreetMap Grid Lines
                    val gridColor = if (isSatelliteLayer) Color(0xFF334155) else Color(0xFFE2E8F0)
                    var x = 0f
                    while (x < width) {
                        drawLine(gridColor, start = Offset(x, 0f), end = Offset(x, height), strokeWidth = 1f)
                        x += tileSize
                    }
                    var y = 0f
                    while (y < height) {
                        drawLine(gridColor, start = Offset(0f, y), end = Offset(width, y), strokeWidth = 1f)
                        y += tileSize
                    }

                    // Main Highways / Roads
                    val roadColor = if (isSatelliteLayer) Color(0xFF475569) else Color(0xFFFFFFFF)
                    val roadOutline = Color(0xFFCBD5E1)
                    val roadPath = Path().apply {
                        moveTo(0f, height * 0.45f)
                        quadraticTo(width * 0.5f, height * 0.5f, width, height * 0.4f)
                        moveTo(width * 0.35f, 0f)
                        lineTo(width * 0.45f, height)
                    }
                    drawPath(roadPath, roadOutline, style = Stroke(width = 14f * (zoomLevel / 12f)))
                    drawPath(roadPath, roadColor, style = Stroke(width = 10f * (zoomLevel / 12f)))

                    // River / Waterway Curve
                    val waterColor = Color(0xFF38BDF8).copy(alpha = 0.6f)
                    val riverPath = Path().apply {
                        moveTo(0f, height * 0.8f)
                        cubicTo(width * 0.3f, height * 0.7f, width * 0.7f, height * 0.9f, width, height * 0.75f)
                    }
                    drawPath(riverPath, waterColor, style = Stroke(width = 18f * (zoomLevel / 12f)))
                }

                // Center Venue Location Marker Pin
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .clip(RoundedCornerShape(12.dp))
                        .background(PinkPrimary)
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = "Pin",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = venueTitle,
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }

                // Floating Map Controls (Zoom In +, Zoom Out -, Layer Toggle)
                Column(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(Color.White)
                            .border(1.dp, Color(0xFFCBD5E1), CircleShape)
                            .clickable { zoomLevel = (zoomLevel + 1f).coerceAtMost(20f) },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Zoom In", tint = Color.Black, modifier = Modifier.size(18.dp))
                    }

                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(Color.White)
                            .border(1.dp, Color(0xFFCBD5E1), CircleShape)
                            .clickable { zoomLevel = (zoomLevel - 1f).coerceAtLeast(10f) },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = Icons.Default.Remove, contentDescription = "Zoom Out", tint = Color.Black, modifier = Modifier.size(18.dp))
                    }

                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(if (isSatelliteLayer) PinkPrimary else Color.White)
                            .border(1.dp, Color(0xFFCBD5E1), CircleShape)
                            .clickable {
                                isSatelliteLayer = !isSatelliteLayer
                                onShowToast(if (isSatelliteLayer) "Satellite View Enabled" else "OpenStreetMap Standard HD")
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Map,
                            contentDescription = "Map Layer",
                            tint = if (isSatelliteLayer) Color.White else Color.Black,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                // Bottom OpenSource Tag & Directions Button
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(8.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.White.copy(alpha = 0.9f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "🌐 OpenStreetMap • HD Vector Tile",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF475569)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Open Directions & My Location Action Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(PinkPrimary.copy(alpha = 0.1f))
                        .clickable { openGoogleMaps() }
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.Directions, contentDescription = "Directions", tint = PinkPrimary, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (currentLanguage == Language.TAMIL) "📍கூகுள் மேப் வழித்தடம்" else "📍 Open Google Maps",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = PinkPrimary
                    )
                }

                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFFF1F5F9))
                        .clickable {
                            zoomLevel = 16f
                            onShowToast("Centered on $venueTitle Location")
                        }
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.MyLocation, contentDescription = "Recenter", tint = Color(0xFF475569), modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (currentLanguage == Language.TAMIL) "மறுசீரமைக்கவும்" else "Recenter",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF475569)
                    )
                }
            }
        }
    }
}
