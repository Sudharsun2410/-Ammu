package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.random.Random

@Composable
fun QrCodeCanvas(
    qrText: String,
    modifier: Modifier = Modifier,
    sizeDp: Dp = 120.dp,
    qrColor: Color = Color(0xFF1E293B),
    backgroundColor: Color = Color.White
) {
    Box(
        modifier = modifier
            .size(sizeDp)
            .background(backgroundColor)
    ) {
        Canvas(modifier = Modifier.size(sizeDp)) {
            val gridCount = 21
            val cellSize = size.width / gridCount
            
            // Draw background
            drawRect(color = backgroundColor, size = size)

            // Seed based on qrText for consistent pattern
            val seed = qrText.hashCode().toLong()
            val random = Random(seed)

            for (row in 0 until gridCount) {
                for (col in 0 until gridCount) {
                    val isCornerFinder = 
                        (row < 7 && col < 7) || 
                        (row < 7 && col >= gridCount - 7) || 
                        (row >= gridCount - 7 && col < 7)

                    if (isCornerFinder) {
                        // Draw corner finder blocks
                        val inOuterBorder = (row == 0 || row == 6 || col == 0 || col == 6) && (row in 0..6 && col in 0..6)
                        val inTopRightBorder = (row == 0 || row == 6 || col == gridCount - 7 || col == gridCount - 1) && (row in 0..6 && col >= gridCount - 7)
                        val inBottomLeftBorder = (row == gridCount - 7 || row == gridCount - 1 || col == 0 || col == 6) && (row >= gridCount - 7 && col in 0..6)
                        val inCenter = (row in 2..4 && col in 2..4) || (row in 2..4 && col in gridCount - 5..gridCount - 3) || (row in gridCount - 5..gridCount - 3 && col in 2..4)

                        if (inOuterBorder || inTopRightBorder || inBottomLeftBorder || inCenter) {
                            drawRect(
                                color = qrColor,
                                topLeft = Offset(col * cellSize, row * cellSize),
                                size = Size(cellSize, cellSize)
                            )
                        }
                    } else {
                        // Data bits
                        if (random.nextBoolean()) {
                            drawRect(
                                color = qrColor,
                                topLeft = Offset(col * cellSize, row * cellSize),
                                size = Size(cellSize * 0.9f, cellSize * 0.9f)
                            )
                        }
                    }
                }
            }
        }
    }
}
