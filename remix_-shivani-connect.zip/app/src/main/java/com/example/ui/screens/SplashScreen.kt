package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.Language
import com.example.ui.components.GlassBadge
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.PinkDark
import com.example.ui.theme.PinkPrimary
import com.example.ui.theme.PurplePrimary
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
    currentLanguage: Language = Language.ENGLISH,
    isSignedIn: Boolean = false,
    onSplashFinished: (navigateToAuth: Boolean) -> Unit
) {
    // Entrance Animatable values
    val logoScale = remember { Animatable(0.65f) }
    val logoAlpha = remember { Animatable(0f) }

    // Pulsing/Blinking Infinite Transition for soft glow & breathing effect
    val infiniteTransition = rememberInfiniteTransition(label = "SplashGlowAnimation")
    val glowPulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "GlowAlpha"
    )

    val breathingScale by infiniteTransition.animateFloat(
        initialValue = 0.98f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "BreathingScale"
    )

    // Trigger Splash sequence (1.8 seconds)
    LaunchedEffect(Unit) {
        // Step 1: Smooth Fade-In and Zoom-In
        logoAlpha.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 600, easing = FastOutSlowInEasing)
        )
        logoScale.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 700, easing = FastOutSlowInEasing)
        )

        // Step 2: Hold for total 1.8 seconds
        delay(1100)

        // Step 3: Complete animation and navigate
        onSplashFinished(!isSignedIn)
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White) // Clean white background as requested
    ) {
        val maxContainerWidth = if (maxWidth > 600.dp) 540.dp else maxWidth

        // Top-Right & Bottom-Left Decorative Ambient Pink-Purple Gradient Accents
        Box(
            modifier = Modifier
                .size(320.dp)
                .align(Alignment.TopEnd)
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            PinkPrimary.copy(alpha = 0.18f),
                            PurplePrimary.copy(alpha = 0.08f),
                            Color.Transparent
                        )
                    )
                )
        )

        Box(
            modifier = Modifier
                .size(360.dp)
                .align(Alignment.BottomStart)
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            PurplePrimary.copy(alpha = 0.18f),
                            PinkDark.copy(alpha = 0.08f),
                            Color.Transparent
                        )
                    )
                )
        )

        // Main Center Content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = maxContainerWidth)
                .align(Alignment.Center)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Soft Glow Aura Container around the Logo
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .scale(logoScale.value * breathingScale)
                    .alpha(logoAlpha.value)
            ) {
                // Soft Glow Aura Radial Circle
                Box(
                    modifier = Modifier
                        .size(190.dp)
                        .clip(CircleShape)
                        .background(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    PinkPrimary.copy(alpha = glowPulseAlpha * 0.45f),
                                    PurplePrimary.copy(alpha = glowPulseAlpha * 0.25f),
                                    Color.Transparent
                                )
                            )
                        )
                )

                // Glassmorphic Outer Ring with Pink & Purple Gradient
                Box(
                    modifier = Modifier
                        .size(136.dp)
                        .clip(CircleShape)
                        .background(
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    PinkPrimary.copy(alpha = 0.12f),
                                    PurplePrimary.copy(alpha = 0.12f)
                                )
                            )
                        )
                        .border(
                            width = 2.5.dp,
                            brush = Brush.linearGradient(
                                colors = listOf(PinkPrimary, PurplePrimary, GoldPrimary)
                            ),
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    // Logo Image in Center
                    Image(
                        painter = painterResource(id = R.drawable.sk_shivani_skhub_logo_1785082786285),
                        contentDescription = "SK Shivani Connect Logo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(120.dp)
                            .clip(CircleShape)
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // App Brand Name & Subtitle
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .alpha(logoAlpha.value)
                    .scale(logoScale.value)
            ) {
                Text(
                    text = "SK SHIVANI HUB",
                    fontWeight = FontWeight.Black,
                    fontSize = 26.sp,
                    letterSpacing = 1.5.sp,
                    color = Color(0xFF1E1B4B), // Deep navy dark for premium contrast on white
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .height(1.dp)
                            .size(30.dp, 1.dp)
                            .background(PinkPrimary)
                    )

                    Text(
                        text = if (currentLanguage == Language.TAMIL) "இணைப்பு • சேவை • வளர்ச்சி" else "CONNECT • SERVE • GROW",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = PinkPrimary,
                        letterSpacing = 2.sp,
                        textAlign = TextAlign.Center
                    )

                    Box(
                        modifier = Modifier
                            .height(1.dp)
                            .size(30.dp, 1.dp)
                            .background(PinkPrimary)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                GlassBadge(
                    text = if (currentLanguage == Language.TAMIL) "தமிழ்நாடு கிராம சேவை தளம்" else "TAMIL NADU VILLAGE DIGITAL HUB",
                    containerColor = PinkPrimary.copy(alpha = 0.08f),
                    contentColor = PinkDark
                )
            }
        }

        // Bottom Footer Branding
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 36.dp)
                .alpha(logoAlpha.value),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "POWERED BY SHIVANI ORBIT",
                fontSize = 9.5.sp,
                fontWeight = FontWeight.Black,
                color = Color.Gray,
                letterSpacing = 1.5.sp
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "Madurai • Salem • Coimbatore • Chennai",
                fontSize = 9.sp,
                color = Color.Gray.copy(alpha = 0.7f)
            )
        }
    }
}
