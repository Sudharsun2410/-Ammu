package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Language
import com.example.ui.components.GlassCard
import com.example.ui.components.StarRating
import com.example.ui.theme.PinkPrimary

@Composable
fun ChatScreen(
    currentLanguage: Language,
    onShowToast: (String) -> Unit
) {
    var messages by remember {
        mutableStateOf(
            listOf(
                "Vanakkam! Thank you for inquiring about Sri Lakshmi Marriage Palace.",
                "Is the A/C hall available on August 25th for reception?",
                "Yes, August 25th is open! You can place advance booking directly on Shivani Connect."
            )
        )
    }
    var inputMsg by remember { mutableStateOf("") }
    var userRating by remember { mutableStateOf(5) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .padding(bottom = 80.dp)
    ) {
        // Chat Partner Header
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(PinkPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "🏰", fontSize = 20.sp)
                    }
                    Column {
                        Text(text = "Sri Lakshmi Palace Vendor", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(text = "Alanganallur • Online", fontSize = 11.sp, color = Color(0xFF16A34A), fontWeight = FontWeight.Bold)
                    }
                }

                IconButton(onClick = { onShowToast("Calling +91 98421 88990...") }) {
                    Icon(imageVector = Icons.Default.Call, contentDescription = "Call", tint = PinkPrimary)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Message History
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages) { msg ->
                val isMe = msg.contains("A/C hall")
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = if (isMe) Alignment.CenterEnd else Alignment.CenterStart
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (isMe) PinkPrimary else Color(0xFFE2E8F0))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = msg,
                            color = if (isMe) Color.White else Color(0xFF1E293B),
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Submit Vendor Review Section
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(10.dp)) {
                Text(text = "RATE THIS VENDOR", fontSize = 9.sp, fontWeight = FontWeight.Black, color = PinkPrimary)
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) {
                    StarRating(
                        rating = userRating.toDouble(),
                        starSize = 20.dp,
                        fontSize = 12.sp,
                        onRatingSelected = { userRating = it }
                    )
                    Text(
                        text = "Submit ($userRating ★)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = PinkPrimary,
                        modifier = Modifier
                            .clickable { onShowToast("Rating $userRating stars submitted successfully!") }
                            .padding(4.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Message Input
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = inputMsg,
                onValueChange = { inputMsg = it },
                placeholder = { Text("Type message to vendor...") },
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.weight(1f)
            )

            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(PinkPrimary)
                    .clickable {
                        if (inputMsg.isNotBlank()) {
                            messages = messages + inputMsg
                            inputMsg = ""
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = Icons.Default.Send, contentDescription = "Send", tint = Color.White)
            }
        }
    }
}
