package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBackIos
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EventBusy
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Language
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.PinkDark
import com.example.ui.theme.PinkPrimary
import java.util.Calendar
import java.util.Locale

@Composable
fun BookingCalendarView(
    bookedDates: List<String> = listOf("2026-08-05", "2026-08-12", "2026-08-18", "2026-08-25", "2026-09-08", "2026-09-15"),
    muhurthamDates: List<String> = listOf("2026-08-03", "2026-08-09", "2026-08-20", "2026-08-24", "2026-08-30", "2026-09-06", "2026-09-12"),
    selectedDate: String,
    selectedTimeSlot: String,
    guestCount: String,
    pricePerDay: Double = 35000.0,
    currentLanguage: Language = Language.ENGLISH,
    onDateSelected: (String) -> Unit,
    onSlotSelected: (String) -> Unit,
    onGuestCountChange: (String) -> Unit = {},
    onShowToast: (String) -> Unit = {}
) {
    // Current viewed Year and Month (0-indexed month)
    var viewedYear by remember { mutableIntStateOf(2026) }
    var viewedMonth by remember { mutableIntStateOf(7) } // 7 = August (Calendar.AUGUST)
    var activeFilter by remember { mutableStateOf("ALL") } // ALL, AVAILABLE, MUHURTHAM

    val monthNamesEn = listOf("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December")
    val monthNamesTa = listOf("ஜனவரி", "பிப்ரவரி", "மார்ச்", "ஏப்ரல்", "மே", "ஜூன்", "ஜூலை", "ஆகஸ்ட்", "செப்டம்பர்", "அக்டோபர்", "நவம்பர்", "டிசம்பர்")

    val dayHeadersEn = listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
    val dayHeadersTa = listOf("ஞாயி", "திங்", "செவ்", "புதன்", "வியா", "வெள்", "சனி")

    // Calculate calendar grid data
    val cal = Calendar.getInstance().apply {
        set(Calendar.YEAR, viewedYear)
        set(Calendar.MONTH, viewedMonth)
        set(Calendar.DAY_OF_MONTH, 1)
    }

    val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    val startDayOfWeek = cal.get(Calendar.DAY_OF_WEEK) - 1 // 0 for Sunday

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.9f))
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(20.dp))
            .padding(16.dp)
    ) {
        // Month Navigation Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(PinkPrimary.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CalendarMonth,
                        contentDescription = "Calendar",
                        tint = PinkPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Column {
                    val monthName = if (currentLanguage == Language.TAMIL) monthNamesTa[viewedMonth] else monthNamesEn[viewedMonth]
                    Text(
                        text = "$monthName $viewedYear",
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = if (currentLanguage == Language.TAMIL) "நேரடி பயன்பாட்டு நிலை & தேதிகள்" else "Live Availability & Booking Calendar",
                        fontSize = 10.5.sp,
                        color = PinkPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                IconButton(
                    onClick = {
                        if (viewedMonth == 0) {
                            viewedMonth = 11
                            viewedYear -= 1
                        } else {
                            viewedMonth -= 1
                        }
                    },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBackIos,
                        contentDescription = "Previous Month",
                        tint = PinkPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                }

                IconButton(
                    onClick = {
                        if (viewedMonth == 11) {
                            viewedMonth = 0
                            viewedYear += 1
                        } else {
                            viewedMonth += 1
                        }
                    },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                        contentDescription = "Next Month",
                        tint = PinkPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Legend & Filter Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val filters = listOf(
                "ALL" to if (currentLanguage == Language.TAMIL) "அனைத்தும்" else "All Dates",
                "AVAILABLE" to if (currentLanguage == Language.TAMIL) "கிடைப்பவை" else "Available Only",
                "MUHURTHAM" to if (currentLanguage == Language.TAMIL) "முஹூர்த்தம் ✨" else "Muhurtham ✨"
            )

            filters.forEach { (key, label) ->
                val isSelected = activeFilter == key
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) PinkPrimary else MaterialTheme.colorScheme.surface)
                        .border(1.dp, if (isSelected) PinkPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .clickable { activeFilter = key }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = label,
                        fontSize = 10.5.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onBackground
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Availability Color Legend Indicators
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.5f))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            LegendIndicator(color = Color(0xFF16A34A), label = if (currentLanguage == Language.TAMIL) "கிடைக்கும்" else "Available")
            LegendIndicator(color = Color(0xFFDC2626), label = if (currentLanguage == Language.TAMIL) "முன்பதிவு ஆனது" else "Booked")
            LegendIndicator(color = GoldPrimary, label = if (currentLanguage == Language.TAMIL) "சுப தினம் ✨" else "Muhurtham ✨")
            LegendIndicator(color = PinkPrimary, label = if (currentLanguage == Language.TAMIL) "தேர்வு" else "Selected")
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Days of Week Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            val dayHeaders = if (currentLanguage == Language.TAMIL) dayHeadersTa else dayHeadersEn
            dayHeaders.forEach { header ->
                Text(
                    text = header,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.Gray,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Calendar Grid (7 Columns)
        val totalCells = startDayOfWeek + daysInMonth
        val rowsCount = (totalCells + 6) / 7

        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            for (rowIndex in 0 until rowsCount) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    for (colIndex in 0 until 7) {
                        val cellIndex = rowIndex * 7 + colIndex
                        val dayNum = cellIndex - startDayOfWeek + 1

                        if (dayNum in 1..daysInMonth) {
                            val formattedDate = String.format(Locale.US, "%04d-%02d-%02d", viewedYear, viewedMonth + 1, dayNum)
                            val isBooked = bookedDates.contains(formattedDate)
                            val isMuhurtham = muhurthamDates.contains(formattedDate)
                            val isSelected = formattedDate == selectedDate

                            // Filter check
                            val isVisibleByFilter = when (activeFilter) {
                                "AVAILABLE" -> !isBooked
                                "MUHURTHAM" -> isMuhurtham
                                else -> true
                            }

                            CalendarDayCell(
                                modifier = Modifier.weight(1f),
                                dayNumber = dayNum,
                                isBooked = isBooked,
                                isMuhurtham = isMuhurtham,
                                isSelected = isSelected,
                                isVisibleByFilter = isVisibleByFilter,
                                currentLanguage = currentLanguage,
                                onClick = {
                                    if (isBooked) {
                                        onShowToast("Date $formattedDate is already booked! Please select another available date.")
                                    } else {
                                        onDateSelected(formattedDate)
                                        if (isMuhurtham) {
                                            onShowToast("Selected Auspicious Muhurtham Day ✨ ($formattedDate)")
                                        }
                                    }
                                }
                            )
                        } else {
                            // Empty Cell placeholder for offset
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
        Spacer(modifier = Modifier.height(14.dp))

        // Selected Date Summary & Availability Feedback Panel (Horizontal Alignment)
        val isSelectedDateMuhurtham = muhurthamDates.contains(selectedDate)
        val isSelectedDateBooked = bookedDates.contains(selectedDate)

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(
                    when {
                        isSelectedDateBooked -> Color(0xFFFEE2E2)
                        isSelectedDateMuhurtham -> Color(0xFFFEF3C7)
                        else -> PinkPrimary.copy(alpha = 0.12f)
                    }
                )
                .border(
                    1.5.dp,
                    when {
                        isSelectedDateBooked -> Color(0xFFEF4444)
                        isSelectedDateMuhurtham -> GoldPrimary
                        else -> PinkPrimary
                    },
                    RoundedCornerShape(16.dp)
                )
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left Column: Selected Date & Status Badge
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(
                                when {
                                    isSelectedDateBooked -> Color(0xFFDC2626).copy(alpha = 0.15f)
                                    isSelectedDateMuhurtham -> GoldPrimary.copy(alpha = 0.2f)
                                    else -> PinkPrimary.copy(alpha = 0.2f)
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when {
                                isSelectedDateBooked -> Icons.Default.EventBusy
                                isSelectedDateMuhurtham -> Icons.Default.Star
                                else -> Icons.Default.CheckCircle
                            },
                            contentDescription = null,
                            tint = when {
                                isSelectedDateBooked -> Color(0xFFDC2626)
                                isSelectedDateMuhurtham -> GoldPrimary
                                else -> PinkPrimary
                            },
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Column {
                        Text(
                            text = if (currentLanguage == Language.TAMIL) "தேர்ந்தெடுக்கப்பட்ட தேதி" else "Selected Date",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                        )
                        Text(
                            text = selectedDate,
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = when {
                                isSelectedDateBooked -> if (currentLanguage == Language.TAMIL) "முன்பதிவு செய்யப்பட்டுள்ளது" else "Fully Booked"
                                isSelectedDateMuhurtham -> if (currentLanguage == Language.TAMIL) "சுப முஹூர்த்த நாள் ✨" else "Muhurtham Day ✨"
                                else -> if (currentLanguage == Language.TAMIL) "கிடைக்கும் தேதி" else "Live Available"
                            },
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = when {
                                isSelectedDateBooked -> Color(0xFFDC2626)
                                isSelectedDateMuhurtham -> Color(0xFFB45309)
                                else -> Color(0xFF16A34A)
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Right Column: Horizontal Rate Badge (Cleanly aligned per day amount)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.White)
                        .border(1.dp, PinkPrimary.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = if (currentLanguage == Language.TAMIL) "ஒரு நாள் கட்டணம்" else "Rate Per Day",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                        )
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = "₹${pricePerDay.toInt()}",
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp,
                                color = PinkPrimary
                            )
                            Text(
                                text = if (currentLanguage == Language.TAMIL) " / நாள்" else " / day",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = PinkPrimary.copy(alpha = 0.8f)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Time Slot Selection Options (Horizontal Bar)
        Text(
            text = if (currentLanguage == Language.TAMIL) "நேர இடைவெளியை தேர்ந்தெடுக்கவும்" else "SELECT BOOKING TIME SLOT",
            fontSize = 10.5.sp,
            fontWeight = FontWeight.Black,
            color = Color.Gray,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Horizontal Row for Time Slots
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            val slotItems = listOf(
                Triple("Morning", "6 AM - 2 PM", if (currentLanguage == Language.TAMIL) "காலை" else "Morning"),
                Triple("Evening", "3 PM - 11 PM", if (currentLanguage == Language.TAMIL) "மாலை" else "Evening"),
                Triple("Full Day", "24 Hours", if (currentLanguage == Language.TAMIL) "முழு நாள்" else "Full Day")
            )

            slotItems.forEach { (key, subText, labelText) ->
                val fullSlotName = "$key ($subText)"
                val isSlotSelected = selectedTimeSlot.contains(key, ignoreCase = true)

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSlotSelected) PinkPrimary else MaterialTheme.colorScheme.surface)
                        .border(
                            1.dp,
                            if (isSlotSelected) PinkPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                            RoundedCornerShape(12.dp)
                        )
                        .clickable { onSlotSelected(fullSlotName) }
                        .padding(vertical = 10.dp, horizontal = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = labelText,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSlotSelected) Color.White else MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = subText,
                            fontSize = 8.5.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (isSlotSelected) Color.White.copy(alpha = 0.85f) else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CalendarDayCell(
    modifier: Modifier = Modifier,
    dayNumber: Int,
    isBooked: Boolean,
    isMuhurtham: Boolean,
    isSelected: Boolean,
    isVisibleByFilter: Boolean,
    currentLanguage: Language,
    onClick: () -> Unit
) {
    val scale by animateFloatAsState(
        targetValue = if (isSelected) 1.08f else 1.0f,
        animationSpec = tween(durationMillis = 200, easing = FastOutSlowInEasing),
        label = "cellScale"
    )

    val bgColor by animateColorAsState(
        targetValue = when {
            !isVisibleByFilter -> MaterialTheme.colorScheme.surface.copy(alpha = 0.3f)
            isSelected -> PinkPrimary
            isBooked -> Color(0xFFFEE2E2)
            isMuhurtham -> Color(0xFFFEF3C7)
            else -> MaterialTheme.colorScheme.surface
        },
        animationSpec = tween(durationMillis = 200),
        label = "cellBg"
    )

    val textColor = when {
        !isVisibleByFilter -> Color.Gray.copy(alpha = 0.4f)
        isSelected -> Color.White
        isBooked -> Color(0xFF991B1B)
        isMuhurtham -> Color(0xFF92400E)
        else -> MaterialTheme.colorScheme.onBackground
    }

    Box(
        modifier = modifier
            .aspectRatio(1f)
            .scale(scale)
            .clip(RoundedCornerShape(12.dp))
            .background(bgColor)
            .border(
                width = if (isSelected) 2.dp else if (isMuhurtham) 1.dp else 0.5.dp,
                color = when {
                    isSelected -> PinkPrimary
                    isBooked -> Color(0xFFFCA5A5)
                    isMuhurtham -> GoldPrimary
                    else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                },
                shape = RoundedCornerShape(12.dp)
            )
            .clickable(onClick = onClick)
            .padding(2.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "$dayNumber",
                fontWeight = if (isSelected || isMuhurtham) FontWeight.Black else FontWeight.Bold,
                fontSize = 13.sp,
                color = textColor
            )

            if (isMuhurtham && !isBooked && !isSelected) {
                Text(
                    text = "✨",
                    fontSize = 8.sp
                )
            } else if (isBooked && !isSelected) {
                Text(
                    text = if (currentLanguage == Language.TAMIL) "முன்பதிவு" else "Booked",
                    fontSize = 7.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF991B1B)
                )
            } else if (isSelected) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(10.dp)
                )
            }
        }
    }
}

@Composable
private fun LegendIndicator(color: Color, label: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Text(
            text = label,
            fontSize = 9.5.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
        )
    }
}
