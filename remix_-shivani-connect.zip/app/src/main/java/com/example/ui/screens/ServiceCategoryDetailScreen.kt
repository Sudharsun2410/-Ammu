package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.EventCategory
import com.example.model.Language
import com.example.model.SampleData
import com.example.model.VenueOrService
import com.example.ui.components.GlassBadge
import com.example.ui.components.GlassCard
import com.example.ui.components.StarRating
import com.example.ui.theme.PinkPrimary
import com.example.ui.theme.PinkSecondary
import com.example.ui.theme.PurplePrimary

@Composable
fun ServiceCategoryDetailScreen(
    category: EventCategory,
    currentDistrict: String,
    currentLanguage: Language,
    onBackClick: () -> Unit,
    onBookVenue: (VenueOrService) -> Unit,
    onToggleWishlist: (VenueOrService) -> Unit,
    onShowToast: (String) -> Unit
) {
    val context = LocalContext.current
    var bookmarkedIds by remember { mutableStateOf(setOf<String>()) }

    // Filter vendor listings for selected category
    val vendors = SampleData.sampleVenuesAndServices.filter {
        it.categoryId.equals(category.id, ignoreCase = true) || category.id == "other"
    }.ifEmpty {
        // Fallback sample vendor list so every 15 category displays high quality vendors
        listOf(
            VenueOrService(
                id = "${category.id}_v1",
                titleEn = "Shivani Premium ${category.nameEn} Services",
                titleTa = "சிவாணி பிரீமியம் ${category.nameTa}",
                categoryId = category.id,
                district = currentDistrict,
                taluk = "Main",
                village = "Central Town",
                villageTamil = "மைய நகரம்",
                address = "100 Feet Main Road, $currentDistrict",
                pricePerDay = 15000.0,
                rating = 4.9,
                reviewCount = 86,
                capacity = "Unlimited Event Orders",
                isLiveAvailable = true,
                bookedDates = emptyList(),
                features = listOf("Top Rated Team", "Instant Booking", "Transparent Pricing", "5 Star Customer Service"),
                imageUrl = "https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=800&q=80",
                phone = "+91 98765 43210",
                vendorName = "Shivani Connect Preferred Vendor"
            ),
            VenueOrService(
                id = "${category.id}_v2",
                titleEn = "Grand Royal ${category.nameEn} Group",
                titleTa = "கிராண்ட் ராயல் ${category.nameTa}",
                categoryId = category.id,
                district = currentDistrict,
                taluk = "East",
                village = "Bazaar Street",
                villageTamil = "பஜார் வீதி",
                address = "Bazaar Square, $currentDistrict",
                pricePerDay = 22000.0,
                rating = 4.8,
                reviewCount = 54,
                capacity = "Standard & Premium Packages",
                isLiveAvailable = true,
                bookedDates = emptyList(),
                features = listOf("Custom Themes", "On-Time Delivery", "Certified Professionals"),
                imageUrl = "https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&w=800&q=80",
                phone = "+91 94433 11223",
                vendorName = "Royal Events Tamil Nadu"
            )
        )
    }

    val sampleGalleryImages = listOf(
        "https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=400&q=80",
        "https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&w=400&q=80",
        "https://images.unsplash.com/photo-1555244162-803834f70033?auto=format&fit=crop&w=400&q=80",
        "https://images.unsplash.com/photo-1537633552985-df8429e8048b?auto=format&fit=crop&w=400&q=80"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Service Hero Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(PinkPrimary, PurplePrimary, Color(category.colorHex))
                        )
                    )
            )

            // Content Header inside Banner
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Top Bar Navigation
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onBackClick,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.25f))
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }

                    GlassBadge(
                        text = if (currentLanguage == Language.TAMIL) "${vendors.size} சரிபார்க்கப்பட்ட விற்பனையாளர்கள்" else "${vendors.size} Verified Vendors",
                        containerColor = Color.White.copy(alpha = 0.3f),
                        contentColor = Color.White
                    )
                }

                // Title & Description
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.25f))
                            .border(1.5.dp, Color.White, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = category.iconEmoji, fontSize = 28.sp)
                    }

                    Column {
                        Text(
                            text = if (currentLanguage == Language.TAMIL) category.nameTa else category.nameEn,
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                        Text(
                            text = if (currentLanguage == Language.TAMIL) "சிறந்த கட்டணத்தில் நேரடி முன்பதிவு" else "Direct vendor booking in $currentDistrict at best rates",
                            fontSize = 12.sp,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                }
            }
        }

        // Image Gallery Strip
        Column(modifier = Modifier.padding(vertical = 12.dp)) {
            Text(
                text = if (currentLanguage == Language.TAMIL) "வேலை கேலரி புகைப்படங்கள்" else "Service Work Gallery & Setup Images",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.padding(horizontal = 16.dp)
            ) {
                items(sampleGalleryImages) { imgUrl ->
                    AsyncImage(
                        model = imgUrl,
                        contentDescription = "Gallery Thumbnail",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(width = 110.dp, height = 75.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .border(1.dp, PinkPrimary.copy(alpha = 0.3f), RoundedCornerShape(14.dp))
                    )
                }
            }
        }

        // Vendors List
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = if (currentLanguage == Language.TAMIL) "கிடைக்கும் சேவைகள் & விற்பனையாளர்கள்" else "Available Vendor Listings",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            items(vendors) { vendor ->
                val isBookmarked = bookmarkedIds.contains(vendor.id)

                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    elevation = 4.dp
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        // Vendor Header Image Banner
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(140.dp)
                                .clip(RoundedCornerShape(16.dp))
                        ) {
                            AsyncImage(
                                model = vendor.imageUrl,
                                contentDescription = vendor.titleEn,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )

                            // Availability & Category Badge
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                GlassBadge(
                                    text = if (vendor.isLiveAvailable) "LIVE AVAILABLE" else "BOOKED TODAY",
                                    containerColor = if (vendor.isLiveAvailable) Color(0xFFDCFCE7) else Color(0xFFFEE2E2),
                                    contentColor = if (vendor.isLiveAvailable) Color(0xFF15803D) else Color(0xFFB91C1C)
                                )

                                // Wishlist Button
                                IconButton(
                                    onClick = {
                                        bookmarkedIds = if (isBookmarked) bookmarkedIds - vendor.id else bookmarkedIds + vendor.id
                                        onToggleWishlist(vendor)
                                        onShowToast(if (isBookmarked) "Removed from wishlist" else "Added to wishlist!")
                                    },
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.9f))
                                ) {
                                    Icon(
                                        imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                        contentDescription = "Wishlist",
                                        tint = PinkPrimary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Title & Price Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (currentLanguage == Language.TAMIL) vendor.titleTa else vendor.titleEn,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onBackground
                                )

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.LocationOn,
                                        contentDescription = null,
                                        tint = PinkPrimary,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = "${vendor.village}, ${vendor.district}",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                                    )
                                }
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "₹${vendor.pricePerDay.toInt()}",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Black,
                                    color = PinkPrimary
                                )
                                Text(
                                    text = "/ event day",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Rating & Reviews
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            StarRating(rating = vendor.rating)
                            Text(
                                text = "${vendor.rating} (${vendor.reviewCount} reviews)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f)
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Description & Features
                        Text(
                            text = "Provided by ${vendor.vendorName} • Capacity: ${vendor.capacity}. Includes transparent billing and verified GST invoice.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f),
                            lineHeight = 16.sp
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Actions Row: Contact, Share, Book Now
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Call / Contact Button
                            OutlinedButton(
                                onClick = {
                                    onShowToast("Calling ${vendor.vendorName}: ${vendor.phone}")
                                },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Call,
                                    contentDescription = "Contact",
                                    tint = PinkPrimary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (currentLanguage == Language.TAMIL) "தொடர்பு" else "Contact",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = PinkPrimary
                                )
                            }

                            // Share Button
                            IconButton(
                                onClick = {
                                    onShowToast("Sharing ${vendor.titleEn} details...")
                                },
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(PinkPrimary.copy(alpha = 0.1f))
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Share,
                                    contentDescription = "Share",
                                    tint = PinkPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            // Book Now Button
                            Button(
                                onClick = { onBookVenue(vendor) },
                                colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.weight(1.3f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Event,
                                    contentDescription = "Book",
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (currentLanguage == Language.TAMIL) "முன்பதிவு" else "Book Now",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(30.dp)) }
        }
    }
}
