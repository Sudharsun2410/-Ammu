package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = PinkPrimary,
    onPrimary = Color.White,
    secondary = PinkSecondary,
    onSecondary = Color.White,
    tertiary = PinkLight,
    background = DarkBackground,
    surface = DarkGlassSurface,
    onBackground = DarkTextPrimary,
    onSurface = DarkTextPrimary,
    outline = DarkGlassBorder
)

private val LightColorScheme = lightColorScheme(
    primary = PinkPrimary,
    onPrimary = Color.White,
    secondary = PinkSecondary,
    onSecondary = Color.White,
    tertiary = PinkDark,
    background = PinkBackground,
    surface = SoftWhiteGlass,
    onBackground = TextDark,
    onSurface = TextDark,
    outline = GlassBorderDark
)

@Composable
fun ShivaniConnectTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
