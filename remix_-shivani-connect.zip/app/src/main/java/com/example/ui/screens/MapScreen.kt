package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Language
import com.example.model.SampleData
import com.example.model.VenueOrService
import com.example.model.VillageLocation
import com.example.ui.components.GlassBadge
import com.example.ui.components.GlassCard
import com.example.ui.components.InteractiveTamilNaduMap
import com.example.ui.components.StarRating
import com.example.ui.theme.PinkDark
import com.example.ui.theme.PinkPrimary

@Composable
fun MapScreen(
    currentDistrict: String,
    currentTaluk: String,
    currentVillage: String,
    currentLanguage: Language,
    onSelectLocation: (String, String, String) -> Unit,
    onBookVenueClick: (VenueOrService) -> Unit,
    onShowToast: (String) -> Unit
) {
    val districts = remember { SampleData.sampleLocations.map { it.district }.distinct() }
    val filteredTaluks = remember(currentDistrict) {
        SampleData.sampleLocations.filter { it.district == currentDistrict }.map { it.taluk }.distinct()
    }
    val filteredVillages = remember(currentDistrict, currentTaluk) {
        SampleData.sampleLocations.filter { it.district == currentDistrict && it.taluk == currentTaluk }
    }

    val villageVenues = remember(currentVillage) {
        SampleData.sampleVenuesAndServices.filter { it.village == currentVillage }
            .ifEmpty { SampleData.sampleVenuesAndServices }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 80.dp)
    ) {
        // Section Header
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            Text(
                text = if (currentLanguage == Language.TAMIL) "தமிழ்நாடு வரைபட வழிகாட்டி" else "Interactive Tamil Nadu Map",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = if (currentLanguage == Language.TAMIL) "மாவட்டம் ➔ தாலுகா ➔ கிராமச் சேவைகள்" else "District ➔ Taluk ➔ Village drilldown navigation",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
            )
        }

        // Voice & District Search Bar
        var mapSearchQuery by remember { mutableStateOf("") }
        val context = LocalContext.current

        val mapVoiceLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val spokenResults = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                val spokenText = spokenResults?.firstOrNull()
                if (!spokenText.isNullOrBlank()) {
                    Log.d("sk", "Map Voice Search: $spokenText")
                    mapSearchQuery = spokenText
                    val matchedLoc = SampleData.sampleLocations.firstOrNull {
                        it.district.contains(spokenText, ignoreCase = true) ||
                        it.districtTamil.contains(spokenText, ignoreCase = true) ||
                        it.village.contains(spokenText, ignoreCase = true)
                    }
                    if (matchedLoc != null) {
                        onSelectLocation(matchedLoc.district, matchedLoc.taluk, matchedLoc.village)
                        onShowToast("Navigated to ${matchedLoc.district} - ${matchedLoc.village}")
                    } else {
                        onShowToast("Searched: $spokenText")
                    }
                }
            }
        }

        fun startMapVoiceSearch() {
            try {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (currentLanguage == Language.TAMIL) "ta-IN" else "en-IN")
                    putExtra(RecognizerIntent.EXTRA_PROMPT, if (currentLanguage == Language.TAMIL) "மாவட்டத்தின் பெயரை கூறவும்..." else "Speak district or village name...")
                }
                mapVoiceLauncher.launch(intent)
            } catch (e: Exception) {
                Log.e("sk", "Map voice launch error", e)
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp)
        ) {
            OutlinedTextField(
                value = mapSearchQuery,
                onValueChange = {
                    mapSearchQuery = it
                    val match = SampleData.sampleLocations.firstOrNull { loc ->
                        loc.district.contains(it, ignoreCase = true) ||
                        loc.districtTamil.contains(it, ignoreCase = true) ||
                        loc.village.contains(it, ignoreCase = true)
                    }
                    if (match != null && it.length >= 3) {
                        onSelectLocation(match.district, match.taluk, match.village)
                    }
                },
                placeholder = {
                    Text(
                        text = if (currentLanguage == Language.TAMIL) "மாவட்டத்தைத் தேடுக (எ.கா. மதுரை, சென்னை)..." else "Search district (e.g. Madurai, Chennai)...",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search District",
                        tint = PinkPrimary
                    )
                },
                trailingIcon = {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(PinkPrimary.copy(alpha = 0.15f))
                            .clickable { startMapVoiceSearch() },
                        contentAlignment = Alignment.Center
                    ) {
                        Text("🎤", fontSize = 14.sp)
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(20.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                    focusedBorderColor = PinkPrimary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }

        // District Selection Carousel
        Text(
            text = "SELECT DISTRICT",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = PinkPrimary,
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 4.dp)
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(districts) { dist ->
                val isSelected = dist == currentDistrict
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (isSelected) PinkPrimary else MaterialTheme.colorScheme.surface)
                        .border(1.dp, if (isSelected) PinkPrimary else MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
                        .clickable {
                            val firstLoc = SampleData.sampleLocations.first { it.district == dist }
                            onSelectLocation(dist, firstLoc.taluk, firstLoc.village)
                        }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = dist,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onBackground,
                        fontSize = 12.sp
                    )
                }
            }
        }

        // Taluk & Village Selection Carousel
        Text(
            text = "SELECT TALUK & VILLAGE",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = PinkPrimary,
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 4.dp)
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(filteredVillages) { loc ->
                val isSelected = loc.village == currentVillage
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (isSelected) Color(0xFF0F172A) else MaterialTheme.colorScheme.surface)
                        .border(1.dp, if (isSelected) PinkPrimary else MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
                        .clickable { onSelectLocation(loc.district, loc.taluk, loc.village) }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "📍 ${loc.village} (${loc.taluk})",
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onBackground,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // Interactive SVG/Canvas Tamil Nadu Map Container
        InteractiveTamilNaduMap(
            selectedDistrict = currentDistrict,
            currentLanguage = currentLanguage,
            onDistrictSelect = { districtRegion ->
                val firstLoc = SampleData.sampleLocations.firstOrNull { it.district.equals(districtRegion.id, ignoreCase = true) }
                if (firstLoc != null) {
                    onSelectLocation(firstLoc.district, firstLoc.taluk, firstLoc.village)
                    onShowToast("Selected ${districtRegion.nameEn} (${districtRegion.nameTa}) on Tamil Nadu Map")
                } else {
                    onSelectLocation(districtRegion.id, "Main Taluk", "${districtRegion.id} Village")
                    onShowToast("Navigated to ${districtRegion.nameEn}")
                }
            },
            onBookServiceClick = { pin ->
                val matchedVenue = SampleData.sampleVenuesAndServices.firstOrNull {
                    it.district.equals(pin.districtId, ignoreCase = true) || it.titleEn.contains(pin.serviceTitleEn, ignoreCase = true)
                } ?: SampleData.sampleVenuesAndServices.first()
                onBookVenueClick(matchedVenue)
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(290.dp)
                .padding(horizontal = 16.dp, vertical = 6.dp)
        )

        // Local Village Listings Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (currentLanguage == Language.TAMIL) "$currentVillage இல் உள்ள சேவைகள்" else "Services in $currentVillage",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "${villageVenues.size} Verified",
                fontSize = 11.sp,
                color = PinkPrimary,
                fontWeight = FontWeight.Bold
            )
        }

        // Lazy Column of Village Services
        LazyColumn(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(villageVenues) { item ->
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    elevation = 4.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(70.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(PinkPrimary.copy(alpha = 0.1f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "🏰", fontSize = 32.sp)
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (currentLanguage == Language.TAMIL) item.titleTa else item.titleEn,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                maxLines = 1
                            )
                            Text(
                                text = item.address,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                                maxLines = 1
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                StarRating(
                                    rating = item.rating,
                                    reviewCount = item.reviewCount,
                                    starSize = 11.dp,
                                    fontSize = 11.sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "• ₹${item.pricePerDay.toInt()}/day",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = PinkDark
                                )
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Button(
                                onClick = { onBookVenueClick(item) },
                                colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(text = "Book", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier
                                    .clickable { onShowToast("Calling ${item.phone}") }
                                    .padding(2.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Call,
                                    contentDescription = "Call",
                                    tint = PinkPrimary,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
