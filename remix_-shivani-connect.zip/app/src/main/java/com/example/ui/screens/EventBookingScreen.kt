package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material3.OutlinedButton
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FilterList
import com.example.data.WishlistItemEntity
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.data.BookingEntity
import com.example.model.Language
import com.example.model.SampleData
import com.example.model.VenueOrService
import com.example.ui.components.BookingCalendarView
import com.example.ui.components.OpenSourceVenueMap
import com.example.ui.components.GlassBadge
import com.example.ui.components.GlassCard
import com.example.ui.components.StarRating
import com.example.ui.theme.PinkDark
import com.example.ui.theme.PinkPrimary

@Composable
fun EventBookingScreen(
    currentDistrict: String,
    currentVillage: String,
    selectedCategory: String?,
    selectedVenue: VenueOrService?,
    showPaymentDialog: Boolean,
    bookingDate: String,
    bookingTimeSlot: String,
    guestCount: String,
    currentLanguage: Language,
    savedBookings: List<BookingEntity> = emptyList(),
    onCategorySelect: (String) -> Unit,
    onSelectVenue: (VenueOrService?) -> Unit,
    onUpdateBookingDetails: (String, String, String) -> Unit,
    onOpenPayment: () -> Unit,
    onClosePayment: () -> Unit,
    onConfirmBooking: (String) -> Unit,
    onCancelBooking: (Int) -> Unit = {},
    onAddSampleBookings: () -> Unit = {},
    onViewReceipt: (BookingEntity) -> Unit = {},
    onShowToast: (String) -> Unit = {},
    wishlistItems: List<WishlistItemEntity> = emptyList(),
    onToggleWishlist: (VenueOrService) -> Unit = {}
) {
    var currentSubTab by remember { mutableStateOf(0) } // 0 = Book Services, 1 = My Bookings
    var searchQuery by remember { mutableStateOf("") }
    var selectedLocationFilter by remember { mutableStateOf("All") }
    var showMapOverview by remember { mutableStateOf(false) }
    val context = LocalContext.current

    val venues = remember(selectedCategory, currentDistrict, searchQuery, selectedLocationFilter) {
        SampleData.sampleVenuesAndServices.filter { venue ->
            val matchesCategory = (selectedCategory.isNullOrBlank() || venue.categoryId == selectedCategory)

            val matchesLocationChip = when (selectedLocationFilter) {
                "All" -> true
                else -> venue.district.contains(selectedLocationFilter, ignoreCase = true) ||
                        venue.taluk.contains(selectedLocationFilter, ignoreCase = true) ||
                        venue.village.contains(selectedLocationFilter, ignoreCase = true) ||
                        venue.address.contains(selectedLocationFilter, ignoreCase = true)
            }

            val q = searchQuery.trim()
            val matchesQuery = q.isEmpty() ||
                venue.titleEn.contains(q, ignoreCase = true) ||
                venue.titleTa.contains(q, ignoreCase = true) ||
                venue.district.contains(q, ignoreCase = true) ||
                venue.taluk.contains(q, ignoreCase = true) ||
                venue.village.contains(q, ignoreCase = true) ||
                venue.villageTamil.contains(q, ignoreCase = true) ||
                venue.address.contains(q, ignoreCase = true) ||
                venue.vendorName.contains(q, ignoreCase = true)

            matchesCategory && matchesLocationChip && matchesQuery
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
    ) {
        // Sub-Navigation Segment Control: Book Services vs My Bookings
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { currentSubTab = 0 },
                color = if (currentSubTab == 0) PinkPrimary else MaterialTheme.colorScheme.surface,
                border = if (currentSubTab == 0) null else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                shape = RoundedCornerShape(12.dp)
            ) {
                Box(modifier = Modifier.padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                    Text(
                        text = if (currentLanguage == Language.TAMIL) "🏰 சேவைகள் முன்பதிவு" else "🏰 Book Services",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (currentSubTab == 0) Color.White else MaterialTheme.colorScheme.onBackground
                    )
                }
            }

            Surface(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { currentSubTab = 1 },
                color = if (currentSubTab == 1) PinkPrimary else MaterialTheme.colorScheme.surface,
                border = if (currentSubTab == 1) null else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                shape = RoundedCornerShape(12.dp)
            ) {
                Box(modifier = Modifier.padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                    Text(
                        text = if (currentLanguage == Language.TAMIL) "📋 எனது முன்பதிவுகள் (${savedBookings.size})" else "📋 My Bookings (${savedBookings.size})",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (currentSubTab == 1) Color.White else MaterialTheme.colorScheme.onBackground
                    )
                }
            }
        }

        if (currentSubTab == 1) {
            MyBookingsScreen(
                savedBookings = savedBookings,
                currentLanguage = currentLanguage,
                onCancelBooking = onCancelBooking,
                onAddSampleBookings = onAddSampleBookings,
                onViewReceipt = onViewReceipt,
                onBookNewClick = { currentSubTab = 0 },
                onShowToast = onShowToast
            )
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 80.dp)
            ) {
                // Top Header
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                    Text(
                        text = if (currentLanguage == Language.TAMIL) "திருமண மகால் & சேவை முன்பதிவு" else "Event & Hall Booking Engine",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = if (currentLanguage == Language.TAMIL) "தமிழ்நாடு முழுவதும் உள்ள மகால்கள் & நேரலை மேப்" else "Search Mahals & Services across Tamil Nadu with live map markers",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                }

                // 1. Search Box
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    placeholder = {
                        Text(
                            text = if (currentLanguage == Language.TAMIL) "தேடுங்கள்: அரூர், தர்மபுரி, மதுரை, லக்ஷ்மி மஹால்..." else "Search: Harur, Dharmapuri, Salem, Madurai, Mahal...",
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search Icon",
                            tint = PinkPrimary
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Clear Search",
                                    tint = Color.Gray
                                )
                            }
                        }
                    },
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PinkPrimary,
                        unfocusedBorderColor = Color(0xFFE2E8F0),
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    ),
                    singleLine = true
                )

                // 2. Tamil Nadu Location Filter Chips
                val locationList = listOf(
                    "All" to (if (currentLanguage == Language.TAMIL) "📍 அனைத்து தமிழ்நாடு (38 மாவட்டங்கள்)" else "📍 All Tamil Nadu (38 Districts)"),
                    "Harur" to (if (currentLanguage == Language.TAMIL) "🏰 அரூர்" else "🏰 Harur"),
                    "Dharmapuri" to (if (currentLanguage == Language.TAMIL) "📍 தர்மபுரி" else "📍 Dharmapuri"),
                    "Salem" to (if (currentLanguage == Language.TAMIL) "🌴 சேலம்" else "🌴 Salem"),
                    "Chennai" to (if (currentLanguage == Language.TAMIL) "🏙️ சென்னை" else "🏙️ Chennai"),
                    "Tiruchirappalli" to (if (currentLanguage == Language.TAMIL) "🏛️ திருச்சி" else "🏛️ Trichy"),
                    "Coimbatore" to (if (currentLanguage == Language.TAMIL) "⛰️ கோவை" else "⛰️ Coimbatore"),
                    "Krishnagiri" to (if (currentLanguage == Language.TAMIL) "🌿 கிருஷ்ணகிரி" else "🌿 Krishnagiri"),
                    "Tirupattur" to (if (currentLanguage == Language.TAMIL) "🏰 திருப்பத்தூர்" else "🏰 Tirupattur"),
                    "Erode" to (if (currentLanguage == Language.TAMIL) "🌊 ஈரோடு" else "🌊 Erode"),
                    "Madurai" to (if (currentLanguage == Language.TAMIL) "🛕 மதுரை" else "🛕 Madurai"),
                    "Tiruvannamalai" to (if (currentLanguage == Language.TAMIL) "🔥 திருவண்ணாமலை" else "🔥 Tiruvannamalai")
                )

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(locationList) { (key, label) ->
                        val isSelected = selectedLocationFilter == key
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) PinkPrimary else MaterialTheme.colorScheme.surface)
                                .border(1.dp, if (isSelected) PinkPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                                .clickable { selectedLocationFilter = key }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = label,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onBackground
                            )
                        }
                    }
                }

                // 3. Category Filter Pills
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        val isAll = selectedCategory == null || selectedCategory.isEmpty()
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (isAll) PinkPrimary else MaterialTheme.colorScheme.surface)
                                .border(1.dp, if (isAll) PinkPrimary else MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
                                .clickable { onCategorySelect("") }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(text = "All Services", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = if (isAll) Color.White else MaterialTheme.colorScheme.onBackground)
                        }
                    }
                    items(SampleData.sampleCategories) { cat ->
                        val isSelected = selectedCategory == cat.id
                        val catColor = Color(cat.colorHex)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (isSelected) catColor else catColor.copy(alpha = 0.12f))
                                .border(1.2.dp, if (isSelected) catColor else catColor.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                                .clickable { onCategorySelect(cat.id) }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "${cat.iconEmoji} ${if (currentLanguage == Language.TAMIL) cat.nameTa else cat.nameEn}",
                                fontWeight = FontWeight.Black,
                                fontSize = 11.sp,
                                color = if (isSelected) Color.White else catColor
                            )
                        }
                    }
                }

                // 4. Search Results Summary Bar & Interactive Map Toggle
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = "Pin",
                            tint = PinkPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (currentLanguage == Language.TAMIL) "${venues.size} மகால்கள் & சேவைகள் கண்டறியப்பட்டது" else "${venues.size} Mahals & Services Found",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }

                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { showMapOverview = !showMapOverview },
                        color = if (showMapOverview) PinkPrimary else PinkPrimary.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Map,
                                contentDescription = "Map View",
                                tint = if (showMapOverview) Color.White else PinkPrimary,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (showMapOverview) "📋 List View" else "🗺️ Map Pins",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (showMapOverview) Color.White else PinkPrimary
                            )
                        }
                    }
                }

                // 5. Interactive OpenSource Venue Map Overview (When toggled)
                if (showMapOverview && venues.isNotEmpty()) {
                    val topVenue = venues.first()
                    Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                        OpenSourceVenueMap(
                            venueTitle = if (currentLanguage == Language.TAMIL) topVenue.titleTa else topVenue.titleEn,
                            villageLocation = topVenue.village,
                            districtLocation = topVenue.district,
                            currentLanguage = currentLanguage,
                            mapUrl = topVenue.mapUrl,
                            onShowToast = onShowToast
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // 6. Searchable List View
                if (venues.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = "No Results",
                                    tint = Color.Gray,
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = if (currentLanguage == Language.TAMIL) "'$searchQuery' என்ற பெயரில் மகால்கள் கிடைக்கவில்லை" else "No venues found matching '$searchQuery'",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = if (currentLanguage == Language.TAMIL) "அரூர், தர்மபுரி, மதுரை, அல்லது சென்னை என்று தேடிப் பார்க்கவும்." else "Try searching for Harur, Dharmapuri, Salem, Madurai, or Chennai.",
                                    fontSize = 11.sp,
                                    color = Color.Gray,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Button(
                                    onClick = {
                                        searchQuery = ""
                                        selectedLocationFilter = "All"
                                        onCategorySelect("")
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text(
                                        text = if (currentLanguage == Language.TAMIL) "தேடலை மீட்டமைக்கவும்" else "Reset Search Filters",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(venues) { venue ->
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    elevation = 6.dp
                ) {
                    Column {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(130.dp)
                        ) {
                            AsyncImage(
                                model = venue.imageUrl,
                                contentDescription = venue.titleEn,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color.Black.copy(alpha = 0.35f))
                            )

                            // Status Tag
                            Box(
                                modifier = Modifier
                                    .padding(10.dp)
                                    .align(Alignment.TopStart)
                            ) {
                                GlassBadge(
                                    text = if (venue.isLiveAvailable) "LIVE AVAILABLE" else "BOOKED DATES ACTIVE",
                                    containerColor = if (venue.isLiveAvailable) Color(0xFFDCFCE7) else Color(0xFFFEE2E2),
                                    contentColor = if (venue.isLiveAvailable) Color(0xFF15803D) else Color(0xFF991B1B)
                                )
                            }

                            // Favorite Toggle Button (Room DB Persistence)
                            val isWishlisted = wishlistItems.any { it.id == venue.id }
                            IconButton(
                                onClick = { onToggleWishlist(venue) },
                                modifier = Modifier
                                    .padding(10.dp)
                                    .align(Alignment.TopEnd)
                                    .clip(CircleShape)
                                    .background(Color.Black.copy(alpha = 0.5f))
                                    .size(32.dp)
                            ) {
                                Icon(
                                    imageVector = if (isWishlisted) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                    contentDescription = "Favorite",
                                    tint = if (isWishlisted) PinkPrimary else Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (currentLanguage == Language.TAMIL) venue.titleTa else venue.titleEn,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                StarRating(
                                    rating = venue.rating,
                                    reviewCount = venue.reviewCount,
                                    starSize = 13.dp,
                                    fontSize = 12.sp
                                )
                            }

                            Text(
                                text = "📍 ${venue.address}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            // Features Chips
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                venue.features.take(2).forEach { feat ->
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(0.5.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(6.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(text = "✓ $feat", fontSize = 9.sp, color = PinkPrimary)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = "BOOKING RATE", fontSize = 9.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f))
                                    Text(
                                        text = "₹${venue.pricePerDay.toInt()}/day",
                                        fontWeight = FontWeight.Black,
                                        fontSize = 18.sp,
                                        color = PinkPrimary
                                    )
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    if (venue.mapUrl.isNotBlank()) {
                                        OutlinedButton(
                                            onClick = {
                                                try {
                                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(venue.mapUrl))
                                                    context.startActivity(intent)
                                                } catch (e: Exception) {
                                                    onShowToast("Opening Map Link...")
                                                }
                                            },
                                            shape = RoundedCornerShape(12.dp),
                                            border = androidx.compose.foundation.BorderStroke(1.dp, PinkPrimary),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                        ) {
                                            Text(
                                                text = "📍 Maps",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp,
                                                color = PinkPrimary
                                            )
                                        }
                                    }

                                    Button(
                                        onClick = { onSelectVenue(venue) },
                                        colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                                        shape = RoundedCornerShape(12.dp),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = if (currentLanguage == Language.TAMIL) "தேதி தேர்வு" else "Select Dates",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

    // Detailed Venue View & Booking Availability Sheet Dialog
    if (selectedVenue != null && !showPaymentDialog) {
        Dialog(onDismissRequest = { onSelectVenue(null) }) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                ) {
                    // 1. Hero Image Banner with Overlay Controls
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                    ) {
                        AsyncImage(
                            model = selectedVenue.imageUrl,
                            contentDescription = selectedVenue.titleEn,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(alpha = 0.35f))
                        )

                        // Top Left Live Status
                        Box(
                            modifier = Modifier
                                .padding(12.dp)
                                .align(Alignment.TopStart)
                        ) {
                            GlassBadge(
                                text = if (selectedVenue.isLiveAvailable) "LIVE AVAILABLE" else "BOOKED DATES ACTIVE",
                                containerColor = if (selectedVenue.isLiveAvailable) Color(0xFFDCFCE7) else Color(0xFFFEE2E2),
                                contentColor = if (selectedVenue.isLiveAvailable) Color(0xFF15803D) else Color(0xFF991B1B)
                            )
                        }

                        // Top Right Close Button
                        IconButton(
                            onClick = { onSelectVenue(null) },
                            modifier = Modifier
                                .padding(8.dp)
                                .align(Alignment.TopEnd)
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.5f))
                                .size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        // Bottom Image Information Overlay
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.BottomStart)
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Capacity Badge
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.Black.copy(alpha = 0.6f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Group,
                                        contentDescription = "Capacity",
                                        tint = Color.White,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = selectedVenue.capacity.ifBlank { "1000+ Capacity" },
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            // Rating Badge
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.Black.copy(alpha = 0.6f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                StarRating(
                                    rating = selectedVenue.rating,
                                    reviewCount = selectedVenue.reviewCount,
                                    starSize = 12.dp,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    // 2. Main Content Body
                    Column(modifier = Modifier.padding(16.dp)) {
                        // Title & District Location Header
                        Text(
                            text = if (currentLanguage == Language.TAMIL) selectedVenue.titleTa else selectedVenue.titleEn,
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp,
                            color = MaterialTheme.colorScheme.onBackground
                        )

                        Text(
                            text = "📍 ${selectedVenue.address}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f),
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(top = 4.dp)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // 3. Contact Information & Direct Action Card
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                                .padding(12.dp)
                        ) {
                            Column {
                                Text(
                                    text = if (currentLanguage == Language.TAMIL) "📞 தொடர்புக்கு & விவரங்கள் (Contact Info)" else "📞 Contact & Management Details",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onBackground
                                )

                                Spacer(modifier = Modifier.height(6.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "🏢 ${selectedVenue.vendorName.ifBlank { "Mahal Management" }}",
                                            fontSize = 11.5.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = PinkPrimary
                                        )
                                        Text(
                                            text = "📱 ${selectedVenue.phone.ifBlank { "+91 98421 88990" }}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f)
                                        )
                                    }

                                    // Direct Call Button
                                    OutlinedButton(
                                        onClick = {
                                            try {
                                                val phoneNum = selectedVenue.phone.ifBlank { "+919842188990" }
                                                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNum"))
                                                context.startActivity(intent)
                                            } catch (e: Exception) {
                                                onShowToast("Calling Manager...")
                                            }
                                        },
                                        shape = RoundedCornerShape(10.dp),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, PinkPrimary),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Call, contentDescription = "Call", tint = PinkPrimary, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = if (currentLanguage == Language.TAMIL) "அழைக்க" else "Call",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = PinkPrimary
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // Directions & Share Action Buttons Row
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    // Get Directions Button
                                    Button(
                                        onClick = {
                                            val targetUrl = selectedVenue.mapUrl.ifBlank {
                                                "https://www.google.com/maps/search/?api=1&query=${Uri.encode("${selectedVenue.titleEn} ${selectedVenue.address}")}"
                                            }
                                            try {
                                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl))
                                                context.startActivity(intent)
                                                onShowToast("Opening Google Maps Directions...")
                                            } catch (e: Exception) {
                                                onShowToast("Opening Navigation...")
                                            }
                                        },
                                        modifier = Modifier.weight(1f),
                                        colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                                        shape = RoundedCornerShape(10.dp),
                                        contentPadding = PaddingValues(vertical = 6.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Directions, contentDescription = "Get Directions", tint = Color.White, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = if (currentLanguage == Language.TAMIL) "🧭 வழித்தடம் (Get Directions)" else "🧭 Get Directions",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }

                                    // Share Mahal Details Button
                                    OutlinedButton(
                                        onClick = {
                                            try {
                                                val shareText = "📍 ${selectedVenue.titleEn}\nAddress: ${selectedVenue.address}\nContact: ${selectedVenue.phone}\nMap: ${selectedVenue.mapUrl}"
                                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                                    type = "text/plain"
                                                    putExtra(Intent.EXTRA_TEXT, shareText)
                                                }
                                                context.startActivity(Intent.createChooser(shareIntent, "Share Mahal Details"))
                                            } catch (e: Exception) {
                                                onShowToast("Sharing Mahal details...")
                                            }
                                        },
                                        shape = RoundedCornerShape(10.dp),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Share, contentDescription = "Share", tint = MaterialTheme.colorScheme.onBackground, modifier = Modifier.size(14.dp))
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // 4. Features & Amenities Chips
                        Text(
                            text = if (currentLanguage == Language.TAMIL) "✨ வசதிகள் & சிறப்பம்சங்கள் (Amenities)" else "✨ Key Amenities & Features",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            selectedVenue.features.take(4).forEach { feat ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(PinkPrimary.copy(alpha = 0.08f))
                                        .border(0.5.dp, PinkPrimary.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = "✓ $feat",
                                        fontSize = 10.sp,
                                        color = PinkPrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // 5. Embedded OpenSource Venue Location Map
                        OpenSourceVenueMap(
                            venueTitle = if (currentLanguage == Language.TAMIL) selectedVenue.titleTa else selectedVenue.titleEn,
                            villageLocation = selectedVenue.village.ifBlank { currentVillage },
                            districtLocation = selectedVenue.district.ifBlank { currentDistrict },
                            currentLanguage = currentLanguage,
                            mapUrl = selectedVenue.mapUrl,
                            onShowToast = onShowToast
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // 6. Live Interactive Booking Calendar View Component
                        BookingCalendarView(
                            bookedDates = selectedVenue.bookedDates,
                            muhurthamDates = listOf("2026-08-03", "2026-08-09", "2026-08-20", "2026-08-24", "2026-08-30", "2026-09-06", "2026-09-12"),
                            selectedDate = bookingDate,
                            selectedTimeSlot = bookingTimeSlot,
                            guestCount = guestCount,
                            pricePerDay = selectedVenue.pricePerDay,
                            currentLanguage = currentLanguage,
                            onDateSelected = { newDate ->
                                onUpdateBookingDetails(newDate, bookingTimeSlot, guestCount)
                            },
                            onSlotSelected = { newSlot ->
                                onUpdateBookingDetails(bookingDate, newSlot, guestCount)
                            },
                            onGuestCountChange = { newGuest ->
                                onUpdateBookingDetails(bookingDate, bookingTimeSlot, newGuest)
                            },
                            onShowToast = onShowToast
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // 7. Summary & Proceed Horizontal Card
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(PinkPrimary.copy(alpha = 0.08f))
                                .border(1.dp, PinkPrimary.copy(alpha = 0.25f), RoundedCornerShape(16.dp))
                                .padding(14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = if (currentLanguage == Language.TAMIL) "மொத்த கட்டணம் (1 நாள்)" else "TOTAL AMOUNT (1 DAY)",
                                        fontSize = 9.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                                    )
                                    Row(verticalAlignment = Alignment.Bottom) {
                                        Text(
                                            text = "₹${selectedVenue.pricePerDay.toInt()}",
                                            fontWeight = FontWeight.Black,
                                            fontSize = 20.sp,
                                            color = PinkPrimary
                                        )
                                        Text(
                                            text = if (currentLanguage == Language.TAMIL) " / நாள்" else " / day",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = PinkPrimary.copy(alpha = 0.8f)
                                        )
                                    }
                                }

                                Button(
                                    onClick = onOpenPayment,
                                    colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                                    shape = RoundedCornerShape(12.dp),
                                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                                ) {
                                    Text(
                                        text = if (currentLanguage == Language.TAMIL) "⚡ செலுத்து (Auto Pay)" else "⚡ Auto Pay / Book",
                                        fontWeight = FontWeight.Black,
                                        fontSize = 11.5.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Demo Payment Dialog
    if (showPaymentDialog && selectedVenue != null) {
        var selectedPaymentMethod by remember { mutableStateOf("UPI (PhonePe / Google Pay)") }

        Dialog(onDismissRequest = onClosePayment) {
            Surface(
                shape = RoundedCornerShape(28.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Demo Payment Gateway",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        IconButton(onClick = onClosePayment) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFFEFF6FF))
                            .padding(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = Color(0xFF2563EB))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(text = "256-Bit SSL Demo Secured", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1D4ED8))
                                Text(text = "Amount: ₹${selectedVenue.pricePerDay.toInt()}", fontSize = 13.sp, fontWeight = FontWeight.Black, color = Color(0xFF1E293B))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(text = "CHOOSE PAYMENT METHOD", fontSize = 10.sp, fontWeight = FontWeight.Black, color = PinkPrimary)
                    Spacer(modifier = Modifier.height(8.dp))

                    listOf(
                        "UPI (PhonePe / Google Pay / Paytm)",
                        "Credit / Debit Card (Visa/Master)",
                        "Net Banking (SBI / HDFC / Canara)",
                        "Cash / Token Advance at Venue"
                    ).forEach { method ->
                        val isSelected = method == selectedPaymentMethod
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) PinkPrimary.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surface)
                                .border(1.dp, if (isSelected) PinkPrimary else MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
                                .clickable { selectedPaymentMethod = method }
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = { selectedPaymentMethod = method }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = method, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onConfirmBooking("⚡ Auto Pay (UPI Express)") },
                            colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = "⚡ Auto Pay Mini (₹${selectedVenue.pricePerDay.toInt()})",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }

                        Button(
                            onClick = { onConfirmBooking(selectedPaymentMethod) },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = "Pay & Invoice",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}
}
}
