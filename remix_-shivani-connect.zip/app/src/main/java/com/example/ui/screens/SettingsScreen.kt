package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.MarkEmailRead
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Pending
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import com.example.data.BookingEntity
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.BackupState
import com.example.model.Language
import com.example.model.UserProfile
import com.example.model.UserRole
import com.example.service.FcmNotificationManager
import com.example.service.FcmSettingsState
import com.example.ui.components.GlassBadge
import com.example.ui.components.GlassCard
import com.example.ui.theme.PinkPrimary
import com.example.ui.theme.PinkSecondary
import com.example.ui.theme.PurplePrimary

@Composable
fun SettingsScreen(
    userProfile: UserProfile,
    currentRole: UserRole,
    currentLanguage: Language,
    isDarkMode: Boolean,
    onBackClick: () -> Unit,
    onLanguageToggle: () -> Unit,
    onDarkModeToggle: () -> Unit,
    onRoleSelect: (UserRole) -> Unit,
    onOpenAdminPanel: () -> Unit,
    onLogoutClick: () -> Unit,
    onShowToast: (String) -> Unit,
    savedBookings: List<BookingEntity> = emptyList(),
    onCancelBooking: (Int) -> Unit = {},
    onUpdateBookingStatus: (Int, String) -> Unit = { _, _ -> },
    onDeleteBooking: (Int) -> Unit = {},
    onSeedSampleBookings: () -> Unit = {},
    onViewInvoice: ((BookingEntity) -> Unit)? = null
) {
    var activeSubSection by remember { mutableStateOf<String?>(null) } // "profile", "backup", "privacy", "about", "notifications", etc.
    var backupState by remember { mutableStateOf(BackupState()) }
    var fcmState by remember { mutableStateOf(FcmSettingsState()) }

    LaunchedEffect(Unit) {
        FcmNotificationManager.fetchFcmToken { token ->
            fcmState = fcmState.copy(fcmToken = token)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp)
        ) {
            // Top Spacing Requirement + Header Bar
            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        if (activeSubSection != null) activeSubSection = null
                        else onBackClick()
                    },
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surface)
                        .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = PinkPrimary
                    )
                }

                Text(
                    text = if (activeSubSection != null) activeSubSection!!.replaceFirstChar { it.uppercase() } else if (currentLanguage == Language.TAMIL) "அமைப்புகள்" else "Settings",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Spacer(modifier = Modifier.size(44.dp))
            }

        Spacer(modifier = Modifier.height(12.dp))

        if (activeSubSection == null) {
            // MAIN SETTINGS LIST
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Profile Header Card
                item {
                    GlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { activeSubSection = "Profile" },
                        shape = RoundedCornerShape(24.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(CircleShape)
                                    .border(2.dp, Brush.linearGradient(listOf(PinkPrimary, PurplePrimary)), CircleShape)
                                    .background(Color.Black),
                                contentAlignment = Alignment.Center
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.sk_shivani_skhub_logo_1785082786285),
                                    contentDescription = "Profile Pic",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.size(50.dp).clip(CircleShape)
                                )
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = userProfile.fullName,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 16.sp,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                Text(
                                    text = userProfile.email,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                GlassBadge(
                                    text = "ROLE: ${currentRole.displayName.uppercase()}",
                                    containerColor = Color(currentRole.badgeColorHex).copy(alpha = 0.15f),
                                    contentColor = Color(currentRole.badgeColorHex)
                                )
                            }

                            Icon(
                                imageVector = Icons.Default.ChevronRight,
                                contentDescription = null,
                                tint = PinkPrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                }

                // Settings Menu Items
                item {
                    SettingsRowItem(
                        icon = Icons.Default.Person,
                        title = "Profile",
                        subtitle = "Name, Phone, Email & User Details",
                        onClick = { activeSubSection = "Profile" }
                    )
                }

                item {
                    SettingsRowItem(
                        icon = Icons.Default.History,
                        title = if (currentLanguage == Language.TAMIL) "முன்பதிவு வரலாறு" else "Booking History",
                        subtitle = "Past & upcoming event hall, catering & service bookings",
                        onClick = { activeSubSection = "Booking History" }
                    )
                }

                item {
                    SettingsRowItem(
                        icon = Icons.Default.Person,
                        title = "User",
                        subtitle = if (currentRole == UserRole.USER) "Active Role: Customer / Citizen" else "Switch to Customer Mode",
                        onClick = {
                            onRoleSelect(UserRole.USER)
                            onShowToast("Switched to Customer User mode")
                        }
                    )
                }

                item {
                    SettingsRowItem(
                        icon = Icons.Default.AdminPanelSettings,
                        title = "Admin",
                        subtitle = if (currentRole == UserRole.ADMIN) "Active Role: Platform Administrator" else "Switch to Admin Mode",
                        onClick = {
                            onRoleSelect(UserRole.ADMIN)
                            onShowToast("Switched to Admin mode")
                        }
                    )
                }

                item {
                    SettingsRowItem(
                        icon = Icons.Default.Store,
                        title = "Vendor",
                        subtitle = if (currentRole == UserRole.VENDOR) "Active Role: Service Provider" else "Switch to Vendor Mode",
                        onClick = {
                            onRoleSelect(UserRole.VENDOR)
                            onShowToast("Switched to Vendor mode")
                        }
                    )
                }

                item {
                    SettingsRowItem(
                        icon = Icons.Default.Language,
                        title = "Language",
                        subtitle = "Current: ${if (currentLanguage == Language.TAMIL) "தமிழ் (Tamil)" else "English"}",
                        onClick = onLanguageToggle
                    )
                }

                item {
                    SettingsRowItem(
                        icon = Icons.Default.DarkMode,
                        title = "Theme",
                        subtitle = if (isDarkMode) "Dark Mode Active" else "Light Mode Active",
                        onClick = onDarkModeToggle
                    )
                }

                item {
                    SettingsRowItem(
                        icon = Icons.Default.Backup,
                        title = "Backup & Restore",
                        subtitle = "Create backup, restore & cloud sync",
                        onClick = { activeSubSection = "Backup & Restore" }
                    )
                }

                item {
                    SettingsRowItem(
                        icon = Icons.Default.Notifications,
                        title = "Notifications",
                        subtitle = if (fcmState.allNotificationsEnabled) "FCM Real-time Alerts Active" else "All FCM Alerts Muted",
                        trailingContent = {
                            Switch(
                                checked = fcmState.allNotificationsEnabled,
                                onCheckedChange = { isChecked ->
                                    val updated = fcmState.copy(allNotificationsEnabled = isChecked)
                                    fcmState = updated
                                    FcmNotificationManager.updateTopicSubscriptions(
                                        bookingEnabled = isChecked && updated.bookingUpdatesEnabled,
                                        promoEnabled = isChecked && updated.promotionalOffersEnabled
                                    )
                                    onShowToast(if (isChecked) "FCM Notifications Enabled" else "All FCM Notifications Muted")
                                },
                                colors = SwitchDefaults.colors(checkedThumbColor = PinkPrimary)
                            )
                        },
                        onClick = { activeSubSection = "Notifications" }
                    )
                }

                item {
                    SettingsRowItem(
                        icon = Icons.Default.PrivacyTip,
                        title = "Privacy",
                        subtitle = "Data encryption & privacy permissions",
                        onClick = { activeSubSection = "Privacy" }
                    )
                }

                item {
                    SettingsRowItem(
                        icon = Icons.Default.Security,
                        title = "Security",
                        subtitle = "Password, PIN & 2-Factor Auth",
                        onClick = { activeSubSection = "Security" }
                    )
                }

                item {
                    SettingsRowItem(
                        icon = Icons.Default.People,
                        title = "User Management",
                        subtitle = "Manage platform accounts & permissions",
                        onClick = { activeSubSection = "User Management" }
                    )
                }

                item {
                    SettingsRowItem(
                        icon = Icons.Default.Store,
                        title = "Vendor Management",
                        subtitle = "Approve village vendors & services",
                        onClick = { activeSubSection = "Vendor Management" }
                    )
                }

                item {
                    SettingsRowItem(
                        icon = Icons.Default.AdminPanelSettings,
                        title = "Admin Panel",
                        subtitle = "Full system workspace & analytics",
                        onClick = onOpenAdminPanel
                    )
                }

                item {
                    SettingsRowItem(
                        icon = Icons.Default.HelpOutline,
                        title = "Help & Support",
                        subtitle = "24/7 Helpline, FAQ & WhatsApp support",
                        onClick = { activeSubSection = "Help & Support" }
                    )
                }

                item {
                    SettingsRowItem(
                        icon = Icons.Default.Info,
                        title = "About",
                        subtitle = "Shivani Connect v1.0 • Brand Story",
                        onClick = { activeSubSection = "About" }
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = onLogoutClick,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Logout, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("LOGOUT", fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(30.dp))
                }
            }
        } else {
            // SUB-SECTION VIEWS
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp)
            ) {
                when (activeSubSection) {
                    "Booking History" -> {
                        BookingHistorySubSection(
                            savedBookings = savedBookings,
                            currentLanguage = currentLanguage,
                            onCancelBooking = onCancelBooking,
                            onUpdateBookingStatus = onUpdateBookingStatus,
                            onDeleteBooking = onDeleteBooking,
                            onSeedSampleBookings = onSeedSampleBookings,
                            onViewInvoice = onViewInvoice,
                            onShowToast = onShowToast
                        )
                    }

                    "Notifications" -> {
                        NotificationsSubSection(
                            fcmState = fcmState,
                            onUpdateFcmState = { fcmState = it },
                            onShowToast = onShowToast
                        )
                    }

                    "Backup & Restore" -> {
                        BackupAndRestoreSection(
                            backupState = backupState,
                            onUpdateState = { backupState = it },
                            onShowToast = onShowToast
                        )
                    }

                    "Profile" -> {
                        ProfileSubSection(userProfile = userProfile, onShowToast = onShowToast)
                    }

                    "About" -> {
                        AboutSubSection()
                    }

                    else -> {
                        // Generic placeholder sub-section
                        GlassCard(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(24.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "$activeSubSection Settings",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = "Configure and customize $activeSubSection preferences for Shivani Connect platform.",
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f),
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(20.dp))
                                Button(
                                    onClick = { onShowToast("$activeSubSection settings saved!") },
                                    colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text("Save Changes")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
}

@Composable
private fun SettingsRowItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    trailingContent: (@Composable () -> Unit)? = null
) {
    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(PinkPrimary.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = PinkPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Column {
                    Text(
                        text = title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = subtitle,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                }
            }

            if (trailingContent != null) {
                trailingContent()
            } else {
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
private fun BackupAndRestoreSection(
    backupState: BackupState,
    onUpdateState: (BackupState) -> Unit,
    onShowToast: (String) -> Unit
) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(PinkPrimary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.CloudDone, contentDescription = null, tint = PinkPrimary)
                        }

                        Column {
                            Text("Database Backup & Sync", fontWeight = FontWeight.Black, fontSize = 16.sp)
                            Text("Last Backup: ${backupState.lastBackupTime}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
                            Text("Archive Size: ${backupState.backupSizeMb}", fontSize = 12.sp, color = PinkPrimary, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Action Buttons for Backup & Restore Requirements
                    Button(
                        onClick = {
                            onUpdateState(backupState.copy(lastBackupTime = "Just Now"))
                            onShowToast("Created encrypted Room DB backup in local storage!")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.Upload, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Create Backup", fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedButton(
                        onClick = {
                            onShowToast("Restored database tables & bookings successfully!")
                        },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.Restore, contentDescription = null, tint = PinkPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Restore Backup", fontWeight = FontWeight.Bold, color = PinkPrimary)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { onShowToast("Exported JSON database backup file!") },
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Export Data", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = { onShowToast("Imported data file into SQLite Room DB!") },
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Import Data", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item {
            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Auto Backup", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("Perform daily automated database backups in background", fontSize = 11.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
                        }
                        Switch(
                            checked = backupState.isAutoBackupEnabled,
                            onCheckedChange = {
                                onUpdateState(backupState.copy(isAutoBackupEnabled = it))
                                onShowToast(if (it) "Auto Backup Enabled" else "Auto Backup Disabled")
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = PinkPrimary)
                        )
                    }

                    Divider(modifier = Modifier.padding(vertical = 12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Cloud Backup Support", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("Synchronize encrypted backup with Google Drive / Cloud", fontSize = 11.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
                        }
                        Switch(
                            checked = backupState.isCloudSyncActive,
                            onCheckedChange = {
                                onUpdateState(backupState.copy(isCloudSyncActive = it))
                                onShowToast(if (it) "Cloud Drive Sync Enabled" else "Cloud Sync Disabled")
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = PinkPrimary)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfileSubSection(
    userProfile: UserProfile,
    onShowToast: (String) -> Unit
) {
    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text("User Profile Details", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(16.dp))

            ProfileField("Full Name", userProfile.fullName)
            ProfileField("Mobile Number", userProfile.mobileNumber)
            ProfileField("Email Address", userProfile.email)
            ProfileField("Account Type", userProfile.userType)
            ProfileField("KYC Status", if (userProfile.isVerified) "Verified User ✓" else "Pending")

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = { onShowToast("Updated profile information!") },
                colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Edit Profile Details")
            }
        }
    }
}

@Composable
private fun ProfileField(label: String, value: String) {
    Column(modifier = Modifier.padding(vertical = 6.dp)) {
        Text(text = label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f))
        Text(text = value, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun AboutSubSection() {
    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .border(2.dp, Brush.linearGradient(listOf(PinkPrimary, PurplePrimary)), CircleShape)
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.sk_shivani_skhub_logo_1785082786285),
                    contentDescription = "Logo",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(76.dp).clip(CircleShape)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text("SHIVANI SKHub", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black, color = PinkPrimary)
            Text("CONNECT • SERVE • GROW", fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Shivani Connect is Tamil Nadu's premiere AI-driven Event Booking & Village E-Commerce Platform. " +
                        "Easily discover marriage halls, caterers, photographers, decorators, and local village artisans across all 38 Tamil Nadu districts.",
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                lineHeight = 16.sp,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f)
            )

            Spacer(modifier = Modifier.height(16.dp))

            GlassBadge(text = "App Version: 1.0.0 (Build 2026)", containerColor = PinkPrimary.copy(alpha = 0.15f), contentColor = PinkPrimary)
        }
    }
}

@Composable
private fun NotificationsSubSection(
    fcmState: FcmSettingsState,
    onUpdateFcmState: (FcmSettingsState) -> Unit,
    onShowToast: (String) -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.padding(bottom = 24.dp)
    ) {
        // FCM Status & Token Header Card
        item {
            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(PinkPrimary.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MarkEmailRead,
                                    contentDescription = "FCM Active",
                                    tint = PinkPrimary,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            Column {
                                Text(
                                    text = "Firebase Cloud Messaging",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                Text(
                                    text = if (fcmState.allNotificationsEnabled) "Real-time Push Engine Connected" else "Push Engine Muted",
                                    fontSize = 11.sp,
                                    color = if (fcmState.allNotificationsEnabled) Color(0xFF16A34A) else Color.Gray,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        GlassBadge(
                            text = "FCM v34.15",
                            containerColor = PinkPrimary.copy(alpha = 0.12f),
                            contentColor = PinkPrimary
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // FCM Registration Token Box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.6f))
                            .padding(12.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "DEVICE REGISTRATION TOKEN",
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.Gray
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    IconButton(
                                        onClick = {
                                            clipboardManager.setText(AnnotatedString(fcmState.fcmToken))
                                            onShowToast("FCM Registration Token copied to clipboard!")
                                        },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy", tint = PinkPrimary, modifier = Modifier.size(16.dp))
                                    }

                                    IconButton(
                                        onClick = {
                                            FcmNotificationManager.fetchFcmToken { newToken ->
                                                onUpdateFcmState(fcmState.copy(fcmToken = newToken))
                                                onShowToast("Refreshed FCM registration token!")
                                            }
                                        },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Refresh, contentDescription = "Refresh", tint = PinkPrimary, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = fcmState.fcmToken,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f),
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }

        // Notification Channel Preferences Card
        item {
            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "NOTIFICATION PREFERENCES",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.Gray
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Preference 1: Master Push Notifications
                    NotificationToggleRow(
                        icon = Icons.Default.Notifications,
                        title = "Master Real-time Push Alerts",
                        subtitle = "Enable or disable all incoming background & foreground push alerts",
                        checked = fcmState.allNotificationsEnabled,
                        onCheckedChange = { isChecked ->
                            val updated = fcmState.copy(allNotificationsEnabled = isChecked)
                            onUpdateFcmState(updated)
                            FcmNotificationManager.updateTopicSubscriptions(
                                bookingEnabled = isChecked && updated.bookingUpdatesEnabled,
                                promoEnabled = isChecked && updated.promotionalOffersEnabled
                            )
                            onShowToast(if (isChecked) "Master Push Notifications Enabled" else "All Push Notifications Muted")
                        }
                    )

                    Divider(
                        modifier = Modifier.padding(vertical = 12.dp),
                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                    )

                    // Preference 2: Booking & Service Status Updates
                    NotificationToggleRow(
                        icon = Icons.Default.EventAvailable,
                        title = "Booking & Service Updates",
                        subtitle = "Instant alerts when hall bookings, photographer orders, or village service statuses change",
                        checked = fcmState.allNotificationsEnabled && fcmState.bookingUpdatesEnabled,
                        enabled = fcmState.allNotificationsEnabled,
                        onCheckedChange = { isChecked ->
                            val updated = fcmState.copy(bookingUpdatesEnabled = isChecked)
                            onUpdateFcmState(updated)
                            FcmNotificationManager.updateTopicSubscriptions(
                                bookingEnabled = isChecked,
                                promoEnabled = updated.promotionalOffersEnabled
                            )
                            onShowToast(if (isChecked) "Booking Updates Topic Subscribed!" else "Unsubscribed from Booking Updates")
                        }
                    )

                    Divider(
                        modifier = Modifier.padding(vertical = 12.dp),
                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                    )

                    // Preference 3: Promotional Offers & Festive Deals
                    NotificationToggleRow(
                        icon = Icons.Default.Campaign,
                        title = "Promotional Offers & Festive Deals",
                        subtitle = "Exclusive coupon codes, festive discounts & village marketplace offers",
                        checked = fcmState.allNotificationsEnabled && fcmState.promotionalOffersEnabled,
                        enabled = fcmState.allNotificationsEnabled,
                        onCheckedChange = { isChecked ->
                            val updated = fcmState.copy(promotionalOffersEnabled = isChecked)
                            onUpdateFcmState(updated)
                            FcmNotificationManager.updateTopicSubscriptions(
                                bookingEnabled = updated.bookingUpdatesEnabled,
                                promoEnabled = isChecked
                            )
                            onShowToast(if (isChecked) "Promotions Topic Subscribed!" else "Unsubscribed from Promotional Offers")
                        }
                    )

                    Divider(
                        modifier = Modifier.padding(vertical = 12.dp),
                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                    )

                    // Preference 4: Vendor & Chat Messages
                    NotificationToggleRow(
                        icon = Icons.Default.Send,
                        title = "Vendor & Direct Chat Messages",
                        subtitle = "Instant push messages when caterers, decorators, or admins reply in chat",
                        checked = fcmState.allNotificationsEnabled && fcmState.vendorAlertsEnabled,
                        enabled = fcmState.allNotificationsEnabled,
                        onCheckedChange = { isChecked ->
                            onUpdateFcmState(fcmState.copy(vendorAlertsEnabled = isChecked))
                            onShowToast(if (isChecked) "Vendor Direct Messaging Enabled" else "Vendor Messages Muted")
                        }
                    )
                }
            }
        }

        // Test FCM Real-time Push Trigger Card
        item {
            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "REAL-TIME FCM PUSH TESTER",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        color = PinkPrimary
                    )
                    Text(
                        text = "Trigger real-time push alerts to test notification delivery and status bar display.",
                        fontSize = 11.5.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = {
                                FcmNotificationManager.showNotification(
                                    context = context,
                                    title = "🎉 Mandapam Booking Confirmed!",
                                    message = "Your booking for Sri Lakshmi Mahal, Madurai on Oct 15 is confirmed. Token #SK-8921.",
                                    channelId = FcmNotificationManager.CHANNEL_BOOKING
                                )
                                onShowToast("Sent Booking Status Push Alert to status bar!")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(imageVector = Icons.Default.EventAvailable, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Test Booking Update Alert", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }

                        OutlinedButton(
                            onClick = {
                                FcmNotificationManager.showNotification(
                                    context = context,
                                    title = "🔥 Festive Discount Offer Alert!",
                                    message = "Get 25% OFF on Bridal Makeup & Catering Packages in Madurai! Code: SHIVANI25",
                                    channelId = FcmNotificationManager.CHANNEL_PROMO
                                )
                                onShowToast("Sent Promotional Offer Push Alert to status bar!")
                            },
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(imageVector = Icons.Default.Campaign, contentDescription = null, tint = PinkPrimary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Test Promotional Offer Alert", fontWeight = FontWeight.Bold, color = PinkPrimary, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NotificationToggleRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    enabled: Boolean = true,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(if (enabled) PinkPrimary.copy(alpha = 0.12f) else Color.Gray.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = if (enabled) PinkPrimary else Color.Gray,
                    modifier = Modifier.size(18.dp)
                )
            }

            Column(modifier = Modifier.padding(end = 8.dp)) {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.5.sp,
                    color = if (enabled) MaterialTheme.colorScheme.onBackground else Color.Gray
                )
                Text(
                    text = subtitle,
                    fontSize = 10.5.sp,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                    lineHeight = 14.sp
                )
            }
        }

        Switch(
            checked = checked,
            enabled = enabled,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = PinkPrimary,
                checkedTrackColor = PinkPrimary.copy(alpha = 0.3f)
            )
        )
    }
}

@Composable
private fun BookingHistorySubSection(
    savedBookings: List<BookingEntity>,
    currentLanguage: Language,
    onCancelBooking: (Int) -> Unit,
    onUpdateBookingStatus: (Int, String) -> Unit,
    onDeleteBooking: (Int) -> Unit,
    onSeedSampleBookings: () -> Unit,
    onViewInvoice: ((BookingEntity) -> Unit)?,
    onShowToast: (String) -> Unit
) {
    var selectedFilter by remember { mutableStateOf("ALL") } // ALL, UPCOMING, COMPLETED, CANCELLED
    var searchQuery by remember { mutableStateOf("") }
    var bookingToCancel by remember { mutableStateOf<BookingEntity?>(null) }

    val filteredBookings = remember(savedBookings, selectedFilter, searchQuery) {
        savedBookings.filter { booking ->
            val matchesFilter = when (selectedFilter) {
                "UPCOMING" -> booking.status.equals("CONFIRMED", ignoreCase = true) || booking.status.equals("PENDING", ignoreCase = true)
                "COMPLETED" -> booking.status.equals("COMPLETED", ignoreCase = true)
                "CANCELLED" -> booking.status.equals("CANCELLED", ignoreCase = true)
                else -> true
            }
            val matchesSearch = searchQuery.isBlank() ||
                    booking.title.contains(searchQuery, ignoreCase = true) ||
                    booking.bookingId.contains(searchQuery, ignoreCase = true) ||
                    booking.village.contains(searchQuery, ignoreCase = true) ||
                    booking.district.contains(searchQuery, ignoreCase = true) ||
                    booking.category.contains(searchQuery, ignoreCase = true)
            matchesFilter && matchesSearch
        }
    }

    val totalCount = savedBookings.size
    val upcomingCount = savedBookings.count { it.status.equals("CONFIRMED", ignoreCase = true) || it.status.equals("PENDING", ignoreCase = true) }
    val completedCount = savedBookings.count { it.status.equals("COMPLETED", ignoreCase = true) }
    val cancelledCount = savedBookings.count { it.status.equals("CANCELLED", ignoreCase = true) }

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Top Banner / Statistics Card
        GlassCard(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            elevation = 4.dp
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (currentLanguage == Language.TAMIL) "எனது முன்பதிவு வரலாறு" else "Booking History & Events",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = if (currentLanguage == Language.TAMIL) "கடந்த மற்றும் வரவிருக்கும் நிகழ்வுகள்" else "Past & upcoming event hall & service bookings",
                            fontSize = 11.5.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                        )
                    }

                    OutlinedButton(
                        onClick = { onSeedSampleBookings() },
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp), tint = PinkPrimary)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (savedBookings.isEmpty()) "Load Sample Data" else "Reset Test Data", fontSize = 11.sp, color = PinkPrimary)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Stats Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatBadge(label = "Total", value = "$totalCount", color = PinkPrimary, modifier = Modifier.weight(1f))
                    StatBadge(label = "Upcoming", value = "$upcomingCount", color = Color(0xFF059669), modifier = Modifier.weight(1f))
                    StatBadge(label = "Completed", value = "$completedCount", color = Color(0xFF4F46E5), modifier = Modifier.weight(1f))
                    StatBadge(label = "Cancelled", value = "$cancelledCount", color = Color(0xFFDC2626), modifier = Modifier.weight(1f))
                }
            }
        }

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Search by title, ID, village or category...", fontSize = 12.5.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = PinkPrimary) },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = PinkPrimary,
                unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
            )
        )

        // Filter Chips Row
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            val filters = listOf(
                "ALL" to "All ($totalCount)",
                "UPCOMING" to "Upcoming ($upcomingCount)",
                "COMPLETED" to "Completed ($completedCount)",
                "CANCELLED" to "Cancelled ($cancelledCount)"
            )

            items(filters) { (key, label) ->
                val isSelected = selectedFilter == key
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isSelected) PinkPrimary else MaterialTheme.colorScheme.surface)
                        .border(
                            width = 1.dp,
                            color = if (isSelected) PinkPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                            shape = RoundedCornerShape(20.dp)
                        )
                        .clickable { selectedFilter = key }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = label,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onBackground
                    )
                }
            }
        }

        // Scrollable Bookings List
        if (filteredBookings.isEmpty()) {
            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.EventAvailable,
                        contentDescription = null,
                        modifier = Modifier.size(48.dp),
                        tint = PinkPrimary.copy(alpha = 0.6f)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "No Bookings Found",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (savedBookings.isEmpty()) "You haven't made any event or service bookings yet." else "No bookings match your current filter or search query.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                        textAlign = TextAlign.Center
                    )
                    if (savedBookings.isEmpty()) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { onSeedSampleBookings() },
                            colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Load Sample History")
                        }
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 80.dp)
            ) {
                items(filteredBookings, key = { it.id }) { booking ->
                    BookingHistoryCard(
                        booking = booking,
                        onCancelClick = { bookingToCancel = booking },
                        onDeleteClick = { onDeleteBooking(booking.id) },
                        onUpdateStatus = { status -> onUpdateBookingStatus(booking.id, status) },
                        onViewInvoice = onViewInvoice
                    )
                }
            }
        }
    }

    // Cancellation Confirmation Dialog
    if (bookingToCancel != null) {
        val target = bookingToCancel!!
        AlertDialog(
            onDismissRequest = { bookingToCancel = null },
            title = {
                Text(
                    text = "Cancel Event Booking?",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "Are you sure you want to cancel booking #${target.bookingId} for \"${target.title}\"?",
                        fontSize = 13.5.sp
                    )
                    Text(
                        text = "• Event Date: ${target.bookingDate}\n• Location: ${target.village}, ${target.district}\n• Total Amount: ${target.totalPrice}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "The vendor and village agent will be notified of this cancellation immediately.",
                        fontSize = 11.5.sp,
                        color = Color(0xFFDC2626),
                        fontWeight = FontWeight.SemiBold
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onCancelBooking(target.id)
                        bookingToCancel = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Confirm Cancellation", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { bookingToCancel = null },
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Keep Booking")
                }
            },
            shape = RoundedCornerShape(20.dp)
        )
    }
}

@Composable
private fun StatBadge(
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(color.copy(alpha = 0.12f))
            .padding(vertical = 8.dp, horizontal = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = value,
                fontWeight = FontWeight.Black,
                fontSize = 16.sp,
                color = color
            )
            Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                color = color
            )
        }
    }
}

@Composable
private fun BookingHistoryCard(
    booking: BookingEntity,
    onCancelClick: () -> Unit,
    onDeleteClick: () -> Unit,
    onUpdateStatus: (String) -> Unit,
    onViewInvoice: ((BookingEntity) -> Unit)?
) {
    val statusUpper = booking.status.uppercase()

    val badgeBg = when (statusUpper) {
        "CONFIRMED" -> Color(0xFFD1FAE5)
        "PENDING" -> Color(0xFFFEF3C7)
        "COMPLETED" -> Color(0xFFE0E7FF)
        "CANCELLED" -> Color(0xFFFEE2E2)
        else -> Color(0xFFF3F4F6)
    }

    val badgeColor = when (statusUpper) {
        "CONFIRMED" -> Color(0xFF059669)
        "PENDING" -> Color(0xFFD97706)
        "COMPLETED" -> Color(0xFF4F46E5)
        "CANCELLED" -> Color(0xFFDC2626)
        else -> Color.DarkGray
    }

    val badgeIcon = when (statusUpper) {
        "CONFIRMED" -> Icons.Default.CheckCircle
        "PENDING" -> Icons.Default.Pending
        "COMPLETED" -> Icons.Default.CheckCircle
        "CANCELLED" -> Icons.Default.Cancel
        else -> Icons.Default.Info
    }

    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        elevation = 4.dp
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Row: Booking ID + Category Icon + Status Label
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(PinkPrimary.copy(alpha = 0.15f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "#${booking.bookingId}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp,
                            color = PinkPrimary
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = booking.category.replaceFirstChar { it.uppercase() },
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                }

                // Status Badge
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(badgeBg)
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = badgeIcon,
                            contentDescription = null,
                            tint = badgeColor,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = statusUpper,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = badgeColor
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Venue / Event Title
            Text(
                text = booking.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Date & Time Slot
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.CalendarToday,
                    contentDescription = null,
                    tint = PinkPrimary,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "${booking.bookingDate}  •  ${booking.timeSlot}",
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.85f)
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Location & Guests
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.LocationOn,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "${booking.village}, ${booking.district}  •  👥 ${booking.guestCount}",
                    fontSize = 11.5.sp,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
            Spacer(modifier = Modifier.height(10.dp))

            // Bottom Row: Price + Payment Method + Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Total Price",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = booking.totalPrice,
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "(${booking.paymentMethod})",
                            fontSize = 10.5.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                        )
                    }
                }

                // Action Buttons Row
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (onViewInvoice != null) {
                        IconButton(
                            onClick = { onViewInvoice(booking) },
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.surface)
                                .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ReceiptLong,
                                contentDescription = "View Invoice",
                                tint = PinkPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    if (statusUpper == "CONFIRMED" || statusUpper == "PENDING") {
                        OutlinedButton(
                            onClick = onCancelClick,
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDC2626)),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFDC2626).copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Cancel,
                                contentDescription = null,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Cancel Booking",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    } else if (statusUpper == "CANCELLED") {
                        OutlinedButton(
                            onClick = onDeleteClick,
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.3f)),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = null,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Remove",
                                fontSize = 11.5.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

