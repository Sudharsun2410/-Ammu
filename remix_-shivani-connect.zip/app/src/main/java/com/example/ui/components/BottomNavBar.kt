package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Language
import com.example.ui.theme.PinkPrimary
import com.example.ui.theme.PinkSecondary
import com.example.ui.theme.PurplePrimary

data class NavItem(
    val index: Int,
    val titleEn: String,
    val titleTa: String,
    val iconEmoji: String
)

val leftNavItems = listOf(
    NavItem(0, "Home", "முகப்பு", "🏠"),
    NavItem(1, "Event", "நிகழ்வுகள்", "🎪")
)

val rightNavItems = listOf(
    NavItem(2, "Work", "வேலை", "💼"),
    NavItem(3, "Store", "சந்தை", "🛒")
)

@Composable
fun BottomNavBar(
    selectedTab: Int,
    currentLanguage: Language,
    onTabSelected: (Int) -> Unit,
    onAddClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars),
        contentAlignment = Alignment.BottomCenter
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 760.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(16.dp, RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                    .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                    .padding(vertical = 8.dp, horizontal = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Left Items: Home, Event
                    leftNavItems.forEach { item ->
                        NavItemView(
                            item = item,
                            isSelected = selectedTab == item.index,
                            currentLanguage = currentLanguage,
                            onClick = { onTabSelected(item.index) }
                        )
                    }

                    // Center Spacer for Floating FAB
                    Spacer(modifier = Modifier.size(52.dp))

                    // Right Items: Map, Store
                    rightNavItems.forEach { item ->
                        NavItemView(
                            item = item,
                            isSelected = selectedTab == item.index,
                            currentLanguage = currentLanguage,
                            onClick = { onTabSelected(item.index) }
                        )
                    }
                }
            }

            // Center Floating Action Button (+)
            FloatingActionButton(
                onClick = onAddClick,
                shape = CircleShape,
                containerColor = Color.Transparent,
                elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 8.dp),
                modifier = Modifier
                    .offset(y = (-20).dp)
                    .size(58.dp)
                    .shadow(12.dp, CircleShape)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(PinkPrimary, PurplePrimary)))
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Create Event & Category Quick Action",
                    tint = Color.White,
                    modifier = Modifier.size(28.dp)
                )
            }
        }
    }
}

@Composable
private fun NavItemView(
    item: NavItem,
    isSelected: Boolean,
    currentLanguage: Language,
    onClick: () -> Unit
) {
    val isHomeTab = item.index == 0
    val isEventTab = item.index == 1
    val isWorkTab = item.index == 2
    val isStoreTab = item.index == 3

    val animatedBg by animateColorAsState(
        targetValue = when {
            isHomeTab && isSelected -> Color(0xFFFFE4E6)
            isHomeTab -> Color(0xFFFFF1F2)
            isWorkTab && isSelected -> Color(0xFFD1FAE5)
            isWorkTab -> Color(0xFFECFDF5)
            isStoreTab && isSelected -> Color(0xFFFEF3C7)
            isStoreTab -> Color(0xFFFFFBEB)
            isEventTab && isSelected -> PinkPrimary.copy(alpha = 0.22f)
            isEventTab -> Color(0xFFFFEFF3)
            isSelected -> PinkPrimary.copy(alpha = 0.15f)
            else -> Color.Transparent
        },
        label = "NavBg"
    )

    val borderColor = when {
        isHomeTab && isSelected -> Color(0xFFE11D48)
        isHomeTab -> Color(0xFFFDA4AF)
        isWorkTab && isSelected -> Color(0xFF059669)
        isWorkTab -> Color(0xFF6EE7B7)
        isStoreTab && isSelected -> Color(0xFFD97706)
        isStoreTab -> Color(0xFFFDE68A)
        isEventTab && isSelected -> PinkPrimary
        isEventTab -> PinkPrimary.copy(alpha = 0.35f)
        isSelected -> PinkPrimary
        else -> Color.Transparent
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(animatedBg)
            .border(
                1.2.dp,
                borderColor,
                RoundedCornerShape(16.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(
                    when {
                        isHomeTab && isSelected -> Brush.linearGradient(listOf(Color(0xFFE11D48), Color(0xFFF43F5E)))
                        isHomeTab -> SolidColor(Color(0xFFFFE4E6))
                        isWorkTab && isSelected -> Brush.linearGradient(listOf(Color(0xFF059669), Color(0xFF10B981)))
                        isWorkTab -> SolidColor(Color(0xFFD1FAE5))
                        isStoreTab && isSelected -> Brush.linearGradient(listOf(Color(0xFFF59E0B), Color(0xFFD97706)))
                        isStoreTab -> SolidColor(Color(0xFFFEF3C7))
                        isEventTab && isSelected -> Brush.linearGradient(listOf(PinkPrimary, PurplePrimary))
                        isSelected -> SolidColor(PinkPrimary)
                        else -> SolidColor(Color.Transparent)
                    }
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = item.iconEmoji,
                fontSize = if (isHomeTab || isWorkTab || isStoreTab || isEventTab) 17.sp else 16.sp
            )
        }

        Spacer(modifier = Modifier.height(2.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            if (isHomeTab || isWorkTab || isStoreTab || isEventTab) {
                Box(
                    modifier = Modifier
                        .size(5.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                isHomeTab -> Color(0xFFE11D48)
                                isWorkTab -> Color(0xFF059669)
                                isStoreTab -> Color(0xFFD97706)
                                else -> Color(0xFFE11D48)
                            }
                        )
                )
                Spacer(modifier = Modifier.width(3.dp))
            }
            Text(
                text = if (currentLanguage == Language.TAMIL) item.titleTa else item.titleEn,
                fontSize = 11.sp,
                fontWeight = if (isSelected || isHomeTab || isWorkTab || isStoreTab || isEventTab) FontWeight.Black else FontWeight.Bold,
                color = when {
                    isHomeTab -> Color(0xFFBE123C)
                    isWorkTab -> Color(0xFF047857)
                    isStoreTab -> Color(0xFFB45309)
                    isSelected || isEventTab -> PinkPrimary
                    else -> MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                }
            )
        }
    }
}

