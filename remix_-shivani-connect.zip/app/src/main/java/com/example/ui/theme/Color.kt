package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Shivani Connect - White + Pink + Purple Gradient Premium Glassmorphism Palette
val PinkPrimary = Color(0xFFE91E63)        // Vibrant Pink 500
val PinkSecondary = Color(0xFF9C27B0)      // Deep Purple 500
val PinkDark = Color(0xFFC2185B)           // Dark Pink 700
val PinkLight = Color(0xFFFCE4EC)          // Soft Pink 50
val PinkBackground = Color(0xFFFAFAFD)     // Off-white soft background

val PurplePrimary = Color(0xFF8E24AA)      // Purple Accent
val PurpleLight = Color(0xFFF3E5F5)        // Light Purple 50
val PurpleGradientEnd = Color(0xFF7B1FA2)  // Deep Purple 700

val GoldPrimary = Color(0xFFD4AF37)        // Classic Gold Accent
val GoldAccent = Color(0xFFF59E0B)         // Amber Gold
val GoldDark = Color(0xFFB45309)           // Deep Gold / Amber

// Legacy Alias Mappings for Theme Harmony
val SkyBluePrimary = PinkPrimary
val SkyBlueSecondary = PinkSecondary
val SkyBlueDark = PinkDark

val SoftWhiteGlass = Color(0xF0FFFFFF)     // High opacity glassmorphism white
val UltraWhiteGlass = Color(0xF8FFFFFF)    // Pure white glass card surface
val GlassBorder = Color(0x33E91E63)        // Translucent pink border highlight
val GlassBorderDark = Color(0x339C27B0)    // Translucent purple border accent

// Text colors
val TextDark = Color(0xFF1E293B)         // Slate 800
val TextMuted = Color(0xFF64748B)        // Slate 500
val TextLight = Color(0xFF94A3B8)        // Slate 400

// Dark Mode Glass Palette
val DarkBackground = Color(0xFF120917)    // Deep Midnight Purple Canvas
val DarkGlassSurface = Color(0xEA24122C)  // Dark Purple Translucent Surface
val DarkGlassBorder = Color(0x40E91E63)   // Soft Pink Glow Border
val DarkTextPrimary = Color(0xFFF8FAFC)
val DarkTextMuted = Color(0xFF94A3B8)

