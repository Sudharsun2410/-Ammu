package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.StarHalf
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

@Composable
fun StarRating(
    rating: Double,
    modifier: Modifier = Modifier,
    maxStars: Int = 5,
    starSize: Dp = 14.dp,
    starColor: Color = Color(0xFFF59E0B),
    unfilledColor: Color = Color(0xFFCBD5E1),
    showRatingNumber: Boolean = true,
    reviewCount: Int? = null,
    textColor: Color = MaterialTheme.colorScheme.onBackground,
    fontSize: TextUnit = 12.sp,
    onRatingSelected: ((Int) -> Unit)? = null
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Start
    ) {
        // Draw 5 Stars
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(1.dp)
        ) {
            for (i in 1..maxStars) {
                val isClickable = onRatingSelected != null
                val starModifier = Modifier
                    .size(starSize)
                    .then(
                        if (isClickable) {
                            Modifier.clickable { onRatingSelected?.invoke(i) }
                        } else Modifier
                    )

                when {
                    rating >= i -> {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Full Star $i",
                            tint = starColor,
                            modifier = starModifier
                        )
                    }
                    rating >= i - 0.5 -> {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.StarHalf,
                            contentDescription = "Half Star $i",
                            tint = starColor,
                            modifier = starModifier
                        )
                    }
                    else -> {
                        Icon(
                            imageVector = Icons.Outlined.StarOutline,
                            contentDescription = "Empty Star $i",
                            tint = unfilledColor,
                            modifier = starModifier
                        )
                    }
                }
            }
        }

        if (showRatingNumber || reviewCount != null) {
            Spacer(modifier = Modifier.width(4.dp))
        }

        if (showRatingNumber) {
            val formattedScore = String.format(Locale.US, "%.1f", rating)
            Text(
                text = formattedScore,
                fontSize = fontSize,
                fontWeight = FontWeight.Bold,
                color = textColor
            )
        }

        if (reviewCount != null) {
            Spacer(modifier = Modifier.width(3.dp))
            Text(
                text = "($reviewCount)",
                fontSize = (fontSize.value * 0.9f).sp,
                color = textColor.copy(alpha = 0.65f),
                fontWeight = FontWeight.Medium
            )
        }
    }
}
