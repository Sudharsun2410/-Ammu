package com.example.ui.components

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Lan
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.PinkPrimary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class ThermalDevice(
    val name: String,
    val address: String,
    val type: String, // "Bluetooth", "USB", or "Network"
    val isConnected: Boolean = false
)

@Composable
fun ThermalPrinterDialog(
    onDismissRequest: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var selectedConnectionType by remember { mutableStateOf("Bluetooth") } // "Bluetooth", "USB", "Network"
    var isScanning by remember { mutableStateOf(false) }
    var selectedPaperWidth by remember { mutableStateOf("58mm") } // "58mm" or "80mm"
    var autoPrintEnabled by remember { mutableStateOf(true) }
    var isTestPrinting by remember { mutableStateOf(false) }

    // Network printer configuration fields
    var networkIpAddress by remember { mutableStateOf("192.168.1.100") }
    var networkPort by remember { mutableStateOf("9100") }

    var connectedDevice by remember {
        mutableStateOf<ThermalDevice?>(
            ThermalDevice("POS-58 Thermal BT", "00:11:22:33:44:55", "Bluetooth", isConnected = true)
        )
    }

    var devicesList by remember {
        mutableStateOf(
            listOf(
                ThermalDevice("POS-58 Thermal BT", "00:11:22:33:44:55", "Bluetooth", isConnected = true),
                ThermalDevice("Everycom 80mm ESC/POS", "00:1B:35:88:99:AA", "Bluetooth", isConnected = false),
                ThermalDevice("TVS RP-3150 STAR", "USB_PORT_01", "USB", isConnected = false),
                ThermalDevice("Epson TM-T88VI LAN", "192.168.1.100:9100", "Network", isConnected = false)
            )
        )
    }

    Dialog(onDismissRequest = onDismissRequest) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp),
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp)
            ) {
                // Header Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(PinkPrimary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Print,
                                contentDescription = "Thermal Printer Settings",
                                tint = PinkPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Column {
                            Text(
                                text = "Thermal Printer Setup",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "ESC/POS Bluetooth, USB & LAN/Wi-Fi",
                                fontSize = 11.sp,
                                color = PinkPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    IconButton(onClick = onDismissRequest) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Connection Mode Selector Tabs (Bluetooth / USB / Network)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf(
                        Triple("Bluetooth", Icons.Default.Bluetooth, "BT"),
                        Triple("USB", Icons.Default.Usb, "USB"),
                        Triple("Network", Icons.Default.Lan, "Wi-Fi/LAN")
                    ).forEach { (mode, icon, label) ->
                        val isSelected = selectedConnectionType == mode
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) PinkPrimary else Color.Transparent)
                                .clickable { selectedConnectionType = mode }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = null,
                                    tint = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(15.dp)
                                )
                                Text(
                                    text = label,
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Active Printer Connection Status Banner
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            if (connectedDevice != null) Color(0xFFDCFCE7) else Color(0xFFFEE2E2)
                        )
                        .border(
                            1.dp,
                            if (connectedDevice != null) Color(0xFF16A34A) else Color(0xFFEF4444),
                            RoundedCornerShape(16.dp)
                        )
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = when (connectedDevice?.type) {
                                    "USB" -> Icons.Default.Usb
                                    "Network" -> Icons.Default.Lan
                                    else -> Icons.Default.Bluetooth
                                },
                                contentDescription = null,
                                tint = if (connectedDevice != null) Color(0xFF15803D) else Color(0xFFB91C1C)
                            )

                            Column {
                                Text(
                                    text = connectedDevice?.name ?: "No Printer Connected",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = if (connectedDevice != null) Color(0xFF14532D) else Color(0xFF7F1D1D)
                                )
                                Text(
                                    text = connectedDevice?.let { "Status: Online • ${it.type} (${it.address})" } ?: "Configure or scan printer below",
                                    fontSize = 10.sp,
                                    color = if (connectedDevice != null) Color(0xFF166534) else Color(0xFF991B1B)
                                )
                            }
                        }

                        if (connectedDevice != null) {
                            Box(
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(Color(0xFF16A34A))
                                    .padding(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "Connected",
                                    tint = Color.White,
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Network IP Input View (Visible only when "Network" tab is selected)
                if (selectedConnectionType == "Network") {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = "🌐 Wi-Fi / LAN Network Printer Address",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = PinkPrimary
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = networkIpAddress,
                                onValueChange = { networkIpAddress = it },
                                label = { Text("IP Address", fontSize = 10.sp) },
                                singleLine = true,
                                modifier = Modifier.weight(2f),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = PinkPrimary,
                                    unfocusedBorderColor = Color.LightGray
                                )
                            )

                            OutlinedTextField(
                                value = networkPort,
                                onValueChange = { networkPort = it },
                                label = { Text("Port", fontSize = 10.sp) },
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = PinkPrimary,
                                    unfocusedBorderColor = Color.LightGray
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Button(
                            onClick = {
                                val netDev = ThermalDevice(
                                    name = "LAN Thermal Printer",
                                    address = "$networkIpAddress:$networkPort",
                                    type = "Network",
                                    isConnected = true
                                )
                                connectedDevice = netDev
                                Toast.makeText(context, "Connected to Network Printer $networkIpAddress:$networkPort", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Connect Network Printer", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                }

                // Settings Toggles: Paper Roll & Auto-Print
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Paper Width Switcher
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            .padding(10.dp)
                    ) {
                        Text(
                            text = "Paper Roll Width",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf("58mm", "80mm").forEach { width ->
                                val selected = selectedPaperWidth == width
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (selected) PinkPrimary else Color.Transparent)
                                        .clickable { selectedPaperWidth = width }
                                        .padding(vertical = 6.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = width,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }

                    // Auto-Print Toggle
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            .padding(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Auto-Print Receipt",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Switch(
                                checked = autoPrintEnabled,
                                onCheckedChange = { autoPrintEnabled = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = PinkPrimary),
                                modifier = Modifier.size(32.dp)
                            )
                        }
                        Text(
                            text = if (autoPrintEnabled) "Enabled on Booking" else "Manual Print Only",
                            fontSize = 9.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Available Devices Section Header (Filtered by selected mode)
                val filteredDevices = devicesList.filter { it.type == selectedConnectionType }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Discovered $selectedConnectionType Devices",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(PinkPrimary.copy(alpha = 0.1f))
                            .clickable {
                                isScanning = true
                                coroutineScope.launch {
                                    delay(1200)
                                    isScanning = false
                                    Toast.makeText(context, "Scan finished. Found devices.", Toast.LENGTH_SHORT).show()
                                }
                            }
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (isScanning) {
                            CircularProgressIndicator(modifier = Modifier.size(12.dp), strokeWidth = 2.dp, color = PinkPrimary)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Scanning...", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = PinkPrimary)
                        } else {
                            Icon(imageVector = Icons.Default.Refresh, contentDescription = null, tint = PinkPrimary, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Scan", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = PinkPrimary)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Device List
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(filteredDevices) { device ->
                        val isConnected = connectedDevice?.address == device.address
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (isConnected) PinkPrimary.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                                .border(1.dp, if (isConnected) PinkPrimary else Color.Transparent, RoundedCornerShape(14.dp))
                                .clickable {
                                    if (isConnected) {
                                        connectedDevice = null
                                        Toast.makeText(context, "Disconnected ${device.name}", Toast.LENGTH_SHORT).show()
                                    } else {
                                        connectedDevice = device.copy(isConnected = true)
                                        Toast.makeText(context, "Connected to ${device.name}", Toast.LENGTH_SHORT).show()
                                    }
                                }
                                .padding(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = when (device.type) {
                                            "USB" -> Icons.Default.Usb
                                            "Network" -> Icons.Default.Lan
                                            else -> Icons.Default.Bluetooth
                                        },
                                        contentDescription = null,
                                        tint = if (isConnected) PinkPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Column {
                                        Text(
                                            text = device.name,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = "${device.type} • ${device.address}",
                                            fontSize = 9.5.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                Text(
                                    text = if (isConnected) "Disconnect" else "Connect",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isConnected) Color.Red else PinkPrimary
                                )
                            }
                        }
                    }

                    if (filteredDevices.isEmpty()) {
                        item {
                            Text(
                                text = "No $selectedConnectionType printers listed. Tap Scan to search.",
                                fontSize = 11.sp,
                                color = Color.Gray,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Test Print Actions Row (Test Receipt, Cut Paper, Feed Line)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            if (connectedDevice == null) {
                                Toast.makeText(context, "Please connect a thermal printer first!", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            isTestPrinting = true
                            coroutineScope.launch {
                                delay(1000)
                                isTestPrinting = false
                                Toast.makeText(
                                    context,
                                    "🖨️ ESC/POS Test Receipt Printed to ${connectedDevice?.name} ($selectedPaperWidth)!",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        },
                        modifier = Modifier.weight(2f),
                        colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary, contentColor = Color.White),
                        shape = RoundedCornerShape(14.dp),
                        enabled = !isTestPrinting
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            if (isTestPrinting) {
                                CircularProgressIndicator(modifier = Modifier.size(14.dp), color = Color.White, strokeWidth = 2.dp)
                            } else {
                                Icon(imageVector = Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                            }
                            Text("Print Test Receipt", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Button(
                        onClick = {
                            Toast.makeText(context, "✂️ ESC/POS Paper Cut Command Sent", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.ContentCut,
                                contentDescription = "Cut",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Cut", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // ESC/POS Preview Slip Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFFEF9C3))
                        .border(1.dp, Color(0xFFFACC15), RoundedCornerShape(12.dp))
                        .padding(10.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "RECEIPT PREVIEW (ESC/POS)",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Black,
                            color = Color(0xFF854D0E),
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = """
                            ==============================
                                    SHIVANI HUB
                             CONNECT • SERVE • GROW
                            ==============================
                            Date: 2026-07-27   Ref: #SH-8842
                            Event: Sri Lakshmi Kalyana Mahal
                            Loc: Alanganallur, Madurai
                            Amount Paid: ₹35,000.00 [PAID]
                            Conn: ${connectedDevice?.type ?: "None"} ($selectedPaperWidth)
                            ==============================
                               Thank you for choosing us!
                            ==============================
                            """.trimIndent(),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 8.5.sp,
                            color = Color(0xFF713F12),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

