package com.example.ui.components

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Language
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.PinkDark
import com.example.ui.theme.PinkPrimary
import com.example.ui.theme.PinkSecondary

data class RegionalLocationMarker(
    val id: String,
    val nameEn: String,
    val nameTa: String,
    val districtEn: String,
    val venueTitleEn: String,
    val venueTitleTa: String,
    val mapUrl: String,
    val emoji: String,
    val rating: Float,
    val price: String,
    val phone: String,
    val canvasOffsetRatio: Offset,
    val markerColor: Color
)

object RegionalLocationsData {
    val locations = listOf(
        RegionalLocationMarker(
            id = "harur",
            nameEn = "Harur",
            nameTa = "ஹரூர்",
            districtEn = "Dharmapuri District",
            venueTitleEn = "Harur Royal Marriage Mahal & Catering",
            venueTitleTa = "ஹரூர் ராயல் திருமண மஹால் & கேட்டரிங்",
            mapUrl = "https://maps.app.goo.gl/VAn6vQPq6Qb3Jy829",
            emoji = "🏰",
            rating = 4.8f,
            price = "₹25,000 / day",
            phone = "+91 94432 12345",
            canvasOffsetRatio = Offset(0.42f, 0.28f),
            markerColor = Color(0xFFEC4899)
        ),
        RegionalLocationMarker(
            id = "dharmapuri",
            nameEn = "Dharmapuri",
            nameTa = "தர்மபுரி",
            districtEn = "District Headquarters",
            venueTitleEn = "Sri Murugan Caterers & Convention Hall",
            venueTitleTa = "ஸ்ரீ முருகன் சமையல் & மண்டபம்",
            mapUrl = "https://maps.app.goo.gl/SSPhEhtgKi2o8qA97",
            emoji = "🍲",
            rating = 4.9f,
            price = "₹220 / leaf",
            phone = "+91 97865 43210",
            canvasOffsetRatio = Offset(0.32f, 0.25f),
            markerColor = Color(0xFFF59E0B)
        ),
        RegionalLocationMarker(
            id = "salem",
            nameEn = "Salem",
            nameTa = "சேலம்",
            districtEn = "Salem Royal District",
            venueTitleEn = "Salem Royal Palace & Grand Banquet",
            venueTitleTa = "சேலம் ராயல் பேலஸ் & பேங்க்வெட்",
            mapUrl = "https://maps.app.goo.gl/6RA4HBz7Q4WgkkGp9",
            emoji = "👑",
            rating = 5.0f,
            price = "₹65,000 / day",
            phone = "+91 98427 12345",
            canvasOffsetRatio = Offset(0.38f, 0.38f),
            markerColor = Color(0xFF8B5CF6)
        ),
        RegionalLocationMarker(
            id = "chennai",
            nameEn = "Chennai",
            nameTa = "சென்னை",
            districtEn = "Capital District",
            venueTitleEn = "Chennai Central Grand Convention Palace",
            venueTitleTa = "சென்னை சென்ட்ரல் கிராண்ட் பேலஸ்",
            mapUrl = "https://www.google.com/maps/search/?api=1&query=Chennai+Tamil+Nadu",
            emoji = "🏙️",
            rating = 4.9f,
            price = "₹1,20,000 / day",
            phone = "+91 98400 11223",
            canvasOffsetRatio = Offset(0.78f, 0.12f),
            markerColor = Color(0xFF3B82F6)
        ),
        RegionalLocationMarker(
            id = "coimbatore",
            nameEn = "Coimbatore",
            nameTa = "கோவை",
            districtEn = "Kovai District",
            venueTitleEn = "Kovai Royal Mahal & Convention Hall",
            venueTitleTa = "கோவை ராயல் மஹால் & அரங்கம்",
            mapUrl = "https://www.google.com/maps/search/?api=1&query=Coimbatore+Tamil+Nadu",
            emoji = "⛰️",
            rating = 4.9f,
            price = "₹85,000 / day",
            phone = "+91 98940 33445",
            canvasOffsetRatio = Offset(0.18f, 0.45f),
            markerColor = Color(0xFF10B981)
        ),
        RegionalLocationMarker(
            id = "madurai",
            nameEn = "Madurai",
            nameTa = "மதுரை",
            districtEn = "Temple City District",
            venueTitleEn = "Madurai Meenakshi Palace & Banquet",
            venueTitleTa = "மதுரை மீனாட்சி பேலஸ் & மஹால்",
            mapUrl = "https://www.google.com/maps/search/?api=1&query=Madurai+Tamil+Nadu",
            emoji = "🏛️",
            rating = 4.8f,
            price = "₹55,000 / day",
            phone = "+91 98421 55667",
            canvasOffsetRatio = Offset(0.38f, 0.68f),
            markerColor = Color(0xFFEF4444)
        ),
        RegionalLocationMarker(
            id = "trichy",
            nameEn = "Trichy",
            nameTa = "திருச்சி",
            districtEn = "Rockfort District",
            venueTitleEn = "Trichy Rockfort Grand Mahal",
            venueTitleTa = "திருச்சி மலைக்கோட்டை கிராண்ட் மஹால்",
            mapUrl = "https://www.google.com/maps/search/?api=1&query=Tiruchirappalli+Tamil+Nadu",
            emoji = "🏰",
            rating = 4.7f,
            price = "₹50,000 / day",
            phone = "+91 94431 77889",
            canvasOffsetRatio = Offset(0.48f, 0.50f),
            markerColor = Color(0xFF06B6D4)
        ),
        RegionalLocationMarker(
            id = "tirunelveli",
            nameEn = "Tirunelveli",
            nameTa = "திருநெல்வேலி",
            districtEn = "Nellaiappar District",
            venueTitleEn = "Tirunelveli Nellaiappar Convention Palace",
            venueTitleTa = "திருநெல்வேலி நெல்லையப்பர் பேலஸ்",
            mapUrl = "https://www.google.com/maps/search/?api=1&query=Tirunelveli+Tamil+Nadu",
            emoji = "🌴",
            rating = 4.8f,
            price = "₹45,000 / day",
            phone = "+91 94422 99001",
            canvasOffsetRatio = Offset(0.32f, 0.82f),
            markerColor = Color(0xFF84CC16)
        ),
        RegionalLocationMarker(
            id = "erode",
            nameEn = "Erode",
            nameTa = "ஈரோடு",
            districtEn = "Textile Hub District",
            venueTitleEn = "Erode Textile City Mahal & Convention",
            venueTitleTa = "ஈரோடு டெக்ஸ்டைல் சிட்டி மஹால்",
            mapUrl = "https://www.google.com/maps/search/?api=1&query=Erode+Tamil+Nadu",
            emoji = "🌿",
            rating = 4.7f,
            price = "₹40,000 / day",
            phone = "+91 98428 11223",
            canvasOffsetRatio = Offset(0.28f, 0.38f),
            markerColor = Color(0xFF14B8A6)
        ),
        RegionalLocationMarker(
            id = "vellore",
            nameEn = "Vellore",
            nameTa = "வேலூர்",
            districtEn = "Fort City District",
            venueTitleEn = "Vellore Fort Royal Mahal & Gardens",
            venueTitleTa = "வேலூர் கோட்டை ராயல் மஹால்",
            mapUrl = "https://www.google.com/maps/search/?api=1&query=Vellore+Tamil+Nadu",
            emoji = "🛡️",
            rating = 4.8f,
            price = "₹60,000 / day",
            phone = "+91 94433 44556",
            canvasOffsetRatio = Offset(0.62f, 0.15f),
            markerColor = Color(0xFF6366F1)
        ),
        RegionalLocationMarker(
            id = "thanjavur",
            nameEn = "Thanjavur",
            nameTa = "தஞ்சாவூர்",
            districtEn = "Chola Dynasty Kingdom",
            venueTitleEn = "Tanjore Chola Kingdom Grand Palace",
            venueTitleTa = "தஞ்சாவூர் சோழா பேலஸ்",
            mapUrl = "https://www.google.com/maps/search/?api=1&query=Thanjavur+Tamil+Nadu",
            emoji = "🛕",
            rating = 4.9f,
            price = "₹55,000 / day",
            phone = "+91 94434 66778",
            canvasOffsetRatio = Offset(0.58f, 0.55f),
            markerColor = Color(0xFFD97706)
        ),
        RegionalLocationMarker(
            id = "kanchipuram",
            nameEn = "Kanchipuram",
            nameTa = "காஞ்சிபுரம்",
            districtEn = "Silk City District",
            venueTitleEn = "Silk City Kanchi Royal Mahal",
            venueTitleTa = "காஞ்சிபுரம் சில்க் சிட்டி மஹால்",
            mapUrl = "https://www.google.com/maps/search/?api=1&query=Kanchipuram+Tamil+Nadu",
            emoji = "🥻",
            rating = 4.9f,
            price = "₹70,000 / day",
            phone = "+91 98402 88990",
            canvasOffsetRatio = Offset(0.70f, 0.18f),
            markerColor = Color(0xFFA855F7)
        ),
        RegionalLocationMarker(
            id = "kanyakumari",
            nameEn = "Kanyakumari",
            nameTa = "கன்னியாகுமரி",
            districtEn = "Southern Tip District",
            venueTitleEn = "Kanyakumari Ocean View Palace & Resort",
            venueTitleTa = "கன்னியாகுமரி ஓஷன் வியூ பேலஸ்",
            mapUrl = "https://www.google.com/maps/search/?api=1&query=Kanyakumari+Tamil+Nadu",
            emoji = "🌊",
            rating = 4.9f,
            price = "₹75,000 / day",
            phone = "+91 94421 22334",
            canvasOffsetRatio = Offset(0.30f, 0.92f),
            markerColor = Color(0xFF0284C7)
        ),
        RegionalLocationMarker(
            id = "krishnagiri",
            nameEn = "Krishnagiri",
            nameTa = "கிருஷ்ணகிரி",
            districtEn = "Mango City District",
            venueTitleEn = "Krishnagiri Mango City Convention Hall",
            venueTitleTa = "கிருஷ்ணகிரி மேங்கோ சிட்டி மஹால்",
            mapUrl = "https://www.google.com/maps/search/?api=1&query=Krishnagiri+Tamil+Nadu",
            emoji = "🌳",
            rating = 4.7f,
            price = "₹35,000 / day",
            phone = "+91 94435 77889",
            canvasOffsetRatio = Offset(0.40f, 0.18f),
            markerColor = Color(0xFF22C55E)
        ),
        RegionalLocationMarker(
            id = "dindigul",
            nameEn = "Dindigul",
            nameTa = "திண்டுக்கல்",
            districtEn = "Lock City District",
            venueTitleEn = "Dindigul Rock Fort Royal Palace",
            venueTitleTa = "திண்டுக்கல் ராக் ஃபோர்ட் பேலஸ்",
            mapUrl = "https://www.google.com/maps/search/?api=1&query=Dindigul+Tamil+Nadu",
            emoji = "🔑",
            rating = 4.8f,
            price = "₹42,000 / day",
            phone = "+91 94436 99001",
            canvasOffsetRatio = Offset(0.35f, 0.58f),
            markerColor = Color(0xFFF97316)
        )
    )
}

@Composable
fun InteractiveLocationMapCard(
    currentLanguage: Language,
    modifier: Modifier = Modifier,
    onShowToast: (String) -> Unit = {}
) {
    val context = LocalContext.current
    var selectedLocation by remember { mutableStateOf(RegionalLocationsData.locations.first()) }
    var isSatelliteView by remember { mutableStateOf(true) }

    // Pulsing animation for active pin marker
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.45f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    fun openMapUrl(url: String, locationName: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            context.startActivity(intent)
            onShowToast("Opening $locationName Google Maps")
        } catch (e: Exception) {
            Toast.makeText(context, "Opening Map for $locationName", Toast.LENGTH_SHORT).show()
        }
    }

    GlassCard(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        elevation = 6.dp,
        shape = RoundedCornerShape(26.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFFFFFFFF),
                            Color(0xFFFFF5F8),
                            Color(0xFFFFF0F5)
                        )
                    )
                )
                .padding(16.dp)
        ) {
            // 1. Header Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f, fill = true),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(PinkPrimary.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Explore,
                            contentDescription = "Interactive Map",
                            tint = PinkPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (currentLanguage == Language.TAMIL) "📍 தமிழ்நாடு நேரலை மேப்" else "📍 Tamil Nadu Satellite Map",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.onBackground,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = if (currentLanguage == Language.TAMIL) "நேரலை மேப் & கூகுள் மேப் இணைப்புகள்" else "Live GPS satellite markers & Google Maps links",
                            fontSize = 10.sp,
                            color = PinkPrimary,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                GlassBadge(
                    text = "${RegionalLocationsData.locations.size} Districts",
                    containerColor = PinkPrimary.copy(alpha = 0.12f),
                    contentColor = PinkPrimary
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 2. Scrollable District Filter Chips / Tabs
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(horizontal = 2.dp)
            ) {
                items(RegionalLocationsData.locations) { loc ->
                    val isSelected = loc.id == selectedLocation.id
                    val chipBg = if (isSelected) loc.markerColor else Color.White
                    val textColor = if (isSelected) Color.White else MaterialTheme.colorScheme.onBackground

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(chipBg)
                            .border(
                                width = if (isSelected) 0.dp else 1.5.dp,
                                color = if (isSelected) Color.Transparent else loc.markerColor.copy(alpha = 0.4f),
                                shape = RoundedCornerShape(16.dp)
                            )
                            .clickable { selectedLocation = loc }
                            .padding(vertical = 8.dp, horizontal = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(text = loc.emoji, fontSize = 13.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (currentLanguage == Language.TAMIL) loc.nameTa else loc.nameEn,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                color = textColor,
                                maxLines = 1
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 3. Interactive Visual Satellite Canvas Map
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(230.dp),
                shape = RoundedCornerShape(20.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            if (isSatelliteView) {
                                Brush.linearGradient(
                                    colors = listOf(
                                        Color(0xFF0F172A), // Dark Satellite Navy
                                        Color(0xFF1E293B),
                                        Color(0xFF022C22)  // Satellite Forest Tint
                                    )
                                )
                            } else {
                                Brush.linearGradient(
                                    colors = listOf(
                                        Color(0xFFF1F5F9),
                                        Color(0xFFE2E8F0),
                                        Color(0xFFCBD5E1)
                                    )
                                )
                            }
                        )
                ) {
                    // Canvas Routes & Region Grid Representation
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val canvasWidth = size.width
                        val canvasHeight = size.height

                        // Draw Grid lines
                        val dashEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 12f), 0f)
                        val lineTint = if (isSatelliteView) Color(0xFF334155).copy(alpha = 0.6f) else Color(0xFF94A3B8).copy(alpha = 0.5f)

                        // Draw regional connect lines between nearby districts
                        val locationsList = RegionalLocationsData.locations
                        for (i in 0 until locationsList.size - 1) {
                            val p1 = Offset(
                                locationsList[i].canvasOffsetRatio.x * canvasWidth,
                                locationsList[i].canvasOffsetRatio.y * canvasHeight
                            )
                            val p2 = Offset(
                                locationsList[i + 1].canvasOffsetRatio.x * canvasWidth,
                                locationsList[i + 1].canvasOffsetRatio.y * canvasHeight
                            )
                            drawLine(
                                color = locationsList[i].markerColor.copy(alpha = 0.35f),
                                start = p1,
                                end = p2,
                                strokeWidth = 3f,
                                pathEffect = dashEffect
                            )
                        }
                    }

                    // Render Map Location Pin Markers dynamically across TN
                    RegionalLocationsData.locations.forEach { loc ->
                        val isSelected = loc.id == selectedLocation.id

                        Box(
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(
                                    start = (loc.canvasOffsetRatio.x * 320).dp,
                                    top = (loc.canvasOffsetRatio.y * 170).dp
                                )
                                .clickable { selectedLocation = loc },
                            contentAlignment = Alignment.Center
                        ) {
                            if (isSelected) {
                                // Pulsing Aura for active selection
                                Box(
                                    modifier = Modifier
                                        .size((36 * pulseScale).dp)
                                        .clip(CircleShape)
                                        .background(loc.markerColor.copy(alpha = 0.4f))
                                )
                            }

                            // Pin Marker Badge
                            Box(
                                modifier = Modifier
                                    .size(if (isSelected) 34.dp else 24.dp)
                                    .clip(CircleShape)
                                    .background(if (isSelected) loc.markerColor else Color.White)
                                    .border(
                                        width = 2.dp,
                                        color = if (isSelected) Color.White else loc.markerColor,
                                        shape = CircleShape
                                    )
                                    .shadow(elevation = 6.dp, shape = CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = loc.emoji,
                                    fontSize = if (isSelected) 15.sp else 10.sp
                                )
                            }

                            if (isSelected) {
                                // Label Tag overlay
                                Box(
                                    modifier = Modifier
                                        .padding(top = 34.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(loc.markerColor)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = if (currentLanguage == Language.TAMIL) loc.nameTa else loc.nameEn,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }

                    // Top Right Satellite View Toggle Button
                    Surface(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable {
                                isSatelliteView = !isSatelliteView
                                onShowToast(if (isSatelliteView) "Satellite HD Layer On" else "Standard Map Layer On")
                            },
                        color = if (isSatelliteView) PinkPrimary else Color.White,
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Map,
                                contentDescription = "Satellite",
                                tint = if (isSatelliteView) Color.White else PinkPrimary,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isSatelliteView) "🛰️ Satellite HD" else "🗺️ Standard",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSatelliteView) Color.White else PinkPrimary
                            )
                        }
                    }

                    // Bottom Map Overlay Watermark / Info
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(8.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.Black.copy(alpha = 0.65f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "🗺️ TN Live Map • Tap markers",
                            fontSize = 9.sp,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 4. Selected Location Details Card with Google Maps Launch CTA
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color.White
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(selectedLocation.markerColor.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(text = selectedLocation.emoji, fontSize = 22.sp)
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column {
                                Text(
                                    text = if (currentLanguage == Language.TAMIL) selectedLocation.nameTa else selectedLocation.nameEn,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Black,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                Text(
                                    text = selectedLocation.districtEn,
                                    fontSize = 11.sp,
                                    color = selectedLocation.markerColor,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Rating Badge
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(GoldPrimary.copy(alpha = 0.15f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = "Rating",
                                tint = GoldPrimary,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "${selectedLocation.rating}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = if (currentLanguage == Language.TAMIL) selectedLocation.venueTitleTa else selectedLocation.venueTitleEn,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "🏷️ ${selectedLocation.price}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = PinkPrimary
                        )
                        Text(
                            text = "📞 ${selectedLocation.phone}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // ACTION BUTTONS: Big Google Maps URL launcher button + Directions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { openMapUrl(selectedLocation.mapUrl, selectedLocation.nameEn) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = selectedLocation.markerColor,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 10.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.LocationOn,
                                    contentDescription = "Map URL",
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (currentLanguage == Language.TAMIL) "📍 கூகுள் மேப்பில் திறக்கவும்" else "📍 Open Google Maps",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }

                        OutlinedButton(
                            onClick = { openMapUrl(selectedLocation.mapUrl, selectedLocation.nameEn) },
                            shape = RoundedCornerShape(14.dp),
                            border = androidx.compose.foundation.BorderStroke(
                                1.5.dp,
                                selectedLocation.markerColor
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.OpenInNew,
                                contentDescription = "Open Link",
                                tint = selectedLocation.markerColor,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
