package com.example.ui.screens

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.speech.RecognizerIntent
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.data.CartItemEntity
import com.example.data.WishlistItemEntity
import com.example.model.AdminReferralSettings
import com.example.model.Language
import com.example.model.MarketProduct
import com.example.model.SampleData
import com.example.ui.components.GlassBadge
import com.example.ui.components.GlassCard
import com.example.ui.components.StarRating
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.PinkDark
import com.example.ui.theme.PinkPrimary
import com.example.ui.theme.SkyBluePrimary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MarketplaceScreen(
    currentVillage: String,
    cartItems: List<CartItemEntity>,
    wishlistItems: List<WishlistItemEntity>,
    eCommerceProducts: List<com.example.data.ECommerceProductEntity> = emptyList(),
    priceRange: ClosedFloatingPointRange<Float> = 0f..5000f,
    selectedProduct: MarketProduct?,
    currentLanguage: Language,
    referralSettings: AdminReferralSettings = AdminReferralSettings(),
    marketProducts: List<MarketProduct> = SampleData.sampleMarketProducts,
    onPriceRangeChange: (ClosedFloatingPointRange<Float>) -> Unit = {},
    onProductSelect: (MarketProduct?) -> Unit,
    onAddToCart: (MarketProduct) -> Unit,
    onRemoveFromCart: (Int) -> Unit,
    onToggleWishlist: (MarketProduct) -> Unit,
    onRemoveFromWishlist: (String) -> Unit = {},
    onSaveEcommerceToWishlist: (com.example.data.ECommerceProductEntity) -> Unit = {},
    onFetchEcommerceLink: (String) -> Unit = {},
    onDeleteECommerceProduct: (Int) -> Unit = {},
    onShowToast: (String) -> Unit
) {
    val context = LocalContext.current
    var showCartSheet by remember { mutableStateOf(false) }
    var showWishlistSheet by remember { mutableStateOf(false) }
    var detailProductModal by remember { mutableStateOf<MarketProduct?>(selectedProduct) }

    // Search, Filter & Sort state
    var productSearchQuery by remember { mutableStateOf("") }
    var selectedMarketplace by remember { mutableStateOf("All") } // All, Meesho, Flipkart, Amazon
    var selectedCategory by remember { mutableStateOf("All") } // All, Bridal Wear, Garlands, Pooja & Return Gifts, Crafts & Gifts
    var selectedSortOption by remember { mutableStateOf("Featured") } // Featured, Price: Low to High, Price: High to Low, Rating

    val voiceLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spokenResults = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spokenText = spokenResults?.firstOrNull()
            if (!spokenText.isNullOrBlank()) {
                productSearchQuery = spokenText
                onShowToast("Voice search: $spokenText")
            }
        }
    }

    fun startVoiceSearch() {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (currentLanguage == Language.TAMIL) "ta-IN" else "en-IN")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Search products...")
            }
            voiceLauncher.launch(intent)
        } catch (e: Exception) {
            Log.e("sk", "Voice search error", e)
        }
    }

    // Filter & Sort Products
    val activeProducts = marketProducts.filter { it.isEnabled }
    val filteredProducts = activeProducts.filter { product ->
        val matchesSearch = productSearchQuery.isBlank() ||
                product.titleEn.contains(productSearchQuery, ignoreCase = true) ||
                product.titleTa.contains(productSearchQuery, ignoreCase = true) ||
                product.category.contains(productSearchQuery, ignoreCase = true) ||
                product.description.contains(productSearchQuery, ignoreCase = true)

        val matchesMarketplace = selectedMarketplace == "All" ||
                product.marketplace.equals(selectedMarketplace, ignoreCase = true)

        val matchesCategory = selectedCategory == "All" ||
                product.category.contains(selectedCategory, ignoreCase = true)

        matchesSearch && matchesMarketplace && matchesCategory
    }.let { list ->
        when (selectedSortOption) {
            "Price: Low to High" -> list.sortedBy { it.price }
            "Price: High to Low" -> list.sortedByDescending { it.price }
            "Rating" -> list.sortedByDescending { it.rating }
            else -> list.sortedByDescending { it.isFeatured } // Featured first
        }
    }

    val featuredList = activeProducts.filter { it.isFeatured }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 80.dp)
    ) {
        // Header Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (currentLanguage == Language.TAMIL) "அதிகாரப்பூர்வ இ-காமர்ஸ் சந்தை" else "Official E-Commerce Marketplace Hub",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = if (currentLanguage == Language.TAMIL) "மீஷோ, பிளிப்கார்ட், அமேசான், மைந்த்ரா, அஜியோ & பிற ஆன்லைன் செயலிகள்" else "Meesho, Flipkart, Amazon, Myntra, Ajio, Tata Neu & More",
                    fontSize = 11.sp,
                    color = PinkPrimary,
                    fontWeight = FontWeight.Bold
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Wishlist / Saved Items Button
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFFFFF1F2))
                        .border(1.dp, PinkPrimary.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                        .clickable { showWishlistSheet = true }
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Favorite, contentDescription = "Wishlist", tint = PinkPrimary, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "${wishlistItems.size}", fontWeight = FontWeight.Black, fontSize = 13.sp, color = PinkPrimary)
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Cart Button
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(PinkPrimary.copy(alpha = 0.15f))
                        .border(1.dp, PinkPrimary.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                        .clickable { showCartSheet = true }
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.ShoppingBag, contentDescription = "Cart", tint = PinkPrimary, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "${cartItems.size}", fontWeight = FontWeight.Black, fontSize = 13.sp, color = PinkPrimary)
                    }
                }
            }
        }

        // Social Media & Admin Support Bar
        SocialMediaBar(referralSettings = referralSettings, context = context, onShowToast = onShowToast)

        // Search Bar with Voice Input
        OutlinedTextField(
            value = productSearchQuery,
            onValueChange = { productSearchQuery = it },
            placeholder = {
                Text(
                    text = if (currentLanguage == Language.TAMIL) "பொருட்களைத் தேடுக (எ.கா. பட்டுப்புடவை, விளக்கு)..." else "Search products (e.g. Saree, Lamp, Garland)...",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                )
            },
            leadingIcon = {
                Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = PinkPrimary)
            },
            trailingIcon = {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(PinkPrimary.copy(alpha = 0.15f))
                        .clickable { startVoiceSearch() },
                    contentAlignment = Alignment.Center
                ) {
                    Text("🎤", fontSize = 14.sp)
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(20.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surface,
                unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                focusedBorderColor = PinkPrimary,
                unfocusedBorderColor = MaterialTheme.colorScheme.outline
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp)
        )

        // Official Marketplace Apps Grid Section (Meesho, Flipkart, Amazon, Myntra, Ajio, Tata Neu, JioMart, Snapdeal)
        MarketplaceAppCardsSection(
            context = context,
            onShowToast = onShowToast
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Footer Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "© 2026 Shivani Hub. All Rights Reserved.",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                textAlign = TextAlign.Center
            )
        }
    }

    // Detail Product Modal Dialog
    if (detailProductModal != null) {
        ProductDetailModal(
            product = detailProductModal!!,
            referralSettings = referralSettings,
            isWishlisted = wishlistItems.any { it.id == detailProductModal!!.id },
            currentLanguage = currentLanguage,
            onDismiss = { detailProductModal = null },
            onBuyNow = {
                executeBuyNow(context, detailProductModal!!, referralSettings, onShowToast)
            },
            onShare = { shareProduct(context, detailProductModal!!, referralSettings) },
            onToggleWishlist = { onToggleWishlist(detailProductModal!!) },
            onAddToCart = {
                onAddToCart(detailProductModal!!)
                detailProductModal = null
            }
        )
    }

    // Wishlist Modal Sheet
    if (showWishlistSheet) {
        ModalBottomSheet(onDismissRequest = { showWishlistSheet = false }) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "Saved Items (${wishlistItems.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(modifier = Modifier.height(12.dp))
                if (wishlistItems.isEmpty()) {
                    Text(text = "No saved items in your wishlist.", fontSize = 12.sp, color = Color.Gray)
                } else {
                    wishlistItems.forEach { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = item.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(text = item.price, fontSize = 12.sp, color = PinkPrimary, fontWeight = FontWeight.Bold)
                            }
                            IconButton(onClick = { onRemoveFromWishlist(item.id) }) {
                                Icon(imageVector = Icons.Default.Delete, contentDescription = "Remove", tint = Color.Red)
                            }
                        }
                        HorizontalDivider()
                    }
                }
            }
        }
    }

    // Cart Modal Sheet
    if (showCartSheet) {
        ModalBottomSheet(onDismissRequest = { showCartSheet = false }) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "Shopping Cart (${cartItems.size} Items)", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(modifier = Modifier.height(12.dp))

                var total = 0.0
                cartItems.forEach { item ->
                    total += item.price * item.quantity
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = item.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(text = "₹${item.price.toInt()} x ${item.quantity}", fontSize = 12.sp, color = PinkPrimary)
                        }
                        IconButton(onClick = { onRemoveFromCart(item.id) }) {
                            Icon(imageVector = Icons.Default.Delete, contentDescription = "Remove", tint = Color.Red)
                        }
                    }
                    HorizontalDivider()
                }

                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Total Amount:", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(text = "₹${total.toInt()}", fontWeight = FontWeight.Black, fontSize = 18.sp, color = PinkPrimary)
                }

                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = {
                        onShowToast("Order placed via Shivani Connect Marketplace!")
                        showCartSheet = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(text = "Proceed to Checkout", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun SocialMediaBar(
    referralSettings: AdminReferralSettings,
    context: Context,
    onShowToast: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Color.White)
            .border(1.5.dp, PinkPrimary.copy(alpha = 0.25f), RoundedCornerShape(20.dp))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "⚡ Connect With Us Directly:",
                fontSize = 11.5.sp,
                fontWeight = FontWeight.Black,
                color = PinkPrimary
            )
            Text(
                text = "Official Handles",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(horizontal = 2.dp)
        ) {
            item {
                // WhatsApp Unique Pill
                UniqueSocialPill(
                    label = "WhatsApp",
                    iconText = "💬",
                    bgGradient = listOf(Color(0xFF25D366), Color(0xFF128C7E)),
                    borderColor = Color(0xFF25D366)
                ) {
                    val num = referralSettings.whatsAppNumber.replace(" ", "").replace("+", "")
                    openUrl(context, "https://wa.me/$num", onShowToast)
                }
            }

            item {
                // Instagram Unique Pill
                UniqueSocialPill(
                    label = "Instagram",
                    iconText = "📸",
                    bgGradient = listOf(Color(0xFF833AB4), Color(0xFFFD1D1D), Color(0xFFF77737)),
                    borderColor = Color(0xFFE1306C)
                ) {
                    openUrl(context, referralSettings.instagramLink, onShowToast)
                }
            }

            item {
                // Facebook Unique Pill
                UniqueSocialPill(
                    label = "Facebook",
                    iconText = "📘",
                    bgGradient = listOf(Color(0xFF1877F2), Color(0xFF0D53B7)),
                    borderColor = Color(0xFF1877F2)
                ) {
                    openUrl(context, referralSettings.facebookLink, onShowToast)
                }
            }

            item {
                // Telegram Unique Pill
                UniqueSocialPill(
                    label = "Telegram",
                    iconText = "✈️",
                    bgGradient = listOf(Color(0xFF0088CC), Color(0xFF229ED9)),
                    borderColor = Color(0xFF0088CC)
                ) {
                    openUrl(context, referralSettings.telegramLink, onShowToast)
                }
            }

            item {
                // YouTube Unique Pill
                UniqueSocialPill(
                    label = "YouTube",
                    iconText = "▶️",
                    bgGradient = listOf(Color(0xFFFF0000), Color(0xFFB30000)),
                    borderColor = Color(0xFFFF0000)
                ) {
                    openUrl(context, referralSettings.youTubeLink, onShowToast)
                }
            }
        }
    }
}

@Composable
fun UniqueSocialPill(
    label: String,
    iconText: String,
    bgGradient: List<Color>,
    borderColor: Color,
    onClick: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Brush.horizontalGradient(bgGradient))
            .border(1.dp, Color.White.copy(alpha = 0.6f), RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(22.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.25f)),
            contentAlignment = Alignment.Center
        ) {
            Text(text = iconText, fontSize = 12.sp)
        }
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
    }
}

@Composable
fun MarketplaceFilterChips(
    selectedMarketplace: String,
    onSelect: (String) -> Unit
) {
    val options = listOf(
        "All" to Color.Gray,
        "Meesho" to Color(0xFFE91E63),
        "Flipkart" to Color(0xFF2874F0),
        "Amazon" to Color(0xFFFF9900)
    )

    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(options) { (name, brandColor) ->
            val isSelected = selectedMarketplace == name
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(if (isSelected) brandColor else brandColor.copy(alpha = 0.1f))
                    .border(1.dp, brandColor.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
                    .clickable { onSelect(name) }
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Text(
                    text = name,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) Color.White else brandColor
                )
            }
        }
    }
}

@Composable
fun CategoryFilterRow(
    selectedCategory: String,
    onSelectCategory: (String) -> Unit
) {
    val categories = listOf("All", "Bridal Wear", "Wedding Garlands", "Return Gifts & Pooja", "Pooja & Decor", "Gift Box")

    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 2.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        items(categories) { cat ->
            val isSelected = selectedCategory == cat
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isSelected) PinkPrimary else MaterialTheme.colorScheme.surfaceVariant)
                    .clickable { onSelectCategory(cat) }
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
                Text(
                    text = cat,
                    fontSize = 11.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun FeaturedProductsHeader(
    featuredProducts: List<MarketProduct>,
    onProductClick: (MarketProduct) -> Unit,
    referralSettings: AdminReferralSettings,
    context: Context,
    onShowToast: (String) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "★ FEATURED MARKETPLACE DEALS", fontSize = 12.sp, fontWeight = FontWeight.Black, color = GoldPrimary)
        }

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 8.dp)
        ) {
            items(featuredProducts) { product ->
                Card(
                    modifier = Modifier
                        .width(220.dp)
                        .clickable { onProductClick(product) },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(3.dp)
                ) {
                    Column {
                        Box {
                            AsyncImage(
                                model = product.imageUrl,
                                contentDescription = product.titleEn,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(110.dp),
                                contentScale = ContentScale.Crop
                            )

                            // Marketplace Badge
                            val bg = when (product.marketplace.lowercase()) {
                                "meesho" -> Color(0xFFE91E63)
                                "flipkart" -> Color(0xFF2874F0)
                                "amazon" -> Color(0xFFFF9900)
                                else -> PinkPrimary
                            }
                            Box(
                                modifier = Modifier
                                    .padding(8.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(bg)
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Text(text = product.marketplace, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }

                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(text = product.titleEn, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1)
                            Spacer(modifier = Modifier.height(2.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = "₹${product.price.toInt()}", fontWeight = FontWeight.Black, fontSize = 14.sp, color = PinkPrimary)

                                Button(
                                    onClick = { executeBuyNow(context, product, referralSettings, onShowToast) },
                                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(text = "Buy Now", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MarketProductCard(
    product: MarketProduct,
    isWishlisted: Boolean,
    referralSettings: AdminReferralSettings,
    currentLanguage: Language,
    onProductClick: () -> Unit,
    onBuyNow: () -> Unit,
    onShare: () -> Unit,
    onToggleWishlist: () -> Unit,
    onAddToCart: () -> Unit
) {
    val mktBg = when (product.marketplace.lowercase()) {
        "meesho" -> Color(0xFFE91E63)
        "flipkart" -> Color(0xFF2874F0)
        "amazon" -> Color(0xFFFF9900)
        else -> PinkPrimary
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onProductClick() },
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(3.dp)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1.2f)
            ) {
                AsyncImage(
                    model = product.imageUrl,
                    contentDescription = product.titleEn,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )

                // Marketplace Badge
                Box(
                    modifier = Modifier
                        .padding(8.dp)
                        .align(Alignment.TopStart)
                        .clip(RoundedCornerShape(8.dp))
                        .background(mktBg)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = product.marketplace,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                }

                // Wishlist Heart Button
                Box(
                    modifier = Modifier
                        .padding(8.dp)
                        .align(Alignment.TopEnd)
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.9f))
                        .clickable { onToggleWishlist() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isWishlisted) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Wishlist",
                        tint = if (isWishlisted) PinkPrimary else Color.Gray,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Discount Tag
                if (product.discountPercent > 0) {
                    Box(
                        modifier = Modifier
                            .padding(8.dp)
                            .align(Alignment.BottomStart)
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color.Red)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "${product.discountPercent}% OFF",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }

            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    text = if (currentLanguage == Language.TAMIL) product.titleTa else product.titleEn,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(2.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    StarRating(rating = product.rating)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "(${product.reviewCount})", fontSize = 10.sp, color = Color.Gray)
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "₹${product.price.toInt()}",
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp,
                        color = PinkPrimary
                    )

                    if (product.originalPrice > product.price) {
                        Text(
                            text = "₹${product.originalPrice.toInt()}",
                            fontSize = 11.sp,
                            color = Color.Gray,
                            textDecoration = TextDecoration.LineThrough
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Action Buttons Row (Buy Now, Share)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Button(
                        onClick = onBuyNow,
                        colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(vertical = 4.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(text = "Buy Now", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    IconButton(
                        onClick = onShare,
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = "Share", tint = PinkPrimary, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun ProductDetailModal(
    product: MarketProduct,
    referralSettings: AdminReferralSettings,
    isWishlisted: Boolean,
    currentLanguage: Language,
    onDismiss: () -> Unit,
    onBuyNow: () -> Unit,
    onShare: () -> Unit,
    onToggleWishlist: () -> Unit,
    onAddToCart: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(18.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(PinkPrimary.copy(alpha = 0.15f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(text = product.marketplace, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = PinkPrimary)
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                AsyncImage(
                    model = product.imageUrl,
                    contentDescription = product.titleEn,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .clip(RoundedCornerShape(16.dp)),
                    contentScale = ContentScale.Crop
                )

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = if (currentLanguage == Language.TAMIL) product.titleTa else product.titleEn,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    StarRating(rating = product.rating)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "${product.rating} (${product.reviewCount} reviews)", fontSize = 12.sp, color = Color.Gray)
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "₹${product.price.toInt()}", fontWeight = FontWeight.Black, fontSize = 22.sp, color = PinkPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "₹${product.originalPrice.toInt()}",
                        fontSize = 14.sp,
                        color = Color.Gray,
                        textDecoration = TextDecoration.LineThrough
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color.Red)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(text = "${product.discountPercent}% OFF", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(text = "DESCRIPTION", fontSize = 11.sp, fontWeight = FontWeight.Black, color = PinkPrimary)
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = product.description, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f))

                Spacer(modifier = Modifier.height(18.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onBuyNow,
                        colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(text = "Buy Now on ${product.marketplace}", fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = onAddToCart,
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.ShoppingBag, contentDescription = null, tint = Color.White)
                    }

                    IconButton(
                        onClick = onShare,
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = "Share", tint = PinkPrimary)
                    }
                }
            }
        }
    }
}

fun executeBuyNow(
    context: Context,
    product: MarketProduct,
    settings: AdminReferralSettings,
    onShowToast: (String) -> Unit
) {
    // Determine affiliate link based on product marketplace
    val referralLink = when (product.marketplace.lowercase()) {
        "meesho" -> settings.meeshoReferralLink.ifBlank { product.productUrl }
        "flipkart" -> settings.flipkartAffiliateLink.ifBlank { product.productUrl }
        "amazon" -> settings.amazonAffiliateLink.ifBlank { product.productUrl }
        else -> product.productUrl.ifBlank { settings.websiteUrl }
    }

    val finalTargetUrl = if (referralLink.isNotBlank()) {
        if (!referralLink.startsWith("http://") && !referralLink.startsWith("https://")) "https://$referralLink" else referralLink
    } else if (product.productUrl.isNotBlank()) {
        if (!product.productUrl.startsWith("http://") && !product.productUrl.startsWith("https://")) "https://${product.productUrl}" else product.productUrl
    } else {
        "https://www.google.com/search?q=${Uri.encode(product.titleEn + " " + product.marketplace)}"
    }

    try {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(finalTargetUrl))
        context.startActivity(intent)
        onShowToast("Opening ${product.marketplace} link via Shivani Connect...")
    } catch (e: Exception) {
        onShowToast("Unable to open marketplace link: ${e.localizedMessage}")
    }
}

fun shareProduct(context: Context, product: MarketProduct, settings: AdminReferralSettings) {
    val link = when (product.marketplace.lowercase()) {
        "meesho" -> settings.meeshoReferralLink.ifBlank { product.productUrl }
        "flipkart" -> settings.flipkartAffiliateLink.ifBlank { product.productUrl }
        "amazon" -> settings.amazonAffiliateLink.ifBlank { product.productUrl }
        else -> product.productUrl.ifBlank { settings.websiteUrl }
    }

    val shareBody = "Check out '${product.titleEn}' for ₹${product.price.toInt()} on ${product.marketplace} via Shivani Connect!\nLink: $link"

    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, product.titleEn)
        putExtra(Intent.EXTRA_TEXT, shareBody)
    }

    context.startActivity(Intent.createChooser(intent, "Share Product via"))
}

fun openUrl(context: Context, url: String, onShowToast: (String) -> Unit) {
    if (url.isBlank()) {
        onShowToast("URL link not configured in Admin Settings.")
        return
    }
    try {
        val target = if (!url.startsWith("http://") && !url.startsWith("https://")) "https://$url" else url
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(target))
        context.startActivity(intent)
    } catch (e: Exception) {
        onShowToast("Could not open link: ${e.localizedMessage}")
    }
}

data class MarketplaceAppInfo(
    val name: String,
    val packageName: String,
    val brandColor: Color,
    val description: String,
    val iconEmoji: String
)

fun isPackageInstalled(context: Context, packageName: String): Boolean {
    return try {
        context.packageManager.getLaunchIntentForPackage(packageName) != null
    } catch (e: Exception) {
        false
    }
}

fun launchMarketplaceAppOrStore(
    context: Context,
    packageName: String,
    appName: String,
    onShowToast: (String) -> Unit
) {
    val pm = context.packageManager
    val launchIntent = pm.getLaunchIntentForPackage(packageName)
    if (launchIntent != null) {
        try {
            context.startActivity(launchIntent)
            onShowToast("Opening $appName App...")
        } catch (e: Exception) {
            onShowToast("Could not open $appName: ${e.localizedMessage}")
        }
    } else {
        try {
            val marketIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName"))
            marketIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(marketIntent)
            onShowToast("Opening Play Store page for $appName...")
        } catch (e: Exception) {
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$packageName"))
            context.startActivity(webIntent)
            onShowToast("Opening Play Store for $appName...")
        }
    }
}

@Composable
fun MarketplaceAppCardsSection(
    context: Context,
    onShowToast: (String) -> Unit
) {
    val marketplaceApps = listOf(
        MarketplaceAppInfo(
            name = "Meesho",
            packageName = "com.misho.supply",
            brandColor = Color(0xFFE91E63),
            description = "Direct Wholesale & Resell",
            iconEmoji = "🛍️"
        ),
        MarketplaceAppInfo(
            name = "Flipkart",
            packageName = "com.flipkart.android",
            brandColor = Color(0xFF2874F0),
            description = "India's Mega Shopping Hub",
            iconEmoji = "📦"
        ),
        MarketplaceAppInfo(
            name = "Amazon",
            packageName = "com.amazon.mShop.android.shopping",
            brandColor = Color(0xFFFF9900),
            description = "Fast Delivery & Top Deals",
            iconEmoji = "⚡"
        ),
        MarketplaceAppInfo(
            name = "Myntra",
            packageName = "com.myntra.android",
            brandColor = Color(0xFFF44336),
            description = "Fashion & Trendy Wear",
            iconEmoji = "👗"
        ),
        MarketplaceAppInfo(
            name = "Ajio",
            packageName = "com.ril.ajio",
            brandColor = Color(0xFF2C3E50),
            description = "Exclusive Styles & Brands",
            iconEmoji = "👠"
        ),
        MarketplaceAppInfo(
            name = "Tata Neu",
            packageName = "com.tatadigital.tcp",
            brandColor = Color(0xFF9C27B0),
            description = "Electronics, Grocery & NeuCoins",
            iconEmoji = "💎"
        ),
        MarketplaceAppInfo(
            name = "JioMart",
            packageName = "com.jio.jiomart",
            brandColor = Color(0xFF00B0FF),
            description = "Daily Essentials & Mobiles",
            iconEmoji = "🍎"
        ),
        MarketplaceAppInfo(
            name = "Snapdeal",
            packageName = "com.snapdeal.main",
            brandColor = Color(0xFFE53935),
            description = "Best Value E-Commerce Deals",
            iconEmoji = "🏷️"
        )
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "🛍️ Official E-Commerce Marketplaces",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "One-click access to official shopping applications",
                    fontSize = 11.sp,
                    color = PinkPrimary,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Grid of Official Marketplaces
        Column(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            marketplaceApps.chunked(2).forEach { rowApps ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    rowApps.forEach { app ->
                        val isInstalled = remember(app.packageName) {
                            isPackageInstalled(context, app.packageName)
                        }

                        GlassCard(
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    launchMarketplaceAppOrStore(context, app.packageName, app.name, onShowToast)
                                },
                            elevation = 4.dp,
                            shape = RoundedCornerShape(18.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(38.dp)
                                            .clip(CircleShape)
                                            .background(app.brandColor.copy(alpha = 0.15f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(app.iconEmoji, fontSize = 18.sp)
                                    }

                                    // Installed or Play Store Badge
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (isInstalled) Color(0xFFDCFCE7) else Color(0xFFF3F4F6))
                                            .border(0.5.dp, if (isInstalled) Color(0xFF16A34A) else Color.Gray, RoundedCornerShape(8.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = if (isInstalled) "Installed ✓" else "Play Store",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isInstalled) Color(0xFF15803D) else Color.DarkGray
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Text(
                                    text = app.name,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onBackground
                                )

                                Text(
                                    text = app.description,
                                    fontSize = 10.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                Button(
                                    onClick = {
                                        launchMarketplaceAppOrStore(context, app.packageName, app.name, onShowToast)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = app.brandColor),
                                    shape = RoundedCornerShape(10.dp),
                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(32.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = if (isInstalled) "Open App" else "Get on Store",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(
                                            imageVector = Icons.Default.OpenInNew,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(12.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // If odd item count, fill remaining row slot
                    if (rowApps.size == 1) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
}
