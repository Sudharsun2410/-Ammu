package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.SdStorage
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.PinkDark
import com.example.ui.theme.PinkPrimary
import com.example.ui.theme.SkyBluePrimary
import com.example.worker.DharmapuriBackupWorker

enum class BackupTimeframe(val titleEn: String, val titleTa: String, val days: Int) {
    ONE_DAY("1 Day", "1 நாள் (தினசரி)", 1),
    FOUR_WEEKS("4 Weeks", "4 வாரங்கள் (மாதாந்திர)", 28),
    ONE_YEAR("1 Year", "1 வருடம் (ஆண்டு)", 365)
}

@Composable
fun BackupManagerCard(
    onShowToast: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedTimeframe by remember { mutableStateOf(BackupTimeframe.FOUR_WEEKS) }
    var selectedDistrict by remember { mutableStateOf("Dharmapuri") }
    var isAutoBackupEnabled by remember { mutableStateOf(true) }
    var isBackingUp by remember { mutableStateOf(false) }
    var lastBackupTime by remember { mutableStateOf("2026-07-25 05:40") }

    val districts = listOf(
        "Dharmapuri" to "தர்மபுரி (அரூர், பெண்ணாகரம்)",
        "Salem" to "சேலம் (மேட்டூர், ஓமலூர்)",
        "Krishnagiri" to "கிருஷ்ணகிரி (உத்தங்கரை)",
        "All Tamil Nadu" to "அனைத்து மாவட்டங்கள்"
    )

    GlassCard(
        modifier = modifier.fillMaxWidth(),
        elevation = 6.dp
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Title
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(GoldPrimary.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.SdStorage,
                            contentDescription = "Backup",
                            tint = GoldDark,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "DATA BACKUP & ARCHIVE",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "தரவு காப்புநகல் & வரலாற்றுச் சேமிப்பு",
                            fontSize = 10.sp,
                            color = SkyBluePrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                GlassBadge(text = "v2.5 SECURE")
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Select Backup Timeframe (1 Day, 4 Weeks, 1 Year)
            Text(
                text = "SELECT BACKUP TIMEFRAME (கால அளவு)",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
            )
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                BackupTimeframe.values().forEach { timeframe ->
                    val isSelected = selectedTimeframe == timeframe
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (isSelected) SkyBluePrimary else MaterialTheme.colorScheme.surface.copy(alpha = 0.5f)
                            )
                            .border(
                                width = 1.dp,
                                color = if (isSelected) GoldPrimary else Color.LightGray.copy(alpha = 0.4f),
                                shape = RoundedCornerShape(10.dp)
                            )
                            .clickable { selectedTimeframe = timeframe }
                            .padding(vertical = 8.dp, horizontal = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = timeframe.titleEn,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onBackground
                            )
                            Text(
                                text = timeframe.titleTa,
                                fontSize = 9.sp,
                                color = if (isSelected) GoldPrimary else Color.Gray
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Select District Filter
            Text(
                text = "DISTRICT DATA SCOPE (மாவட்ட விபரம்)",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
            )
            Spacer(modifier = Modifier.height(6.dp))

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                districts.forEach { (distKey, distLabel) ->
                    val isSelected = selectedDistrict == distKey
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (isSelected) GoldPrimary.copy(alpha = 0.15f) else Color.Transparent
                            )
                            .border(
                                width = 1.dp,
                                color = if (isSelected) GoldPrimary else Color.LightGray.copy(alpha = 0.3f),
                                shape = RoundedCornerShape(8.dp)
                            )
                            .clickable { selectedDistrict = distKey }
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.LocationOn,
                                contentDescription = null,
                                tint = if (isSelected) GoldDark else Color.Gray,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = distLabel,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        }

                        if (isSelected) {
                            Text(
                                text = "SELECTED",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Black,
                                color = GoldDark
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Automatic Scheduled Backup Toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(SkyBluePrimary.copy(alpha = 0.08f))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.DateRange,
                        contentDescription = null,
                        tint = SkyBluePrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "AUTO-BACKUP SCHEDULE",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "Automatic cloud sync every ${selectedTimeframe.titleEn}",
                            fontSize = 9.sp,
                            color = Color.Gray
                        )
                    }
                }

                Switch(
                    checked = isAutoBackupEnabled,
                    onCheckedChange = { enabled ->
                        isAutoBackupEnabled = enabled
                        if (enabled) {
                            DharmapuriBackupWorker.schedulePeriodicBackup(context, selectedTimeframe.days, selectedDistrict)
                            onShowToast("WorkManager Auto-Backup scheduled every ${selectedTimeframe.titleEn} for $selectedDistrict!")
                        } else {
                            onShowToast("Auto-Backup disabled.")
                        }
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = GoldPrimary,
                        checkedTrackColor = SkyBluePrimary
                    )
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Backup & Export Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        isBackingUp = true
                        DharmapuriBackupWorker.triggerImmediateBackup(context, selectedTimeframe.days, selectedDistrict)
                        lastBackupTime = "2026-07-25 05:48"
                        isBackingUp = false
                        onShowToast("WorkManager task enqueued: Backing up $selectedDistrict data (${selectedTimeframe.titleEn})!")
                    },
                    enabled = !isBackingUp,
                    colors = ButtonDefaults.buttonColors(containerColor = SkyBluePrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    if (isBackingUp) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            color = Color.White,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "SAVING...", fontSize = 11.sp)
                    } else {
                        Icon(
                            imageVector = Icons.Default.CloudUpload,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "BACKUP NOW", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                OutlinedButton(
                    onClick = {
                        onShowToast("Downloaded $selectedDistrict details (${selectedTimeframe.titleEn}) as JSON & PDF!")
                    },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.CloudDownload,
                        contentDescription = null,
                        tint = GoldDark,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "EXPORT PDF",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldDark
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Last Backup Stats Banner
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = null,
                        tint = Color.Gray,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Last Backup: $lastBackupTime",
                        fontSize = 10.sp,
                        color = Color.Gray
                    )
                }

                Text(
                    text = "Dharmapuri & Tamil Nadu Verified",
                    fontSize = 10.sp,
                    color = SkyBluePrimary,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
