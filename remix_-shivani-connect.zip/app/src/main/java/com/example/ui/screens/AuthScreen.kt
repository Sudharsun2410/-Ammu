package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.Language
import com.example.model.UserRole
import com.example.ui.components.GlassCard
import com.example.ui.theme.PinkPrimary
import com.example.ui.theme.PinkSecondary
import com.example.ui.theme.PurplePrimary

@Composable
fun AuthScreen(
    currentLanguage: Language,
    onBackClick: () -> Unit,
    onAuthSuccess: (String, UserRole) -> Unit,
    onShowToast: (String) -> Unit
) {
    var isLoginTab by remember { mutableStateOf(true) }

    // Form fields - Login
    var loginIdentifier by remember { mutableStateOf("") }
    var loginPassword by remember { mutableStateOf("") }
    var rememberMe by remember { mutableStateOf(true) }
    var showLoginPassword by remember { mutableStateOf(false) }

    // Form fields - Registration
    var regFullName by remember { mutableStateOf("") }
    var regMobile by remember { mutableStateOf("") }
    var regEmail by remember { mutableStateOf("") }
    var regPassword by remember { mutableStateOf("") }
    var regConfirmPassword by remember { mutableStateOf("") }
    var selectedUserType by remember { mutableStateOf("User") } // User / Vendor / Admin
    var otpCode by remember { mutableStateOf("") }
    var isOtpSent by remember { mutableStateOf(false) }
    var isOtpVerified by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFFFFF0F5), // Lavender Blush Pink
                        Color(0xFFFFF7F9), // Creamy White Pink
                        Color(0xFFFFFFFF)  // Pure White
                    )
                )
            ),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Navigation Bar (Clean Centered Title)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Shivani Hub Login",
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Shivani Hub Brand Logo Badge
            Box(
                modifier = Modifier
                    .size(86.dp)
                    .clip(CircleShape)
                    .border(2.5.dp, Brush.linearGradient(listOf(PinkPrimary, PinkSecondary)), CircleShape)
                    .background(Color.White),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.sk_shivani_skhub_logo_1785082786285),
                    contentDescription = "Shivani Hub Logo",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = if (isLoginTab) "Welcome Back!" else "Create Account",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.onBackground
            )

            Text(
                text = if (isLoginTab) "Sign in to manage your event bookings & orders"
                else "Join Shivani Connect for village services & marketplace",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            // White + Pink Glassmorphism Toggle Tabs: Login / Register
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.White)
                    .border(1.5.dp, PinkPrimary.copy(alpha = 0.3f), RoundedCornerShape(20.dp))
                    .padding(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (isLoginTab) PinkPrimary else Color.Transparent)
                        .clickable { isLoginTab = true }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (currentLanguage == Language.TAMIL) "உள்நுழைவு" else "Login",
                        fontWeight = FontWeight.Bold,
                        color = if (isLoginTab) Color.White else MaterialTheme.colorScheme.onBackground
                    )
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (!isLoginTab) PinkPrimary else Color.Transparent)
                        .clickable { isLoginTab = false }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (currentLanguage == Language.TAMIL) "பதிவு செய்ய" else "Register",
                        fontWeight = FontWeight.Bold,
                        color = if (!isLoginTab) Color.White else MaterialTheme.colorScheme.onBackground
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // White + Pink Glassmorphism Form Card
            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                elevation = 6.dp,
                shape = RoundedCornerShape(26.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    AnimatedVisibility(
                        visible = isLoginTab,
                        enter = fadeIn(),
                        exit = fadeOut()
                    ) {
                        Column {
                            // LOGIN FORM
                            Text(
                                text = if (currentLanguage == Language.TAMIL) "பயனாளர் பெயர் (User Name)" else "User Name",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = loginIdentifier,
                                onValueChange = { loginIdentifier = it },
                                placeholder = { Text(if (currentLanguage == Language.TAMIL) "உங்கள் பெயரை உள்ளிடவும் (Enter your name)" else "Enter your name", fontSize = 13.sp) },
                                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = PinkPrimary) },
                                singleLine = true,
                                shape = RoundedCornerShape(16.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = PinkPrimary,
                                    unfocusedBorderColor = PinkPrimary.copy(alpha = 0.3f),
                                    focusedContainerColor = Color.White,
                                    unfocusedContainerColor = Color.White
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            Text(
                                text = "Password",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = loginPassword,
                                onValueChange = { loginPassword = it },
                                placeholder = { Text("Enter your password", fontSize = 13.sp) },
                                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = PinkPrimary) },
                                trailingIcon = {
                                    IconButton(onClick = { showLoginPassword = !showLoginPassword }) {
                                        Icon(
                                            imageVector = if (showLoginPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                            contentDescription = "Toggle Password"
                                        )
                                    }
                                },
                                visualTransformation = if (showLoginPassword) VisualTransformation.None else PasswordVisualTransformation(),
                                singleLine = true,
                                shape = RoundedCornerShape(16.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = PinkPrimary,
                                    unfocusedBorderColor = PinkPrimary.copy(alpha = 0.3f),
                                    focusedContainerColor = Color.White,
                                    unfocusedContainerColor = Color.White
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(
                                        checked = rememberMe,
                                        onCheckedChange = { rememberMe = it },
                                        colors = CheckboxDefaults.colors(checkedColor = PinkPrimary)
                                    )
                                    Text("Remember Me", fontSize = 12.sp)
                                }

                                TextButton(onClick = { onShowToast("Password reset link sent to your mobile/email!") }) {
                                    Text("Forgot Password?", fontSize = 12.sp, color = PinkPrimary, fontWeight = FontWeight.Bold)
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Button(
                                onClick = {
                                    if (loginIdentifier.isBlank()) {
                                        onShowToast(if (currentLanguage == Language.TAMIL) "தயவுசெய்து பயனர் பெயரை உள்ளிடவும்" else "Please enter User Name")
                                    } else {
                                        val role = if (loginIdentifier.contains("admin")) UserRole.ADMIN
                                        else if (loginIdentifier.contains("vendor")) UserRole.VENDOR
                                        else UserRole.USER

                                        onAuthSuccess(loginIdentifier, role)
                                        onShowToast("Login Successful! Welcome to Shivani Connect")
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                            ) {
                                Text("LOGIN NOW", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            }

                            Spacer(modifier = Modifier.height(20.dp))

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                HorizontalDivider(modifier = Modifier.weight(1f), color = PinkPrimary.copy(alpha = 0.2f))
                                Text(
                                    "  OR  ",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                                )
                                HorizontalDivider(modifier = Modifier.weight(1f), color = PinkPrimary.copy(alpha = 0.2f))
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            OutlinedButton(
                                onClick = {
                                    onAuthSuccess("google_user@gmail.com", UserRole.USER)
                                    onShowToast("Signed in with Google Account!")
                                },
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("🌐 Sign in with Google", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedButton(
                                onClick = { onShowToast("OTP Code sent to registered mobile number: 4281") },
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(imageVector = Icons.Default.Phone, contentDescription = null, tint = PinkPrimary, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Login with Mobile OTP", fontWeight = FontWeight.Bold, color = PinkPrimary)
                            }
                        }
                    }

                    AnimatedVisibility(
                        visible = !isLoginTab,
                        enter = fadeIn(),
                        exit = fadeOut()
                    ) {
                        Column {
                            // REGISTRATION FORM
                            Text("Full Name", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            OutlinedTextField(
                                value = regFullName,
                                onValueChange = { regFullName = it },
                                placeholder = { Text("Enter your name", fontSize = 13.sp) },
                                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = PinkPrimary) },
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Text("Mobile Number", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            OutlinedTextField(
                                value = regMobile,
                                onValueChange = { regMobile = it },
                                placeholder = { Text("Phone number", fontSize = 13.sp) },
                                leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = PinkPrimary) },
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Text("Email Address", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            OutlinedTextField(
                                value = regEmail,
                                onValueChange = { regEmail = it },
                                placeholder = { Text("Enter your email", fontSize = 13.sp) },
                                leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = PinkPrimary) },
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Text("Password", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            OutlinedTextField(
                                value = regPassword,
                                onValueChange = { regPassword = it },
                                placeholder = { Text("Create password", fontSize = 13.sp) },
                                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = PinkPrimary) },
                                visualTransformation = PasswordVisualTransformation(),
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Text("Select User Type", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                listOf("User", "Vendor", "Admin").forEach { type ->
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(if (selectedUserType == type) PinkPrimary.copy(alpha = 0.15f) else Color.Transparent)
                                            .clickable { selectedUserType = type }
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        RadioButton(
                                            selected = selectedUserType == type,
                                            onClick = { selectedUserType = type },
                                            colors = RadioButtonDefaults.colors(selectedColor = PinkPrimary)
                                        )
                                        Text(type, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            // Dynamic Role Capabilities Banner
                            Spacer(modifier = Modifier.height(6.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(
                                        when (selectedUserType) {
                                            "Admin" -> Color(0xFFFEF2F2)
                                            "Vendor" -> Color(0xFFEFF6FF)
                                            else -> Color(0xFFF0FDF4)
                                        }
                                    )
                                    .border(
                                        1.dp,
                                        when (selectedUserType) {
                                            "Admin" -> Color(0xFFFCA5A5)
                                            "Vendor" -> Color(0xFF93C5FD)
                                            else -> Color(0xFF86EFAC)
                                        },
                                        RoundedCornerShape(12.dp)
                                    )
                                    .padding(10.dp)
                            ) {
                                Column {
                                    Text(
                                        text = when (selectedUserType) {
                                            "Admin" -> "👑 ADMIN PERMISSIONS (Full System Control)"
                                            "Vendor" -> "🛠️ VENDOR PERMISSIONS (Execute & Maintain)"
                                            else -> "👤 USER PERMISSIONS (View, Book & Pay)"
                                        },
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = when (selectedUserType) {
                                            "Admin" -> Color(0xFF991B1B)
                                            "Vendor" -> Color(0xFF1E40AF)
                                            else -> Color(0xFF166534)
                                        }
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = when (selectedUserType) {
                                            "Admin" -> "Manage all venues, products, vendor operations, user bookings & secure access control with top safety."
                                            "Vendor" -> "Handle & maintain user requests/orders, complete assigned tasks and share operational info securely with admin."
                                            else -> "View venues, check date availability, place bookings, pay securely via PhonePe, GPay or Credit Card, and order store items."
                                        },
                                        fontSize = 10.5.sp,
                                        color = Color.DarkGray
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Text("OTP Verification", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedTextField(
                                    value = otpCode,
                                    onValueChange = { otpCode = it },
                                    placeholder = { Text("Enter OTP", fontSize = 13.sp) },
                                    singleLine = true,
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.weight(1f)
                                )

                                Button(
                                    onClick = {
                                        if (isOtpSent) {
                                            isOtpVerified = true
                                            onShowToast("OTP Verified Successfully! ✓")
                                        } else {
                                            isOtpSent = true
                                            otpCode = "7890"
                                            onShowToast("OTP sent to mobile! Auto-filled code: 7890")
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = if (isOtpVerified) Color(0xFF16A34A) else PurplePrimary),
                                    shape = RoundedCornerShape(14.dp)
                                ) {
                                    Text(
                                        if (isOtpVerified) "VERIFIED ✓" else if (isOtpSent) "VERIFY OTP" else "SEND OTP",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(20.dp))

                            Button(
                                onClick = {
                                    if (regFullName.isBlank() || regMobile.isBlank()) {
                                        onShowToast("Please fill in your name and mobile number")
                                    } else {
                                        val role = when (selectedUserType) {
                                            "Vendor" -> UserRole.VENDOR
                                            "Admin" -> UserRole.ADMIN
                                            else -> UserRole.USER
                                        }
                                        onAuthSuccess(regEmail.ifBlank { regMobile }, role)
                                        onShowToast("Account created successfully as $selectedUserType!")
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                            ) {
                                Text("REGISTER ACCOUNT", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            }
                        }
                    }
                }
            }

            // Global Footer
            Spacer(modifier = Modifier.height(30.dp))
            HorizontalDivider(
                modifier = Modifier.padding(horizontal = 40.dp),
                color = PinkPrimary.copy(alpha = 0.2f)
            )
            Spacer(modifier = Modifier.height(14.dp))

            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "© 2026 Shivani Hub. All Rights Reserved.",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}
