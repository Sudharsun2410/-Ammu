package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CurrencyRupee
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Language
import com.example.ui.components.GlassCard
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.PinkPrimary
import com.example.ui.theme.PurplePrimary

data class JobOpening(
    val id: String,
    val titleEn: String,
    val titleTa: String,
    val company: String,
    val jobType: String, // "Part-Time" or "Full-Time"
    val payAmount: String,
    val location: String,
    val timing: String,
    val iconEmoji: String,
    val contactPhone: String
)

val sampleJobOpenings = listOf(
    JobOpening(
        id = "j1",
        titleEn = "Catering Feast Helper & Server",
        titleTa = "திருமண விருந்து பரிமாறுபவர்",
        company = "Sri Madurai Caterers",
        jobType = "Part-Time",
        payAmount = "₹800 / day + Food",
        location = "Alanganallur, Madurai",
        timing = "7:00 AM - 3:00 PM (8 Hrs)",
        iconEmoji = "🍲",
        contactPhone = "+91 98421 23456"
    ),
    JobOpening(
        id = "j2",
        titleEn = "Kalyana Mandapam Supervisor",
        titleTa = "திருமண மண்டப மேலாளர்",
        company = "Shivani Royal Palace",
        jobType = "Full-Time",
        payAmount = "₹28,000 / month",
        location = "Madurai Main Road",
        timing = "Shift Basis (Full Day)",
        iconEmoji = "🏰",
        contactPhone = "+91 98421 99887"
    ),
    JobOpening(
        id = "j3",
        titleEn = "Flower Decoration Assistant",
        titleTa = "பூ அலங்கார உதவியாளர்",
        company = "Mullai Floral Arts",
        jobType = "Part-Time",
        payAmount = "₹650 / event",
        location = "Vadipatti, Madurai",
        timing = "4:00 AM - 10:00 AM",
        iconEmoji = "🌸",
        contactPhone = "+91 94431 11223"
    ),
    JobOpening(
        id = "j4",
        titleEn = "Event Lead Photographer",
        titleTa = "நிகழ்ச்சி தலைமை புகைப்படக் கலைஞர்",
        company = "Pixel Moments Studio",
        jobType = "Full-Time",
        payAmount = "₹35,000 / month",
        location = "Tallakulam, Madurai",
        timing = "Flexible Shift",
        iconEmoji = "📸",
        contactPhone = "+91 97890 54321"
    ),
    JobOpening(
        id = "j5",
        titleEn = "Sound & DJ Light Technician",
        titleTa = "ஒலி பெருக்கி & மின் வெளிச்ச உதவியாளர்",
        company = "Raja Sound Systems",
        jobType = "Part-Time",
        payAmount = "₹1,200 / night",
        location = "Melur, Madurai",
        timing = "6:00 PM - 11:00 PM",
        iconEmoji = "🔊",
        contactPhone = "+91 98940 12389"
    )
)

@Composable
fun JobsWorkScreen(
    currentLanguage: Language,
    onShowToast: (String) -> Unit = {}
) {
    var selectedWorkTypeTab by remember { mutableIntStateOf(0) } // 0: Part-Time, 1: Full-Time, 2: Social Media & Dev Profit
    var userRewardPoints by remember { mutableIntStateOf(450) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 80.dp)
    ) {
        // Top Header Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brush.linearGradient(listOf(PinkPrimary, PurplePrimary)))
                .padding(16.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (currentLanguage == Language.TAMIL) "💼 வேலை வாய்ப்பு & வருமானம்" else "💼 Work & Career Portal",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                        Text(
                            text = if (currentLanguage == Language.TAMIL) "பகுதி நேர / முழு நேர வேலை & ஆப் விளம்பர வருவாய்" else "Part-Time, Full-Time Jobs & Developer Profit Hub",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }

                    // Developer Coins Badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White.copy(alpha = 0.2f))
                            .border(1.dp, Color.White.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("🪙", fontSize = 14.sp)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "$userRewardPoints Pts",
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }

        // Sub-Navigation Tabs: Part-Time Work | Full-Time Work | Social & Dev Profit
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            val tabs = listOf(
                Triple(0, "⏱️ " + (if (currentLanguage == Language.TAMIL) "பகுதி நேரம்" else "Part-Time"), Color(0xFF10B981)),
                Triple(1, "💼 " + (if (currentLanguage == Language.TAMIL) "முழு நேரம்" else "Full-Time"), Color(0xFF3B82F6)),
                Triple(2, "📲 " + (if (currentLanguage == Language.TAMIL) "சமூக ஊடகம் & ஆப் லாபம்" else "Social & Dev Profit"), PinkPrimary)
            )

            tabs.forEach { (index, title, accentColor) ->
                val isSelected = selectedWorkTypeTab == index
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (isSelected) accentColor else MaterialTheme.colorScheme.surface)
                        .border(1.dp, if (isSelected) accentColor else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                        .clickable { selectedWorkTypeTab = index }
                        .padding(vertical = 10.dp, horizontal = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = title,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onBackground
                    )
                }
            }
        }

        // Body Content based on Tab
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when (selectedWorkTypeTab) {
                0 -> { // Part-Time Jobs
                    item {
                        Text(
                            text = if (currentLanguage == Language.TAMIL) "⏱️ கிடைக்கும் பகுதி நேர வேலைகள் (தினசரி கூலி)" else "⏱️ Live Part-Time Openings (Daily Wage)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }

                    val partTimeJobs = sampleJobOpenings.filter { it.jobType == "Part-Time" }
                    items(partTimeJobs) { job ->
                        JobCardView(job = job, currentLanguage = currentLanguage, onShowToast = onShowToast)
                    }
                }

                1 -> { // Full-Time Jobs
                    item {
                        Text(
                            text = if (currentLanguage == Language.TAMIL) "💼 நிரந்தர முழு நேர வேலைகள் (மாத சம்பளம்)" else "💼 Permanent Full-Time Careers (Monthly Salary)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }

                    val fullTimeJobs = sampleJobOpenings.filter { it.jobType == "Full-Time" }
                    items(fullTimeJobs) { job ->
                        JobCardView(job = job, currentLanguage = currentLanguage, onShowToast = onShowToast)
                    }
                }

                2 -> { // Social Media & Dev Profit Engine
                    item {
                        // Developer Profit Notice Card
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(18.dp)),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)),
                            border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFF59E0B))
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.MonetizationOn,
                                        contentDescription = "Dev Revenue",
                                        tint = Color(0xFFD97706),
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (currentLanguage == Language.TAMIL) "💡 ஆப் உருவாக்குனரின் வருவாய் மையம் (Developer Profit Hub)" else "💡 App Developer Revenue & Monetization Engine",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Black,
                                        color = Color(0xFF78350F)
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = if (currentLanguage == Language.TAMIL)
                                        "நீங்கள் இந்த விளம்பரங்களை பார்ப்பதன் மூலமும், சமூக ஊடகங்களை பகிர்வதன் மூலமும் பெறப்படும் வருவாய் (Ad Revenue / Referral Commission) இந்த ஷிவானி ஹப் ஆப்பை தொடர்ந்து இலவசமாக செயல்படுத்த உதவுகிறது! "
                                    else
                                        "By watching sponsored ads, following social channels, and sharing referral links, ad revenue & commissions generated directly profit the App Developer to support cloud server hosting & continuous updates!",
                                    fontSize = 11.sp,
                                    color = Color(0xFF92400E),
                                    lineHeight = 16.sp
                                )
                            }
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (currentLanguage == Language.TAMIL) "📺 விளம்பரம் பார்த்து ஆப் டெவலப்பருக்கு ஆதரவளிக்கவும் (Ad Revenue)" else "📺 Watch Sponsored Ads to Support App Developer",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }

                    // Sponsored Ad Unit Card (Generates Developer Ad Profit)
                    item {
                        GlassCard(
                            modifier = Modifier.fillMaxWidth(),
                            elevation = 4.dp
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.PlayCircle,
                                            contentDescription = "Ad",
                                            tint = PinkPrimary,
                                            modifier = Modifier.size(28.dp)
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = if (currentLanguage == Language.TAMIL) "ஸ்பான்சர் செய்த விளம்பரம் (15 நொடிகள்)" else "Sponsored Brand Video Ad (15 Sec)",
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = "+100 Coins • Developer Earns ₹12 Ad Revenue",
                                                fontSize = 10.sp,
                                                color = PinkPrimary,
                                                fontWeight = FontWeight.ExtraBold
                                            )
                                        }
                                    }

                                    Button(
                                        onClick = {
                                            userRewardPoints += 100
                                            onShowToast("▶️ Ad Watched! +100 Coins added & Developer generated ₹12 Ad Profit!")
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                                        shape = RoundedCornerShape(12.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                    ) {
                                        Text("Watch Ad 🎬", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (currentLanguage == Language.TAMIL) "📲 அதிகாரப்பூர்வ சமூக ஊடக பக்கங்கள் (Social Media Channels)" else "📲 Official Social Media Channels",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }

                    // Social Media Channels List
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            SocialMediaLinkItem(
                                name = "Official WhatsApp Channel",
                                icon = "💬",
                                color = Color(0xFF25D366),
                                desc = "Daily Marriage Mandapam Offers & Jobs",
                                onFollow = { onShowToast("Opening Shivani Hub WhatsApp Channel!") }
                            )
                            SocialMediaLinkItem(
                                name = "Instagram Page (@shivanihub)",
                                icon = "📸",
                                color = Color(0xFFE1306C),
                                desc = "Event Decorations, Reels & Photo Highlights",
                                onFollow = { onShowToast("Opening Instagram Page!") }
                            )
                            SocialMediaLinkItem(
                                name = "YouTube Channel (Shivani Connect)",
                                icon = "▶️",
                                color = Color(0xFFFF0000),
                                desc = "Live Event Coverage & Mandapam Virtual Tours",
                                onFollow = { onShowToast("Opening YouTube Channel!") }
                            )
                            SocialMediaLinkItem(
                                name = "Telegram Community Group",
                                icon = "✈️",
                                color = Color(0xFF0088CC),
                                desc = "Direct Worker & Vendor Chat Network",
                                onFollow = { onShowToast("Opening Telegram Group!") }
                            )
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(6.dp))
                        // Referral Link Share Card (Generates Organic Growth for Developer)
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(18.dp)),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF3B82F6))
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = if (currentLanguage == Language.TAMIL) "🚀 ஆப்பை நண்பர்களுடன் பகிரவும்" else "🚀 Share App & Boost Developer Reach",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Black,
                                            color = Color(0xFF1E3A8A)
                                        )
                                        Text(
                                            text = if (currentLanguage == Language.TAMIL) "WhatsApp குழுவில் பகிர்ந்து பலருக்கு வேலை பெற உதவுங்கள்!" else "Share with friends to increase user traffic & developer profit",
                                            fontSize = 10.5.sp,
                                            color = Color(0xFF2563EB)
                                        )
                                    }

                                    Button(
                                        onClick = { onShowToast("App Referral Link Copied! Share on WhatsApp to help Developer!") },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(imageVector = Icons.Default.Share, contentDescription = "Share", modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Share Link", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun JobCardView(
    job: JobOpening,
    currentLanguage: Language,
    onShowToast: (String) -> Unit
) {
    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        elevation = 4.dp
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(PinkPrimary.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(job.iconEmoji, fontSize = 20.sp)
                    }

                    Column {
                        Text(
                            text = if (currentLanguage == Language.TAMIL) job.titleTa else job.titleEn,
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Business, contentDescription = null, tint = PinkPrimary, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = job.company,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                            )
                        }
                    }
                }

                // Job Type Tag
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (job.jobType == "Part-Time") Color(0xFFDCFCE7) else Color(0xFFDBEAFE))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = job.jobType,
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (job.jobType == "Part-Time") Color(0xFF15803D) else Color(0xFF1E40AF)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Details Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.LocationOn, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = job.location, fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f))
                }

                Text(
                    text = "⏰ ${job.timing}",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Salary & Apply Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (currentLanguage == Language.TAMIL) "சம்பளம் / கூலி" else "SALARY / WAGE",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                    )
                    Text(
                        text = job.payAmount,
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp,
                        color = PinkPrimary
                    )
                }

                Button(
                    onClick = { onShowToast("Connecting Call to ${job.company} (${job.contactPhone})") },
                    colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(if (currentLanguage == Language.TAMIL) "விண்ணப்பிக்க 📞" else "Apply Now 📞", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun SocialMediaLinkItem(
    name: String,
    icon: String,
    color: Color,
    desc: String,
    onFollow: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White)
            .border(1.dp, color.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
            .clickable { onFollow() }
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(color.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(icon, fontSize = 18.sp)
                }

                Column {
                    Text(text = name, fontWeight = FontWeight.Bold, fontSize = 12.5.sp, color = MaterialTheme.colorScheme.onBackground)
                    Text(text = desc, fontSize = 9.5.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
                }
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(color)
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
                Text("Join / Follow", color = Color.White, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
