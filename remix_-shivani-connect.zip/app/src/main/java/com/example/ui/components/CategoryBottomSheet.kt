package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SheetState
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.EventCategory
import com.example.model.Language
import com.example.model.SampleData
import com.example.ui.theme.PinkPrimary
import com.example.ui.theme.PinkSecondary
import com.example.ui.theme.PurplePrimary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CategoryBottomSheet(
    currentLanguage: Language,
    onDismiss: () -> Unit,
    onCategorySelected: (EventCategory) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var filterText by remember { mutableStateOf("") }

    val categories = SampleData.sampleCategories.filter { cat ->
        if (filterText.isBlank()) true
        else cat.nameEn.contains(filterText, ignoreCase = true) || cat.nameTa.contains(filterText, ignoreCase = true)
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            // Drag Handle Indicator
            Box(
                modifier = Modifier
                    .width(48.dp)
                    .height(5.dp)
                    .clip(CircleShape)
                    .background(PinkPrimary.copy(alpha = 0.3f))
                    .align(Alignment.CenterHorizontally)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (currentLanguage == Language.TAMIL) "சேவை வகையைத் தேர்ந்தெடுக்கவும்" else "Select Service Category",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = if (currentLanguage == Language.TAMIL) "15 பிரீமியம் திருமண & நிகழ்வு சேவைகள்" else "Explore 15 Premium Event & Vendor Categories",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(PinkPrimary.copy(alpha = 0.1f))
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = PinkPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Quick Actions Banner inside Plus Icon Modal
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(vertical = 2.dp)
            ) {
                item {
                    QuickActionPill("➕ Custom Booking", Color(0xFFE11D48)) {
                        onCategorySelected(SampleData.sampleCategories.first())
                        onDismiss()
                    }
                }
                item {
                    QuickActionPill("🛍️ Add Product", Color(0xFF059669)) {
                        onCategorySelected(SampleData.sampleCategories[1])
                        onDismiss()
                    }
                }
                item {
                    QuickActionPill("💼 Post Job Opening", Color(0xFFD97706)) {
                        onCategorySelected(SampleData.sampleCategories[2])
                        onDismiss()
                    }
                }
                item {
                    QuickActionPill("ℹ️ Info Service", Color(0xFF2563EB)) {
                        onCategorySelected(SampleData.sampleCategories[3])
                        onDismiss()
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Search Bar Filter
            OutlinedTextField(
                value = filterText,
                onValueChange = { filterText = it },
                placeholder = {
                    Text(
                        if (currentLanguage == Language.TAMIL) "வகை தேடுக..." else "Search category (Wedding, Catering, Photo...)",
                        fontSize = 13.sp
                    )
                },
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = PinkPrimary)
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PinkPrimary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(14.dp))

            // 15 Categories Grid with Unique Badges & Card Styles
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(390.dp)
            ) {
                items(categories) { category ->
                    CategoryItemCard(
                        category = category,
                        currentLanguage = currentLanguage,
                        onClick = {
                            onCategorySelected(category)
                            onDismiss()
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun QuickActionPill(
    label: String,
    color: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(color.copy(alpha = 0.12f))
            .border(1.dp, color.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(text = label, fontSize = 11.5.sp, fontWeight = FontWeight.Black, color = color)
    }
}

@Composable
private fun CategoryItemCard(
    category: EventCategory,
    currentLanguage: Language,
    onClick: () -> Unit
) {
    val categoryColor = Color(category.colorHex)
    val badgeText = when (category.id) {
        "cat_marriage_hall" -> "👑 HALL"
        "cat_catering" -> "🔥 FEAST"
        "cat_decor" -> "✨ DECOR"
        "cat_photo" -> "⭐ 4K"
        "cat_music" -> "🎵 LIVE"
        "cat_makeup" -> "💄 GLAM"
        "cat_priest" -> "🪔 PUJA"
        "cat_invitation" -> "💌 PRINT"
        "cat_crackers" -> "💥 FIRE"
        "cat_bus" -> "🚌 AC"
        "cat_security" -> "🛡️ SAFE"
        "cat_return_gifts" -> "🎁 GIFTS"
        "cat_baking" -> "🎂 CAKE"
        "cat_garlands" -> "🌸 FRESH"
        else -> "🌟 TOP"
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(categoryColor.copy(alpha = 0.08f))
            .border(1.5.dp, categoryColor.copy(alpha = 0.35f), RoundedCornerShape(20.dp))
            .clickable { onClick() }
            .padding(10.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            // Unique Category Top Badge
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(categoryColor)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = badgeText,
                    fontSize = 8.5.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            listOf(
                                categoryColor.copy(alpha = 0.3f),
                                categoryColor.copy(alpha = 0.1f)
                            )
                        )
                    )
                    .border(1.2.dp, categoryColor, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = category.iconEmoji,
                    fontSize = 22.sp
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = if (currentLanguage == Language.TAMIL) category.nameTa else category.nameEn,
                fontSize = 11.sp,
                fontWeight = FontWeight.Black,
                color = categoryColor,
                textAlign = TextAlign.Center,
                maxLines = 2,
                lineHeight = 13.sp
            )
        }
    }
}
