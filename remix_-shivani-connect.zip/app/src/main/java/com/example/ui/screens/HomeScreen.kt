package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.speech.RecognizerIntent
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material.icons.filled.Close
import androidx.compose.ui.window.Dialog
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import com.example.data.WishlistItemEntity
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.BookingEntity
import com.example.model.Language
import com.example.model.MarketProduct
import com.example.model.SampleData
import com.example.model.VenueOrService
import com.example.ui.components.GlassBadge
import com.example.ui.components.GlassCard
import com.example.ui.components.InteractiveLocationMapCard
import com.example.ui.components.StarRating
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.PinkDark
import com.example.ui.theme.PinkPrimary
import com.example.ui.theme.PinkSecondary

@Composable
fun HomeScreen(
    district: String,
    village: String,
    searchQuery: String,
    selectedCategory: String?,
    lastBooking: BookingEntity?,
    currentLanguage: Language,
    onSearchChange: (String) -> Unit,
    onCategorySelect: (String) -> Unit,
    onBookVenueClick: (VenueOrService) -> Unit,
    onViewProductClick: (MarketProduct) -> Unit,
    onOpenMapClick: () -> Unit,
    onOpenAiClick: () -> Unit,
    onPrinterClick: () -> Unit = {},
    onOpenSettingsClick: () -> Unit = {},
    wishlistItems: List<WishlistItemEntity> = emptyList(),
    onToggleWishlist: (VenueOrService) -> Unit = {},
    onNextProcessClick: () -> Unit = {}
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    var animateEvents by remember { mutableStateOf(false) }
    var showServiceDirectoryList by remember { mutableStateOf(false) }
    var showNotificationsDialog by remember { mutableStateOf(false) }
    var hasUnreadNotifications by remember { mutableStateOf(true) }
    var liveNotifications by remember {
        mutableStateOf(
            listOf(
                Triple("🏰 Harur Royal Mahal", if (currentLanguage == Language.TAMIL) "ஹரூர் மஹால் மேப் சேர்க்கப்பட்டது! பார்க்க கிளிக் செய்யவும்." else "Harur Mahal added to live Google Maps!", "Just now"),
                Triple("🍲 Dharmapuri Sri Murugan Catering", if (currentLanguage == Language.TAMIL) "தர்மபுரி கேட்டரிங் ஆஃபர் - ₹180/இலை." else "Dharmapuri special leaf booking offer live.", "5m ago"),
                Triple("👑 Salem Royal Palace", if (currentLanguage == Language.TAMIL) "சேலம் பேலஸ் முன்பதிவு திறக்கப்பட்டது." else "Salem Royal Palace bookings open with map directions.", "15m ago"),
                Triple("🎉 Shivani Hub FCM Update", if (currentLanguage == Language.TAMIL) "நேரலை அறிவிப்புகள் இயக்கப்பட்டன." else "Live FCM push notification engine connected.", "1h ago")
            )
        )
    }
    LaunchedEffect(Unit) {
        animateEvents = true
    }

    // Voice Search Launcher
    val voiceLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val spokenResults = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spokenText = spokenResults?.firstOrNull()
            if (!spokenText.isNullOrBlank()) {
                onSearchChange(spokenText)
            }
        }
    }

    fun startVoiceSearch() {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (currentLanguage == Language.TAMIL) "ta-IN" else "en-IN")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Search Shivani Hub...")
            }
            voiceLauncher.launch(intent)
        } catch (e: Exception) {
            Log.e("sk", "Voice search error", e)
        }
    }

    // Soft Pink + White Glassmorphism Background Container
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFFFFF0F5), // Lavender Blush Pink
                        Color(0xFFFFF7F9), // Creamy White Pink
                        Color(0xFFFFFFFF)  // Pure White
                    )
                )
            ),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 700.dp)
                .verticalScroll(scrollState)
                .padding(bottom = 90.dp)
        ) {
            // ==========================================
            // 1. BRAND HEADER WITH SHIVANI CONNECT LOGO
            // ==========================================
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Shivani Connect Logo Badge
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                            .border(2.dp, Brush.linearGradient(listOf(PinkPrimary, PinkSecondary)), CircleShape)
                            .background(Color.White),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.sk_shivani_skhub_logo_1785082786285),
                            contentDescription = "Shivani Connect Logo",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                        )
                    }

                    Column {
                        Text(
                            text = "Shivani Hub",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = if (currentLanguage == Language.TAMIL) "இணைப்போம் • சேவிப்போம் • வளர்வோம்" else "CONNECT • SERVE • GROW",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = PinkPrimary,
                            letterSpacing = 0.5.sp
                        )
                    }
                }

                // Top Right: Live Notification Bell, Thermal Printer & Settings Chip
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // LIVE NOTIFICATION BELL ICON
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color.White)
                            .border(1.5.dp, PinkPrimary.copy(alpha = 0.5f), CircleShape)
                            .clickable {
                                hasUnreadNotifications = false
                                showNotificationsDialog = true
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (hasUnreadNotifications) Icons.Default.NotificationsActive else Icons.Default.Notifications,
                            contentDescription = "Notifications",
                            tint = if (hasUnreadNotifications) Color(0xFFEF4444) else PinkPrimary,
                            modifier = Modifier.size(19.dp)
                        )

                        if (hasUnreadNotifications) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFEF4444))
                                    .border(1.5.dp, Color.White, CircleShape)
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color.White)
                            .border(1.5.dp, PinkPrimary.copy(alpha = 0.4f), CircleShape)
                            .clickable { onPrinterClick() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Print,
                            contentDescription = "Thermal Printer",
                            tint = PinkPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(Color.White)
                            .border(1.5.dp, PinkPrimary.copy(alpha = 0.5f), CircleShape)
                            .clickable { onOpenSettingsClick() }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Settings, contentDescription = "Settings", tint = PinkPrimary, modifier = Modifier.size(17.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (currentLanguage == Language.TAMIL) "அமைப்புகள்" else "Settings",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        }
                    }
                }
            }

            // ==========================================
            // 2. HERO GLASSMORPHISM BANNER
            // ==========================================
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    elevation = 6.dp,
                    shape = RoundedCornerShape(26.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(
                                        Color(0xFFFFF1F2).copy(alpha = 0.85f),
                                        Color(0xFFFCE7F3).copy(alpha = 0.70f),
                                        Color(0xFFFFFFFF).copy(alpha = 0.90f)
                                    )
                                )
                            )
                            .padding(18.dp)
                    ) {
                        GlassBadge(
                            text = if (currentLanguage == Language.TAMIL) "🙏 வணக்கம்! தமிழ்நாடு கிராம சேவை தளம்" else "🙏 Vanakkam! Tamil Nadu Village Hub",
                            containerColor = PinkPrimary.copy(alpha = 0.15f),
                            contentColor = PinkPrimary
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = if (currentLanguage == Language.TAMIL) "திருமண மண்டபங்கள், சமையல் & இ-காமர்ஸ் சந்தை" else "Book Kalyana Mandapams, Catering & Shop Direct",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.onBackground
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Search Bar Input
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = onSearchChange,
                            placeholder = {
                                Text(
                                    text = if (currentLanguage == Language.TAMIL) "மண்டபம், சமையல், புடவை தேடுக..." else "Search halls, catering, saree, marketplace...",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                                )
                            },
                            leadingIcon = {
                                Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = PinkPrimary)
                            },
                            trailingIcon = {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(PinkPrimary.copy(alpha = 0.15f))
                                        .clickable { startVoiceSearch() },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("🎤", fontSize = 14.sp)
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(20.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = Color.White,
                                unfocusedContainerColor = Color.White.copy(alpha = 0.9f),
                                focusedBorderColor = PinkPrimary,
                                unfocusedBorderColor = PinkPrimary.copy(alpha = 0.3f)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Quick Action Pill Buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            QuickPillButton(
                                label = if (currentLanguage == Language.TAMIL) "மண்டபங்கள்" else "Halls",
                                iconEmoji = "🏰",
                                modifier = Modifier.weight(1f)
                            ) { onCategorySelect("halls") }

                            QuickPillButton(
                                label = if (currentLanguage == Language.TAMIL) "சந்தை" else "Market",
                                iconEmoji = "🛍️",
                                modifier = Modifier.weight(1f)
                            ) { onViewProductClick(SampleData.sampleMarketProducts.first()) }

                            QuickPillButton(
                                label = if (currentLanguage == Language.TAMIL) "வரைபடம்" else "TN Map",
                                iconEmoji = "🗺️",
                                modifier = Modifier.weight(1f)
                            ) { onOpenMapClick() }
                        }
                    }
                }
            }

            // ==========================================
            // 3. REGIONAL INTERACTIVE MAP (HARUR • DHARMAPURI • SALEM)
            // ==========================================
            InteractiveLocationMapCard(
                currentLanguage = currentLanguage,
                onShowToast = { msg ->
                    Log.d("sk", "Map Toast: $msg")
                }
            )

            // ==========================================
            // 4. FEATURED EVENTS & CELEBRATIONS (ITEM NAME ON LEFT, CLICK BUTTON ON RIGHT)
            // ==========================================
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (currentLanguage == Language.TAMIL) "🎉 விசேஷ நிகழ்ச்சிகள் & திருமண மண்டபங்கள்" else "🎉 Events & Kalyana Mandapams",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = if (currentLanguage == Language.TAMIL) "பொருள் பெயர் இடதுபுறம் • முன்பதிவு கிளிக் பொத்தான் வலதுபுறம்" else "Verified Event Items in $district • Click Right Button",
                            fontSize = 10.sp,
                            color = PinkPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(PinkPrimary.copy(alpha = 0.12f))
                            .clickable { onCategorySelect("halls") }
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = "View All →",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = PinkPrimary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Location-aware filtered venues for current town/district
                val locationFilteredVenues = remember(district, village, searchQuery, selectedCategory) {
                    val q = searchQuery.trim()
                    val filtered = SampleData.sampleVenuesAndServices.filter { venue ->
                        val matchesCategory = selectedCategory.isNullOrBlank() || venue.categoryId == selectedCategory
                        val matchesSearch = q.isEmpty() ||
                            venue.titleEn.contains(q, ignoreCase = true) ||
                            venue.titleTa.contains(q, ignoreCase = true) ||
                            venue.district.contains(q, ignoreCase = true) ||
                            venue.village.contains(q, ignoreCase = true) ||
                            venue.address.contains(q, ignoreCase = true)

                        val matchesLoc = district.isBlank() || district.equals("Tamil Nadu", ignoreCase = true) ||
                            venue.district.contains(district, ignoreCase = true) ||
                            venue.village.contains(village, ignoreCase = true) ||
                            venue.address.contains(district, ignoreCase = true)

                        matchesCategory && matchesSearch && matchesLoc
                    }
                    if (filtered.isNotEmpty()) filtered else SampleData.sampleVenuesAndServices
                }

                // Step-by-Step Item Control State
                var visibleStepCount by remember { mutableStateOf(1) }
                val totalEventItems = locationFilteredVenues.size

                // Step Indicator & Reveal Button Bar
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(PinkPrimary.copy(alpha = 0.08f))
                        .border(1.dp, PinkPrimary.copy(alpha = 0.25f), RoundedCornerShape(16.dp))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (currentLanguage == Language.TAMIL) "படி நிலை: $visibleStepCount / $totalEventItems ($district மகால்கள்)" else "Step $visibleStepCount of $totalEventItems ($district Mahals)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Text(
                                text = if (currentLanguage == Language.TAMIL) "பொத்தானைக் கிளிக் செய்து அடுத்த பொருளைப் பார்க்கவும்" else "Click button below to step-by-step reveal items",
                                fontSize = 9.5.sp,
                                color = PinkPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Button(
                            onClick = {
                                if (visibleStepCount < totalEventItems) {
                                    visibleStepCount++
                                } else {
                                    visibleStepCount = 1
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = PinkPrimary,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = if (visibleStepCount < totalEventItems) {
                                    if (currentLanguage == Language.TAMIL) "➕ அடுத்த பொருள் (Step ${visibleStepCount + 1})" else "➕ Next Item (${visibleStepCount + 1})"
                                } else {
                                    if (currentLanguage == Language.TAMIL) "🔄 படி 1-க்கு திரும்பு" else "🔄 Reset Steps"
                                },
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Event List Rows: Revealed Step-by-Step on Button Click
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    locationFilteredVenues.take(visibleStepCount).forEachIndexed { index, venue ->
                        AnimatedVisibility(
                            visible = index < visibleStepCount,
                            enter = fadeIn(animationSpec = tween(400)) + slideInVertically(animationSpec = tween(400)) { it / 2 }
                        ) {
                            GlassCard(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onBookVenueClick(venue) },
                                elevation = 4.dp,
                                shape = RoundedCornerShape(20.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    // LEFT SIDE: Item Name, Image & Details
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(56.dp)
                                                .clip(RoundedCornerShape(14.dp))
                                                .background(Color.LightGray.copy(alpha = 0.2f))
                                        ) {
                                            AsyncImage(
                                                model = venue.imageUrl,
                                                contentDescription = venue.titleEn,
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier.fillMaxSize()
                                            )
                                        }

                                        Column(modifier = Modifier.weight(1f)) {
                                            // Item Name on Left
                                            Text(
                                                text = if (currentLanguage == Language.TAMIL) venue.titleTa else venue.titleEn,
                                                fontWeight = FontWeight.Black,
                                                fontSize = 13.5.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                                color = MaterialTheme.colorScheme.onBackground
                                            )

                                            Spacer(modifier = Modifier.height(2.dp))

                                            Text(
                                                text = "📍 ${venue.village}, ${venue.district}",
                                                fontSize = 10.sp,
                                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                                            )

                                            Spacer(modifier = Modifier.height(2.dp))

                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = "₹${venue.pricePerDay.toInt()}/day",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 12.sp,
                                                    color = PinkPrimary
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = "★ ${venue.rating}",
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = GoldPrimary
                                                )
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.width(6.dp))

                                    // RIGHT SIDE: Favorite Toggle & Book Button
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        val isFav = wishlistItems.any { it.id == venue.id }
                                        IconButton(
                                            onClick = { onToggleWishlist(venue) },
                                            modifier = Modifier
                                                .size(34.dp)
                                                .clip(CircleShape)
                                                .background(if (isFav) PinkPrimary.copy(alpha = 0.15f) else Color.LightGray.copy(alpha = 0.2f))
                                        ) {
                                            Icon(
                                                imageVector = if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                                contentDescription = "Favorite",
                                                tint = if (isFav) PinkPrimary else Color.Gray,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }

                                        Button(
                                            onClick = { onBookVenueClick(venue) },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = PinkPrimary,
                                                contentColor = Color.White
                                            ),
                                            shape = RoundedCornerShape(14.dp),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                            elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp)
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = if (currentLanguage == Language.TAMIL) "முன்பதிவு செய்ய கிளிக்" else "Click to Book",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Black
                                                )
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Icon(
                                                    imageVector = Icons.Default.ArrowForward,
                                                    contentDescription = "Click",
                                                    modifier = Modifier.size(12.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // ==========================================
            // 5. MARKETPLACE PRODUCTS HIGHLIGHT
            // ==========================================
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (currentLanguage == Language.TAMIL) "சந்தை சிறப்பு பொருட்கள்" else "Marketplace Featured Items",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "Buy from Meesho, Flipkart & Amazon sellers",
                            fontSize = 10.sp,
                            color = PinkPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Text(
                        text = "Explore Store →",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = PinkPrimary,
                        modifier = Modifier.clickable { onViewProductClick(SampleData.sampleMarketProducts.first()) }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(SampleData.sampleMarketProducts.take(4)) { product ->
                        GlassCard(
                            modifier = Modifier
                                .width(170.dp)
                                .clickable { onViewProductClick(product) },
                            elevation = 4.dp,
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Column {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(100.dp)
                                ) {
                                    AsyncImage(
                                        model = product.imageUrl,
                                        contentDescription = product.titleEn,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )

                                    Box(
                                        modifier = Modifier
                                            .padding(6.dp)
                                            .align(Alignment.TopStart)
                                    ) {
                                        GlassBadge(
                                            text = product.marketplace,
                                            containerColor = when (product.marketplace.lowercase()) {
                                                "meesho" -> Color(0xFFE91E63)
                                                "flipkart" -> Color(0xFF2874F0)
                                                else -> Color(0xFFFF9900)
                                            },
                                            contentColor = Color.White
                                        )
                                    }
                                }

                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        text = if (currentLanguage == Language.TAMIL) product.titleTa else product.titleEn,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        color = MaterialTheme.colorScheme.onBackground
                                    )

                                    Spacer(modifier = Modifier.height(4.dp))

                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = "₹${product.price.toInt()}",
                                            fontWeight = FontWeight.Black,
                                            fontSize = 14.sp,
                                            color = PinkPrimary
                                        )
                                        Text(
                                            text = "★ ${product.rating}",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = GoldPrimary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // ==========================================
            // 5.5 NEXT PROCESS ACTION & ROLE MANAGEMENT CARD
            // ==========================================
            Spacer(modifier = Modifier.height(16.dp))

            // Prominent Bottom Next Process Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(PinkPrimary, PinkDark)
                        )
                    )
                    .border(1.5.dp, GoldPrimary, RoundedCornerShape(22.dp))
                    .clickable { onNextProcessClick() }
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "🚀 ",
                                fontSize = 16.sp
                            )
                            Text(
                                text = if (currentLanguage == Language.TAMIL) "அடுத்த செயல்முறை (Next Process)" else "Next Process → Proceed to Booking",
                                fontWeight = FontWeight.Black,
                                fontSize = 15.sp,
                                color = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (currentLanguage == Language.TAMIL) "தொடர்ந்து அடுத்த படிநிலைக்குச் சென்று மகால்கள் / சேவைகளை முன்பதிவு செய்யவும்" else "Click here to continuously transition to venue bookings, job tasks & services",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }

                    Button(
                        onClick = { onNextProcessClick() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = GoldPrimary,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(14.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = if (currentLanguage == Language.TAMIL) "அடுத்து ➔" else "Next ➔",
                            fontWeight = FontWeight.Black,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Role Management & Permissions Info Card
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                elevation = 4.dp,
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = if (currentLanguage == Language.TAMIL) "👥 பங்கு மேலாண்மை & அனுமதி (Role Management)" else "👥 Role Management & Operations Summary",
                        fontWeight = FontWeight.Black,
                        fontSize = 13.sp,
                        color = PinkPrimary
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    // Admin Role
                    Row(
                        verticalAlignment = Alignment.Top,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFFEF2F2))
                            .padding(8.dp)
                    ) {
                        Text("👑 ", fontSize = 13.sp)
                        Column {
                            Text(
                                text = if (currentLanguage == Language.TAMIL) "நிர்வாகி (Admin): அனைத்தும் கட்டுப்படுத்தப்படும்" else "Admin: Full System Management",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.5.sp,
                                color = Color(0xFF991B1B)
                            )
                            Text(
                                text = if (currentLanguage == Language.TAMIL) "மகால்கள், பொருட்கள், விற்பனையாளர்கள் மற்றும் முன்பதிவுகளை முழுமையாக நிர்வகிக்கும் அதிகாரம்" else "Manages all venues, products, vendors, user bookings, and system settings",
                                fontSize = 10.sp,
                                color = Color(0xFF7F1D1D)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Vendor Role
                    Row(
                        verticalAlignment = Alignment.Top,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFEFF6FF))
                            .padding(8.dp)
                    ) {
                        Text("🛠️ ", fontSize = 13.sp)
                        Column {
                            Text(
                                text = if (currentLanguage == Language.TAMIL) "விற்பனையாளர் (Vendor): ஒதுக்கப்பட்ட பணிகளைச் செய்ய வேண்டும்" else "Vendor: Executing Assigned Tasks",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.5.sp,
                                color = Color(0xFF1E40AF)
                            )
                            Text(
                                text = if (currentLanguage == Language.TAMIL) "நிர்வாகி மற்றும் பயனர் கேட்கும் பணிகளை மட்டும் ஏற்று நிறைவேற்றுவார்" else "Executes work specified by Admin and User, handles orders and updates status",
                                fontSize = 10.sp,
                                color = Color(0xFF1E3A8A)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // User Role
                    Row(
                        verticalAlignment = Alignment.Top,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFF0FDF4))
                            .padding(8.dp)
                    ) {
                        Text("👤 ", fontSize = 13.sp)
                        Column {
                            Text(
                                text = if (currentLanguage == Language.TAMIL) "பயனர் (User): பார்வை, பணி ஒப்படைப்பு & முன்பதிவு" else "User: Viewing, Requesting Work & Booking",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.5.sp,
                                color = Color(0xFF166534)
                            )
                            Text(
                                text = if (currentLanguage == Language.TAMIL) "சேவைகளைப் பார்வையிடுதல், வேலைகளைக் கோருதல் மற்றும் முன்பதிவுகளைச் செய்தல்" else "Views venues & market items, creates work orders, places bookings, and tracks status",
                                fontSize = 10.sp,
                                color = Color(0xFF14532D)
                            )
                        }
                    }
                }
            }

            // ==========================================
            // 6. GLOBAL FOOTER
            // ==========================================
            Spacer(modifier = Modifier.height(20.dp))
            HorizontalDivider(
                modifier = Modifier.padding(horizontal = 32.dp),
                color = PinkPrimary.copy(alpha = 0.2f)
            )
            Spacer(modifier = Modifier.height(16.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 20.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "© 2026 Shivani Hub. All Rights Reserved.",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                    textAlign = TextAlign.Center
                )
            }
        }

        // Service Directory List Dialog Modal
        if (showServiceDirectoryList) {
            Dialog(onDismissRequest = { showServiceDirectoryList = false }) {
                Surface(
                    shape = RoundedCornerShape(26.dp),
                    color = Color.White,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp, vertical = 20.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = if (currentLanguage == Language.TAMIL) "ஷிவானி ஹப் சேவைகள் பட்டியல்" else "Shivani Hub Service Directory List",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 16.sp,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                Text(
                                    text = if (currentLanguage == Language.TAMIL) "அனைத்து திருமண மண்டபங்கள் & சேவைகள்" else "Complete verified vendor & hall directory",
                                    fontSize = 10.5.sp,
                                    color = PinkPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            IconButton(
                                onClick = { showServiceDirectoryList = false },
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(PinkPrimary.copy(alpha = 0.12f))
                            ) {
                                Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = PinkPrimary, modifier = Modifier.size(18.dp))
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Scrollable Service List
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(420.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(SampleData.sampleVenuesAndServices) { item ->
                                GlassCard(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            showServiceDirectoryList = false
                                            onBookVenueClick(item)
                                        },
                                    elevation = 3.dp,
                                    shape = RoundedCornerShape(16.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(50.dp)
                                                    .clip(RoundedCornerShape(12.dp))
                                                    .background(Color.LightGray.copy(alpha = 0.2f))
                                            ) {
                                                AsyncImage(
                                                    model = item.imageUrl,
                                                    contentDescription = item.titleEn,
                                                    contentScale = ContentScale.Crop,
                                                    modifier = Modifier.fillMaxSize()
                                                )
                                            }

                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = if (currentLanguage == Language.TAMIL) item.titleTa else item.titleEn,
                                                    fontWeight = FontWeight.Black,
                                                    fontSize = 12.5.sp,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                Text(
                                                    text = "📍 ${item.village}, ${item.district}",
                                                    fontSize = 9.5.sp,
                                                    color = Color.Gray
                                                )
                                                Text(
                                                    text = "₹${item.pricePerDay.toInt()}/day • ★ ${item.rating}",
                                                    fontSize = 10.5.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = PinkPrimary
                                                )
                                            }
                                        }

                                        Button(
                                            onClick = {
                                                showServiceDirectoryList = false
                                                onBookVenueClick(item)
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                                            shape = RoundedCornerShape(12.dp),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                        ) {
                                            Text(
                                                text = if (currentLanguage == Language.TAMIL) "தேர்வு" else "Select",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = { showServiceDirectoryList = false },
                            colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = if (currentLanguage == Language.TAMIL) "மூடு" else "Close List",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // ==========================================
        // LIVE NOTIFICATIONS DIALOG MODAL
        // ==========================================
        if (showNotificationsDialog) {
            Dialog(onDismissRequest = { showNotificationsDialog = false }) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    shape = RoundedCornerShape(26.dp),
                    color = Color.White,
                    tonalElevation = 8.dp
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.NotificationsActive,
                                    contentDescription = "Notifications",
                                    tint = Color(0xFFEF4444),
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = if (currentLanguage == Language.TAMIL) "🔔 நேரலை அறிவிப்புகள்" else "🔔 Live Notifications",
                                        fontWeight = FontWeight.Black,
                                        fontSize = 17.sp,
                                        color = MaterialTheme.colorScheme.onBackground
                                    )
                                    Text(
                                        text = "Harur • Dharmapuri • Salem Alerts",
                                        fontSize = 10.5.sp,
                                        color = PinkPrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            IconButton(onClick = { showNotificationsDialog = false }) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Close",
                                    tint = Color.Gray
                                )
                            }
                        }

                        HorizontalDivider(
                            modifier = Modifier.padding(vertical = 12.dp),
                            color = PinkPrimary.copy(alpha = 0.2f)
                        )

                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.height(260.dp)
                        ) {
                            items(liveNotifications) { notif ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = Color(0xFFFFF5F8)
                                    ),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, PinkPrimary.copy(alpha = 0.2f))
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = notif.first,
                                                fontWeight = FontWeight.ExtraBold,
                                                fontSize = 13.sp,
                                                color = MaterialTheme.colorScheme.onBackground
                                            )
                                            Text(
                                                text = notif.third,
                                                fontSize = 10.sp,
                                                color = Color.Gray,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(4.dp))

                                        Text(
                                            text = notif.second,
                                            fontSize = 11.5.sp,
                                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f)
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = { showNotificationsDialog = false },
                            colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = if (currentLanguage == Language.TAMIL) "சரி, புரிந்தது" else "Dismiss",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickPillButton(
    label: String,
    iconEmoji: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White)
            .border(1.dp, PinkPrimary.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(vertical = 8.dp, horizontal = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(iconEmoji, fontSize = 14.sp)
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = PinkPrimary
            )
        }
    }
}

private data class ModuleItem(
    val title: String,
    val subtitle: String,
    val icon: String,
    val color: Color,
    val onClick: () -> Unit
)
