package com.example.worker

import android.content.Context
import android.util.Log
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.Data
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.model.SampleData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class DharmapuriBackupWorker(
    context: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val district = inputData.getString(KEY_DISTRICT) ?: "Dharmapuri"
            val timeframeDays = inputData.getInt(KEY_TIMEFRAME_DAYS, 28)

            Log.d(TAG, "Starting WorkManager automatic data backup for district: $district ($timeframeDays days timeframe)")

            // Filter district venues and products
            val filteredVenues = SampleData.sampleVenuesAndServices.filter {
                district.equals("All Tamil Nadu", ignoreCase = true) || it.district.equals(district, ignoreCase = true)
            }

            val filteredProducts = SampleData.sampleMarketProducts.filter {
                district.equals("All Tamil Nadu", ignoreCase = true) || it.village.contains(district, ignoreCase = true) ||
                        it.titleEn.contains(district, ignoreCase = true) || it.titleTa.contains(district, ignoreCase = true) ||
                        it.vendorName.contains(district, ignoreCase = true)
            }

            val filteredLocations = SampleData.sampleLocations.filter {
                district.equals("All Tamil Nadu", ignoreCase = true) || it.district.equals(district, ignoreCase = true)
            }

            // Build JSON Backup Payload
            val backupJsonObject = JSONObject().apply {
                put("appName", "Shivani Connect - Tamil Nadu Local Services")
                put("districtScope", district)
                put("timeframeDays", timeframeDays)
                put("backupTimestamp", SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()))

                // Venues array
                val venuesArray = JSONArray()
                filteredVenues.forEach { v ->
                    venuesArray.put(JSONObject().apply {
                        put("id", v.id)
                        put("titleEn", v.titleEn)
                        put("titleTa", v.titleTa)
                        put("district", v.district)
                        put("taluk", v.taluk)
                        put("village", v.village)
                        put("pricePerDay", v.pricePerDay)
                        put("rating", v.rating)
                        put("reviewCount", v.reviewCount)
                        put("phone", v.phone)
                        put("vendorName", v.vendorName)
                    })
                }
                put("venuesAndServices", venuesArray)

                // Marketplace Products array
                val productsArray = JSONArray()
                filteredProducts.forEach { p ->
                    productsArray.put(JSONObject().apply {
                        put("id", p.id)
                        put("titleEn", p.titleEn)
                        put("titleTa", p.titleTa)
                        put("price", p.price)
                        put("rating", p.rating)
                        put("reviewCount", p.reviewCount)
                        put("village", p.village)
                        put("vendorName", p.vendorName)
                        put("category", p.category)
                    })
                }
                put("marketplaceProducts", productsArray)

                // Locations array
                val locationsArray = JSONArray()
                filteredLocations.forEach { loc ->
                    locationsArray.put(JSONObject().apply {
                        put("district", loc.district)
                        put("districtTamil", loc.districtTamil)
                        put("taluk", loc.taluk)
                        put("talukTamil", loc.talukTamil)
                        put("village", loc.village)
                        put("villageTamil", loc.villageTamil)
                        put("pinCode", loc.pinCode)
                    })
                }
                put("districtLocations", locationsArray)
            }

            // Save JSON to local app files directory
            val backupDir = File(applicationContext.filesDir, "backups")
            if (!backupDir.exists()) {
                backupDir.mkdirs()
            }

            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val backupFile = File(backupDir, "${district.lowercase(Locale.US)}_backup_$timeStamp.json")
            backupFile.writeText(backupJsonObject.toString(2))

            Log.d(TAG, "WorkManager backup successfully created at: ${backupFile.absolutePath}")

            // Prepare Output Data
            val outputData = Data.Builder()
                .putString(KEY_RESULT_FILE_PATH, backupFile.absolutePath)
                .putInt(KEY_RESULT_VENUE_COUNT, filteredVenues.size)
                .putInt(KEY_RESULT_PRODUCT_COUNT, filteredProducts.size)
                .putString(KEY_RESULT_TIMESTAMP, SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()))
                .build()

            Result.success(outputData)
        } catch (e: Exception) {
            Log.e(TAG, "WorkManager backup failed", e)
            Result.failure(
                Data.Builder().putString("error", e.localizedMessage ?: "Unknown error").build()
            )
        }
    }

    companion object {
        const val TAG = "DharmapuriBackupWorker"
        const val WORK_NAME_PERIODIC = "dharmapuri_periodic_backup_work"
        const val WORK_NAME_ONETIME = "dharmapuri_onetime_backup_work"

        const val KEY_DISTRICT = "key_district"
        const val KEY_TIMEFRAME_DAYS = "key_timeframe_days"

        const val KEY_RESULT_FILE_PATH = "key_result_file_path"
        const val KEY_RESULT_VENUE_COUNT = "key_result_venue_count"
        const val KEY_RESULT_PRODUCT_COUNT = "key_result_product_count"
        const val KEY_RESULT_TIMESTAMP = "key_result_timestamp"

        /**
         * Enqueues a periodic background backup task via WorkManager.
         * Timeframe options: 1 day, 28 days (4 weeks), 365 days (1 year).
         */
        fun schedulePeriodicBackup(context: Context, timeframeDays: Int, district: String) {
            val workManager = WorkManager.getInstance(context)

            val inputData = Data.Builder()
                .putString(KEY_DISTRICT, district)
                .putInt(KEY_TIMEFRAME_DAYS, timeframeDays)
                .build()

            val constraints = Constraints.Builder()
                .setRequiresStorageNotLow(true)
                .setRequiredNetworkType(NetworkType.NOT_REQUIRED)
                .build()

            val repeatIntervalHours = (timeframeDays * 24L).coerceAtLeast(24L) // Min 24 hours periodic

            val periodicWorkRequest = PeriodicWorkRequestBuilder<DharmapuriBackupWorker>(
                repeatIntervalHours, TimeUnit.HOURS
            )
                .setInputData(inputData)
                .setConstraints(constraints)
                .build()

            workManager.enqueueUniquePeriodicWork(
                WORK_NAME_PERIODIC,
                ExistingPeriodicWorkPolicy.UPDATE,
                periodicWorkRequest
            )

            Log.d(TAG, "Scheduled WorkManager periodic backup every $timeframeDays days for $district")
        }

        /**
         * Enqueues an immediate one-time background backup task via WorkManager.
         */
        fun triggerImmediateBackup(context: Context, timeframeDays: Int, district: String) {
            val workManager = WorkManager.getInstance(context)

            val inputData = Data.Builder()
                .putString(KEY_DISTRICT, district)
                .putInt(KEY_TIMEFRAME_DAYS, timeframeDays)
                .build()

            val oneTimeWorkRequest = OneTimeWorkRequestBuilder<DharmapuriBackupWorker>()
                .setInputData(inputData)
                .build()

            workManager.enqueueUniqueWork(
                WORK_NAME_ONETIME,
                ExistingWorkPolicy.REPLACE,
                oneTimeWorkRequest
            )

            Log.d(TAG, "Enqueued WorkManager immediate one-time backup for $district")
        }
    }
}
