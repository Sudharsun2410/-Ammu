package com.example.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.BookingEntity
import com.example.data.CartItemEntity
import com.example.data.ShivaniRepository
import com.example.data.WishlistItemEntity
import com.example.model.AdminReferralSettings
import com.example.model.ChatMessage
import com.example.model.Language
import com.example.model.MarketProduct
import com.example.model.SampleData
import com.example.model.UserRole
import com.example.model.VenueOrService
import com.example.model.VillageLocation
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class ShivaniViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ShivaniRepository
    val savedBookings: StateFlow<List<BookingEntity>>
    val cartItems: StateFlow<List<CartItemEntity>>
    val wishlistItems: StateFlow<List<WishlistItemEntity>>
    val eCommerceProducts: StateFlow<List<com.example.data.ECommerceProductEntity>>

    // Price Range Filter State
    private val _priceRange = MutableStateFlow(0f..5000f)
    val priceRange: StateFlow<ClosedFloatingPointRange<Float>> = _priceRange.asStateFlow()

    fun setPriceRange(range: ClosedFloatingPointRange<Float>) {
        _priceRange.value = range
    }

    init {
        val database = AppDatabase.getDatabase(application)
        repository = ShivaniRepository(database.shivaniDao())

        savedBookings = repository.allBookings.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        cartItems = repository.cartItems.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        wishlistItems = repository.wishlistItems.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        @OptIn(ExperimentalCoroutinesApi::class)
        eCommerceProducts = _priceRange.flatMapLatest { range ->
            repository.getECommerceProductsByPriceRange(range.start.toDouble(), range.endInclusive.toDouble())
        }.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )
    }

    // Admin Referral & Social Settings
    private val _referralSettings = MutableStateFlow(AdminReferralSettings())
    val referralSettings: StateFlow<AdminReferralSettings> = _referralSettings.asStateFlow()

    // Admin Managed Market Products
    private val _marketProducts = MutableStateFlow<List<MarketProduct>>(SampleData.sampleMarketProducts)
    val marketProducts: StateFlow<List<MarketProduct>> = _marketProducts.asStateFlow()

    // UI Preferences
    private val _currentLanguage = MutableStateFlow(Language.ENGLISH)
    val currentLanguage: StateFlow<Language> = _currentLanguage.asStateFlow()

    private val _isDarkMode = MutableStateFlow(false)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    private val _currentRole = MutableStateFlow(UserRole.USER)
    val currentRole: StateFlow<UserRole> = _currentRole.asStateFlow()

    // Active Navigation Tab: 0=Home, 1=Map, 2=Events, 3=Store, 4=AI, 5=Role Workspace
    private val _selectedTab = MutableStateFlow(0)
    val selectedTab: StateFlow<Int> = _selectedTab.asStateFlow()

    // Selected Location Navigation
    private val _selectedDistrict = MutableStateFlow("Madurai")
    val selectedDistrict: StateFlow<String> = _selectedDistrict.asStateFlow()

    private val _selectedTaluk = MutableStateFlow("Vadipatti")
    val selectedTaluk: StateFlow<String> = _selectedTaluk.asStateFlow()

    private val _selectedVillage = MutableStateFlow("Alanganallur")
    val selectedVillage: StateFlow<String> = _selectedVillage.asStateFlow()

    // Filters & Search Query
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategoryId = MutableStateFlow<String?>(null)
    val selectedCategoryId: StateFlow<String?> = _selectedCategoryId.asStateFlow()

    // Selected Detail Models for Modal Sheets
    private val _selectedVenue = MutableStateFlow<VenueOrService?>(null)
    val selectedVenue: StateFlow<VenueOrService?> = _selectedVenue.asStateFlow()

    private val _selectedProduct = MutableStateFlow<MarketProduct?>(null)
    val selectedProduct: StateFlow<MarketProduct?> = _selectedProduct.asStateFlow()

    // Active Booking Payment Sheet
    private val _bookingDate = MutableStateFlow("2026-08-25")
    val bookingDate: StateFlow<String> = _bookingDate.asStateFlow()

    private val _bookingTimeSlot = MutableStateFlow("Morning (6:00 AM - 2:00 PM)")
    val bookingTimeSlot: StateFlow<String> = _bookingTimeSlot.asStateFlow()

    private val _guestCount = MutableStateFlow("500 Guests")
    val guestCount: StateFlow<String> = _guestCount.asStateFlow()

    private val _showPaymentDialog = MutableStateFlow(false)
    val showPaymentDialog: StateFlow<Boolean> = _showPaymentDialog.asStateFlow()

    private val _lastCreatedBooking = MutableStateFlow<BookingEntity?>(null)
    val lastCreatedBooking: StateFlow<BookingEntity?> = _lastCreatedBooking.asStateFlow()

    private val _showInvoiceModal = MutableStateFlow(false)
    val showInvoiceModal: StateFlow<Boolean> = _showInvoiceModal.asStateFlow()

    // Toast / Notification Message
    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    // Chat with AI & Vendors
    private val _chatMessages = MutableStateFlow(
        listOf(
            ChatMessage(
                id = "1",
                senderName = "Shivani AI Assistant",
                isUser = false,
                text = "Vanakkam! 🙏 I am your Shivani Connect AI assistant. Ask me anything about Marriage Halls, Catering, Village Services, or Product Orders across Tamil Nadu villages!",
                time = "Just now",
                isAi = true
            )
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    fun toggleLanguage() {
        _currentLanguage.value = if (_currentLanguage.value == Language.ENGLISH) Language.TAMIL else Language.ENGLISH
        Log.d("sk", "Language toggled to ${_currentLanguage.value}")
    }

    fun toggleDarkMode() {
        _isDarkMode.value = !_isDarkMode.value
        Log.d("sk", "Dark mode set to ${_isDarkMode.value}")
    }

    fun setRole(role: UserRole) {
        _currentRole.value = role
        Log.d("sk", "User role changed to ${role.displayName}")
        showToast("Switched role to ${role.displayName}")
    }

    fun selectTab(tabIndex: Int) {
        _selectedTab.value = tabIndex
        Log.d("sk", "Navigation tab selected: $tabIndex")
    }

    fun setLocation(district: String, taluk: String, village: String) {
        _selectedDistrict.value = district
        _selectedTaluk.value = taluk
        _selectedVillage.value = village
        Log.d("sk", "Location set: District=$district, Taluk=$taluk, Village=$village")
        showToast("Location updated to $village, $district")
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
        Log.d("sk", "Search query updated: $query")
    }

    fun setCategoryFilter(categoryId: String?) {
        _selectedCategoryId.value = if (_selectedCategoryId.value == categoryId) null else categoryId
    }

    fun setSelectedVenue(venue: VenueOrService?) {
        _selectedVenue.value = venue
    }

    fun setSelectedProduct(product: MarketProduct?) {
        _selectedProduct.value = product
    }

    fun setBookingDetails(date: String, timeSlot: String, guests: String) {
        _bookingDate.value = date
        _bookingTimeSlot.value = timeSlot
        _guestCount.value = guests
    }

    fun openPaymentDialog() {
        _showPaymentDialog.value = true
    }

    fun closePaymentDialog() {
        _showPaymentDialog.value = false
    }

    fun confirmBooking(paymentMethod: String) {
        val venue = _selectedVenue.value ?: return
        val bookingId = "SHIV-" + (1000..9999).random()

        val newBooking = BookingEntity(
            bookingId = bookingId,
            title = venue.titleEn,
            category = venue.categoryId,
            district = venue.district,
            village = venue.village,
            bookingDate = _bookingDate.value,
            timeSlot = _bookingTimeSlot.value,
            guestCount = _guestCount.value,
            totalPrice = "₹" + venue.pricePerDay.toInt(),
            paymentMethod = paymentMethod,
            status = "CONFIRMED",
            customerName = "Sudharsan R",
            customerPhone = "+91 98765 43210"
        )

        viewModelScope.launch {
            repository.createBooking(newBooking)
            _lastCreatedBooking.value = newBooking
            _showPaymentDialog.value = false
            _showInvoiceModal.value = true
            showToast("Booking Confirmed! ID: $bookingId. SMS & WhatsApp dispatch triggered.")
        }
    }

    fun closeInvoiceModal() {
        _showInvoiceModal.value = false
    }

    fun viewInvoiceForBooking(booking: BookingEntity) {
        _lastCreatedBooking.value = booking
        _showInvoiceModal.value = true
    }

    fun cancelBooking(id: Int) {
        viewModelScope.launch {
            repository.updateBookingStatus(id, "CANCELLED")
            showToast("Booking #$id has been cancelled.")
        }
    }

    fun updateBookingStatus(id: Int, status: String) {
        viewModelScope.launch {
            repository.updateBookingStatus(id, status)
            showToast("Booking #$id updated to $status")
        }
    }

    fun deleteBooking(id: Int) {
        viewModelScope.launch {
            repository.cancelBooking(id)
            showToast("Booking record removed permanently.")
        }
    }

    fun addSampleBookings() {
        viewModelScope.launch {
            val sample1 = BookingEntity(
                bookingId = "SHIV-8012",
                title = "Sri Lakshmi Marriage Palace",
                category = "halls",
                district = "Madurai",
                village = "Alanganallur",
                bookingDate = "2026-08-28",
                timeSlot = "Full Day (6:00 AM - 10:00 PM)",
                guestCount = "800 Guests",
                totalPrice = "₹45000",
                paymentMethod = "Google Pay UPI",
                status = "CONFIRMED",
                customerName = "Sudharsan R",
                customerPhone = "+91 98765 43210"
            )

            val sample2 = BookingEntity(
                bookingId = "SHIV-9310",
                title = "Grand Temple View Photography",
                category = "photo",
                district = "Madurai",
                village = "Palamedu",
                bookingDate = "2026-09-05",
                timeSlot = "Morning Session (7:00 AM - 1:00 PM)",
                guestCount = "400 Guests",
                totalPrice = "₹18500",
                paymentMethod = "PhonePe UPI",
                status = "PENDING",
                customerName = "Sudharsan R",
                customerPhone = "+91 98765 43210"
            )

            val sample3 = BookingEntity(
                bookingId = "SHIV-5240",
                title = "Meenakshi Village Catering Service",
                category = "catering",
                district = "Madurai",
                village = "Vadipatti",
                bookingDate = "2026-05-15",
                timeSlot = "Evening Banquet (6:00 PM - 10:00 PM)",
                guestCount = "350 Guests",
                totalPrice = "₹28000",
                paymentMethod = "PhonePe UPI",
                status = "COMPLETED",
                customerName = "Sudharsan R",
                customerPhone = "+91 98765 43210"
            )

            val sample4 = BookingEntity(
                bookingId = "SHIV-3102",
                title = "Royal Sound & DJ Orchestra",
                category = "dj",
                district = "Dharmapuri",
                village = "Harur Town",
                bookingDate = "2026-06-10",
                timeSlot = "Night Stage (7:00 PM - 11:00 PM)",
                guestCount = "500 Guests",
                totalPrice = "₹15000",
                paymentMethod = "Cash on Service",
                status = "CANCELLED",
                customerName = "Sudharsan R",
                customerPhone = "+91 98765 43210"
            )

            repository.createBooking(sample1)
            repository.createBooking(sample2)
            repository.createBooking(sample3)
            repository.createBooking(sample4)
            showToast("Loaded past & upcoming bookings into local database!")
        }
    }

    fun addToCart(product: MarketProduct) {
        viewModelScope.launch {
            repository.addToCart(
                CartItemEntity(
                    productId = product.id,
                    title = product.titleEn,
                    price = product.price,
                    quantity = 1,
                    imageUrl = product.imageUrl,
                    village = product.village,
                    vendorName = product.vendorName
                )
            )
            showToast("Added ${product.titleEn} to cart!")
        }
    }

    fun removeFromCart(cartId: Int) {
        viewModelScope.launch {
            repository.removeFromCart(cartId)
        }
    }

    fun fetchAndStoreEcommerceLink(url: String) {
        if (url.isBlank()) return
        Log.d("sk", "Enqueueing ECommerce background worker for URL: $url")
        com.example.worker.ECommerceFetchWorker.enqueueProductFetch(getApplication(), url)
        showToast("Started background worker to parse & store product details in Room DB!")
    }

    fun deleteECommerceProduct(id: Int) {
        viewModelScope.launch {
            repository.deleteECommerceProduct(id)
            showToast("Removed product from local Room database")
        }
    }

    fun toggleVenueWishlist(venue: VenueOrService) {
        viewModelScope.launch {
            val isPresent = wishlistItems.value.any { it.id == venue.id }
            repository.toggleWishlist(
                WishlistItemEntity(
                    id = venue.id,
                    title = venue.titleEn,
                    category = venue.categoryId,
                    price = "₹" + venue.pricePerDay.toInt() + "/day",
                    village = "${venue.district}, ${venue.village}",
                    rating = venue.rating,
                    imageUrl = venue.imageUrl,
                    vendorName = venue.vendorName
                ),
                isWishlisted = isPresent
            )
            showToast(if (isPresent) "Removed '${venue.titleEn}' from Room DB Favorites" else "Saved '${venue.titleEn}' to Room DB Favorites ❤️")
        }
    }

    fun toggleWishlist(product: MarketProduct) {
        viewModelScope.launch {
            val isPresent = wishlistItems.value.any { it.id == product.id }
            repository.toggleWishlist(
                WishlistItemEntity(
                    id = product.id,
                    title = product.titleEn,
                    category = product.category,
                    price = "₹" + product.price.toInt(),
                    village = product.village,
                    rating = product.rating,
                    imageUrl = product.imageUrl,
                    vendorName = product.vendorName
                ),
                isWishlisted = isPresent
            )
            showToast(if (isPresent) "Removed from saved items" else "Saved to local Room wishlist")
        }
    }

    fun removeFromWishlist(id: String) {
        viewModelScope.launch {
            repository.toggleWishlist(
                WishlistItemEntity(id = id, title = "", category = "", price = "", village = "", rating = 0.0),
                isWishlisted = true
            )
            showToast("Removed from saved items")
        }
    }

    fun saveEcommerceToWishlist(product: com.example.data.ECommerceProductEntity) {
        viewModelScope.launch {
            val wishId = "ecom_${product.id}"
            val isPresent = wishlistItems.value.any { it.id == wishId }
            repository.toggleWishlist(
                WishlistItemEntity(
                    id = wishId,
                    title = product.title,
                    category = product.platform,
                    price = "₹" + product.price.toInt(),
                    village = product.vendorName,
                    rating = product.rating,
                    imageUrl = product.imageUrl,
                    vendorName = product.platform
                ),
                isWishlisted = isPresent
            )
            showToast(if (isPresent) "Removed from wishlist" else "Saved e-commerce product to Room wishlist!")
        }
    }

    fun sendChatMessage(text: String) {
        if (text.isBlank()) return
        val userMsg = ChatMessage(
            id = UUID.randomUUID().toString(),
            senderName = "You",
            isUser = true,
            text = text,
            time = "Now"
        )
        _chatMessages.value = _chatMessages.value + userMsg

        // AI Response Generator
        viewModelScope.launch {
            kotlinx.coroutines.delay(1000)
            val aiResponse = generateAiResponse(text)
            val aiMsg = ChatMessage(
                id = UUID.randomUUID().toString(),
                senderName = "Shivani AI Assistant",
                isUser = false,
                text = aiResponse,
                time = "Now",
                isAi = true
            )
            _chatMessages.value = _chatMessages.value + aiMsg
        }
    }

    private fun generateAiResponse(query: String): String {
        val q = query.lowercase()
        return when {
            q.contains("hall") || q.contains("mahal") || q.contains("wedding") || q.contains("திருமணம்") ->
                "🏰 For weddings in ${_selectedVillage.value.ifBlank { "Alanganallur" }}, Sri Lakshmi Marriage Palace offers 1200 guest capacity with A/C and kitchen at ₹45,000/day. Live available on Shivani Connect!"
            q.contains("cater") || q.contains("food") || q.contains("சமையல்") ->
                "🍲 Meenakshi Village Catering provides traditional banana leaf feasts with authentic Ghee sweets starting at ₹250/plate in ${_selectedDistrict.value}."
            q.contains("price") || q.contains("budget") || q.contains("கட்டணம்") ->
                "💰 Shivani Connect transparently displays price per day/plate with 0% hidden fees. You get direct vendor rates + demo UPI payment invoice!"
            q.contains("map") || q.contains("location") || q.contains("திசை") ->
                "📍 You can select any Tamil Nadu District -> Taluk -> Village in our interactive map tab to view local shops, halls, and agents."
            else ->
                "✨ Great question! Shivani AI can help you calculate total wedding budget, verify hall dates in ${_selectedVillage.value}, or send booking receipts directly to your WhatsApp."
        }
    }

    // Admin Referral & Social Settings Updates
    fun updateReferralSettings(newSettings: AdminReferralSettings) {
        _referralSettings.value = newSettings
        showToast("Admin Referral & Social Settings saved successfully!")
    }

    // Product Management Operations
    fun addMarketProduct(product: MarketProduct) {
        _marketProducts.value = listOf(product) + _marketProducts.value
        showToast("Added product: ${product.titleEn}")
    }

    fun updateMarketProduct(updatedProduct: MarketProduct) {
        _marketProducts.value = _marketProducts.value.map { if (it.id == updatedProduct.id) updatedProduct else it }
        showToast("Updated product: ${updatedProduct.titleEn}")
    }

    fun deleteMarketProduct(productId: String) {
        _marketProducts.value = _marketProducts.value.filterNot { it.id == productId }
        showToast("Product deleted from marketplace")
    }

    fun toggleProductEnabled(productId: String) {
        _marketProducts.value = _marketProducts.value.map {
            if (it.id == productId) it.copy(isEnabled = !it.isEnabled) else it
        }
        val p = _marketProducts.value.find { it.id == productId }
        showToast(if (p?.isEnabled == true) "Product Enabled" else "Product Disabled")
    }

    fun toggleProductFeatured(productId: String) {
        _marketProducts.value = _marketProducts.value.map {
            if (it.id == productId) it.copy(isFeatured = !it.isFeatured) else it
        }
        val p = _marketProducts.value.find { it.id == productId }
        showToast(if (p?.isFeatured == true) "Marked as Featured" else "Unmarked as Featured")
    }

    fun showToast(msg: String) {
        _toastMessage.value = msg
    }

    fun clearToast() {
        _toastMessage.value = null
    }
}
