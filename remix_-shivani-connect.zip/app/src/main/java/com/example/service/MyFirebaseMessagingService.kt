package com.example.service

import android.util.Log
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class MyFirebaseMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d(TAG, "Refreshed FCM token: $token")
        // Can be synced to backend server or local database
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        Log.d(TAG, "From: ${remoteMessage.from}")

        // Check if message contains a notification payload
        val title = remoteMessage.notification?.title ?: remoteMessage.data["title"] ?: "SHIVANI SKHub Update"
        val body = remoteMessage.notification?.body ?: remoteMessage.data["body"] ?: "You have a new notification update."
        val channelId = remoteMessage.data["channel_id"] ?: FcmNotificationManager.CHANNEL_BOOKING

        FcmNotificationManager.showNotification(
            context = applicationContext,
            title = title,
            message = body,
            channelId = channelId
        )
    }

    companion object {
        private const val TAG = "MyFirebaseMessagingService"
    }
}
