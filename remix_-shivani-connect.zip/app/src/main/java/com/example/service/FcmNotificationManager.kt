package com.example.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity
import com.example.R
import com.google.firebase.messaging.FirebaseMessaging
import java.util.concurrent.atomic.AtomicInteger

data class FcmSettingsState(
    val allNotificationsEnabled: Boolean = true,
    val bookingUpdatesEnabled: Boolean = true,
    val promotionalOffersEnabled: Boolean = true,
    val vendorAlertsEnabled: Boolean = true,
    val fcmToken: String = "Fetching token..."
)

object FcmNotificationManager {
    private const val TAG = "FcmNotificationManager"
    const val CHANNEL_BOOKING = "booking_updates_channel"
    const val CHANNEL_PROMO = "promotions_channel"
    private val notificationIdCounter = AtomicInteger(1000)

    fun initNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val bookingChannel = NotificationChannel(
                CHANNEL_BOOKING,
                "Booking & Service Updates",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Real-time updates regarding event hall bookings, orders & village services"
                enableVibration(true)
            }

            val promoChannel = NotificationChannel(
                CHANNEL_PROMO,
                "Promotions & Festive Offers",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Exclusive discounts, coupon codes and seasonal offers"
            }

            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(bookingChannel)
            notificationManager.createNotificationChannel(promoChannel)
            Log.d(TAG, "Notification channels created successfully")
        }
    }

    fun fetchFcmToken(onTokenRetrieved: (String) -> Unit) {
        try {
            FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
                if (!task.isSuccessful) {
                    Log.w(TAG, "Fetching FCM registration token failed", task.exception)
                    onTokenRetrieved("fcm_demo_token_tn_sk_orbit_9841")
                    return@addOnCompleteListener
                }
                val token = task.result ?: "fcm_demo_token_tn_sk_orbit_9841"
                Log.d(TAG, "FCM Token retrieved: $token")
                onTokenRetrieved(token)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error obtaining FCM token: ${e.message}")
            onTokenRetrieved("fcm_demo_token_tn_sk_orbit_9841")
        }
    }

    fun updateTopicSubscriptions(
        bookingEnabled: Boolean,
        promoEnabled: Boolean
    ) {
        try {
            val fm = FirebaseMessaging.getInstance()
            if (bookingEnabled) {
                fm.subscribeToTopic("booking_updates")
            } else {
                fm.unsubscribeFromTopic("booking_updates")
            }

            if (promoEnabled) {
                fm.subscribeToTopic("promotional_offers")
            } else {
                fm.unsubscribeFromTopic("promotional_offers")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error updating topic subscriptions: ${e.message}")
        }
    }

    fun showNotification(
        context: Context,
        title: String,
        message: String,
        channelId: String = CHANNEL_BOOKING
    ) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.sk_shivani_skhub_logo_1785082786285)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)

        try {
            val notificationManager = NotificationManagerCompat.from(context)
            notificationManager.notify(notificationIdCounter.incrementAndGet(), builder.build())
        } catch (e: SecurityException) {
            Log.e(TAG, "Permission denied for showing notification: ${e.message}")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to show notification: ${e.message}")
        }
    }
}
